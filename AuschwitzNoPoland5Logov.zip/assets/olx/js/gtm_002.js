
// Copyright 2012 Google Inc. All rights reserved.
(function(w,g){w[g]=w[g]||{};w[g].e=function(s){return eval(s);};})(window,'google_tag_manager');(function(){

var data = {
"resource": {
  "version":"1816",
  
  "macros":[{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"CARS-6958-fakePriceTest"
    },{
      "function":"__u",
      "vtp_component":"PATH",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__e"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.trackingData.pageView.platform;return a})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupInited"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"onap"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"trackPage"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyINPopupInited"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smcx_0_last_shown_at"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-21kum4ts"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-p6805o46"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-1n35x1h1"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-4vt2a1uy"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-5a6w1cun"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"listing_format"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCP"
    },{
      "function":"__f",
      "vtp_component":"URL"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){fromResult=\"comprar arrendar ferias autoturisme piese camioane utilaje-constructii utilaje-agricole autoutilitare motociclete remorci osobowe czesci motocykle-i-quady dostawcze maszyny-rolnicze ciezarowe maszyny-budowlane przyczepy carros motos comerciais barcos autocaravanas pesados pecas vanzare inchiriere sprzedaz wynajem\".split(\" \");referrer=",["escape",["macro",17],8,16],";if(0\u003Creferrer.length\u0026\u0026(refSplit=referrer.split(\"\/\"),refSplitThird=refSplit[3],isFromListing=fromResult.includes(refSplitThird),\n!0===isFromListing))return\"from_listing\"})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"seCkOtomoto"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtomoto"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPB2CSFinW"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"financing"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtomotoPT"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtomotoTM"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"seCkImovirtual"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPImovirtual"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPLocations"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPREContent"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"seCk"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPStandvirtual"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ethnioLoaded"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPPTCarHistory"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPPTFutureVAS"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPAutovit"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPROCarHistory"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPROFutureVAS"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"seCkOtodom"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtodom"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smRAnkingDzielnic2019"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"seCkStoria"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPStoria"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"listing_type"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"platform"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cat_l1_id"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"__svdk"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"language"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupRAnkingDzielnic2019"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-uyk78346"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtomotoCVD"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPStandvirtualCVD"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPAutovitCVD"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"action_type"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cat_l3_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cat_l2_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"business_status"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"SurveyPopupWakacje2019"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupPltaformsTasks"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupSellersSurvey"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtomotoHM"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOtomotoPF"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPRECVDImp"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"seCkOLXro"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"user_status"
    },{
      "function":"__aev",
      "vtp_varType":"TEXT"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"user_id"
    },{
      "function":"__v",
      "vtp_name":"gtm.triggers",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":""
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"platform"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cat_l1_name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"event"
    },{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"ow-intercept-treejack-3uh176rj"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"user_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"city_name"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"_hjClosedSurveyInvites"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"_hjDonePolls"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"sellerType"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyCAMPPopupInited"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smREBOtodom"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyREBPopupInited"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smRESOtodom"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyRESPopupInited"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"active_job_lister"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupJOBSListers"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupNoclegi2019"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopUpJOBSListersLeadQuality"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveyPopupJOBSListersLeadQuality"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"carfax_free_report_click"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPOTOCarfax"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPSTVB2CFinancing"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPOTOB2CFinancing"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"traffic_source"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPPLCarHistory"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"smCPPLFutureVAS"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"city_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"touch_point_page"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"part"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"parts_brand"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"tires_diameter"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"tires_width"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"tires_season"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"tires_ratio"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"rims_diameter"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"rims_type"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"wheels_rims_type"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"wheels_tires_season"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"seller_type"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"from_price"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"to_price"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"region_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"district_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"distance_filt"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"item_condition_parts"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){if(",["escape",["macro",96],8,16],"||",["escape",["macro",97],8,16],"||",["escape",["macro",98],8,16],"||",["escape",["macro",99],8,16],"||",["escape",["macro",100],8,16],"||",["escape",["macro",101],8,16],"||",["escape",["macro",102],8,16],"||",["escape",["macro",103],8,16],"||",["escape",["macro",104],8,16],"||",["escape",["macro",105],8,16],"||",["escape",["macro",106],8,16],"||",["escape",["macro",107],8,16],"||",["escape",["macro",108],8,16],"||",["escape",["macro",94],8,16],"||",["escape",["macro",109],8,16],"||",["escape",["macro",110],8,16],"||",["escape",["macro",111],8,16],"||\"all\"!==",["escape",["macro",112],8,16],")return\"filter_used\"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].region_name:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.region_name:void 0:void 0))||(window.ninjaPV?window.ninjaPV.region_name:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].region_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.region_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.region_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].city_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.city_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.city_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].city_name:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.city_name:void 0:void 0))||(window.ninjaPV?window.ninjaPV.city_name:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].subregion_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.subregion_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.subregion_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_region_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_region_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_region_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_region_name:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_region_name:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_region_name:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_subregion_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_subregion_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_subregion_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_city_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_city_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_city_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_city_name:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_city_name:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_city_name:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_district_id:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_district_id:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_district_id:void 0)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=window.dataLayer?window.dataLayer[window.dataLayer.length-2].selected_district_name:void 0;return a=(a=a||(window.trackingData?window.trackingData.pageView?window.trackingData.pageView.selected_district_name:void 0:void 0))||(window.ninjaPV?window.ninjaPV.selected_district_name:void 0)})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPOTOFinIns"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"cC2C"
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"surveycSC2CPopupInited"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"smCPOcC2C"
    },{
      "function":"__u",
      "vtp_component":"HOST",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_name":"gtm.elementId",
      "vtp_dataLayerVersion":1
    }],
  "tags":[{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=50,d=\"RollingCEBBG\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBBG?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":1
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .gtm-survey{\n    position:fixed;\n    left:0;\n    top:51px;\n    width:100%;\n    bottom:0;\n    height:100%;\n    z-index:10001;\n    background:#fff;\n  }\n  .gtm-survey__iframe{\n    width:100%;\n    height:100%;\n    border: none;\n  }\n  .gtm-survey__close{\n    width: 28px;\n    height: 28px;\n    background:#fff;\n    border-radius: 50%;\n    top: 27px;\n    right: 8px;\n    text-align: center;\n    position:absolute;\n    border: 1px solid #ccc;\n    line-height: 28px;\n    cursor: pointer;\n    color: #0098d0;\n    font-weight:bold;\n  }\n  .gtm-survey__close:before{\n    content:'X';\n  }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyRandomMax=800,surveyName=\"rollingCEBBG\";function gtmSurveyClose(){document.querySelector(\".js-gtm-survey\").style.display=\"none\";window.dataLayer=window.dataLayer||[];dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:surveyName})}\nfunction gtmSurveyCode(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",gtmSurveyClose);b.appendChild(a);return b}\nfunction generateUUID(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}function surveyRandomizer(a,b){return Math.floor(Math.random()*(1+b-a))+a}\nfunction setCookie(a,b,d){var c=new Date;c.setTime(c.getTime()+864E5*d);d=\"expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+\";\"+d+\";path\\x3d\/\"}function getCookie(a){a+=\"\\x3d\";for(var b=document.cookie.split(\";\"),d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a))return c.substring(a.length,c.length)}return\"\"}function getGTMData(a){a=[\"gtmData:\"+a];return localStorage.hasOwnProperty(a)?String(localStorage[a]):null}var currentPageArray=[\"listing\",\"ad_page\"];\nfunction surveyInit(){if(getCookie(\"surveyPopupInited\")!=surveyName\u0026\u0026!0===currentPageArray.includes(getGTMData(\"currentPage\"))\u0026\u0026\"1\"==this.surveyRandomizer(1,surveyRandomMax)){var a=getGTMData(\"currentCategoryId\"),b=getGTMData(\"adID\")||\"\",d=getCookie(\"user_id\"),c=getCookie(\"user_business_status\"),e=generateUUID();window.survey_id=e;a=\"https:\/\/www.surveymonkey.com\/r\/rollingCEBBG?user_id\\x3d\"+d+\"\\x26clm_session_id\\x3d\"+e+\"\\x26ad_id\\x3d\"+b+\"\\x26category_id\\x3d\"+a+\"\\x26platform\\x3drwd\\x26business_status\\x3d\"+\nc+\"\\x26survey_name\\x3d\"+surveyName;document.body.appendChild(gtmSurveyCode(a));window.dataLayer=window.dataLayer||[];dataLayer.push({gtmSurveyCLMSessionID:e,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:surveyName});setCookie(\"surveyPopupInited\",surveyName,365);console.log(\"survey cookie created\")}}surveyInit();window.addEventListener(\"gtmDataOnChange\",function(a){surveyInit()},!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":3
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=750,d=\"RollingCEBPL\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBPL?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":11
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .gtm-survey{\n    position:fixed;\n    left:0;\n    top:51px;\n    width:100%;\n    bottom:0;\n    height:100%;\n    z-index:10001;\n    background:#fff;\n  }\n  .gtm-survey__iframe{\n    width:100%;\n    height:100%;\n    border: none;\n  }\n  .gtm-survey__close{\n    width: 28px;\n    height: 28px;\n    background:#fff;\n    border-radius: 50%;\n    top: 27px;\n    right: 8px;\n    text-align: center;\n    position:absolute;\n    border: 1px solid #ccc;\n    line-height: 28px;\n    cursor: pointer;\n    color: #0098d0;\n    font-weight:bold;\n  }\n  .gtm-survey__close:before{\n    content:'X';\n  }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyRandomMax=12E4,surveyName=\"rollingCEBPL\";function gtmSurveyClose(){document.querySelector(\".js-gtm-survey\").style.display=\"none\";window.dataLayer=window.dataLayer||[];dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:surveyName})}\nfunction gtmSurveyCode(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",gtmSurveyClose);b.appendChild(a);return b}\nfunction generateUUID(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}function surveyRandomizer(a,b){return Math.floor(Math.random()*(1+b-a))+a}\nfunction setCookie(a,b,d){var c=new Date;c.setTime(c.getTime()+864E5*d);d=\"expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+\";\"+d+\";path\\x3d\/\"}function getCookie(a){a+=\"\\x3d\";for(var b=document.cookie.split(\";\"),d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a))return c.substring(a.length,c.length)}return\"\"}function getGTMData(a){a=[\"gtmData:\"+a];return localStorage.hasOwnProperty(a)?String(localStorage[a]):null}var currentPageArray=[\"listing\",\"ad_page\"];\nfunction surveyInit(){if(getCookie(\"surveyPopupInited\")!=surveyName\u0026\u0026!0===currentPageArray.includes(getGTMData(\"currentPage\"))\u0026\u0026\"1\"==this.surveyRandomizer(1,surveyRandomMax)){var a=getGTMData(\"currentCategoryId\"),b=getGTMData(\"adID\")||\"\",d=getCookie(\"user_id\"),c=getCookie(\"user_business_status\"),e=generateUUID();window.survey_id=e;a=\"https:\/\/www.surveymonkey.com\/r\/rollingCEBPL?user_id\\x3d\"+d+\"\\x26clm_session_id\\x3d\"+e+\"\\x26ad_id\\x3d\"+b+\"\\x26category_id\\x3d\"+a+\"\\x26platform\\x3drwd\\x26business_status\\x3d\"+\nc+\"\\x26survey_name\\x3d\"+surveyName;document.body.appendChild(gtmSurveyCode(a));window.dataLayer=window.dataLayer||[];dataLayer.push({gtmSurveyCLMSessionID:e,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:surveyName});setCookie(\"surveyPopupInited\",surveyName,365);console.log(\"survey cookie created\")}}surveyInit();window.addEventListener(\"gtmDataOnChange\",function(a){surveyInit()},!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":12
    },{
      "function":"__html",
      "priority":100,
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=500,d=\"RollingCEB\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=b;\ne=\"https:\/\/www.surveymonkey.com\/r\/RollingCEB?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);a=JSON.stringify(a);\ndocument.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":14
    },{
      "function":"__html",
      "priority":100,
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .gtm-survey{\n    position:fixed;\n    left:0;\n    top:51px;\n    width:100%;\n    bottom:0;\n    height:100%;\n    z-index:10001;\n    background:#fff;\n  }\n  .gtm-survey__iframe{\n    width:100%;\n    height:100%;\n    border: none;\n  }\n  .gtm-survey__close{\n    width: 28px;\n    height: 28px;\n    background:#fff;\n    border-radius: 50%;\n    top: 27px;\n    right: 8px;\n    text-align: center;\n    position:absolute;\n    border: 1px solid #ccc;\n    line-height: 28px;\n    cursor: pointer;\n    color: #0098d0;\n    font-weight:bold;\n  }\n  .gtm-survey__close:before{\n    content:'X';\n  }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyRandomMax=15E3,surveyName=\"rollingCEB\";function gtmSurveyClose(){document.querySelector(\".js-gtm-survey\").style.display=\"none\";window.dataLayer=window.dataLayer||[];dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:surveyName})}\nfunction gtmSurveyCode(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",gtmSurveyClose);b.appendChild(a);return b}\nfunction generateUUID(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}function surveyRandomizer(a,b){return Math.floor(Math.random()*(1+b-a))+a}\nfunction setCookie(a,b,d){var c=new Date;c.setTime(c.getTime()+864E5*d);d=\"expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+\";\"+d+\";path\\x3d\/\"}function getCookie(a){a+=\"\\x3d\";for(var b=document.cookie.split(\";\"),d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a))return c.substring(a.length,c.length)}return\"\"}function getGTMData(a){a=[\"gtmData:\"+a];return localStorage.hasOwnProperty(a)?String(localStorage[a]):null}var currentPageArray=[\"listing\",\"ad_page\"];\nfunction surveyInit(){if(getCookie(\"surveyPopupInited\")!=surveyName\u0026\u0026!0===currentPageArray.includes(getGTMData(\"currentPage\"))\u0026\u0026\"1\"==this.surveyRandomizer(1,surveyRandomMax)){var a=getGTMData(\"currentCategoryId\"),b=getGTMData(\"adID\")||\"\",d=getCookie(\"user_id\"),c=getCookie(\"user_business_status\"),e=generateUUID();window.survey_id=e;a=\"https:\/\/www.surveymonkey.com\/r\/RollingCEB?user_id\\x3d\"+d+\"\\x26clm_session_id\\x3d\"+e+\"\\x26ad_id\\x3d\"+b+\"\\x26category_id\\x3d\"+a+\"\\x26platform\\x3drwd\\x26business_status\\x3d\"+\nc+\"\\x26survey_name\\x3d\"+surveyName;document.body.appendChild(gtmSurveyCode(a));window.dataLayer=window.dataLayer||[];dataLayer.push({gtmSurveyCLMSessionID:e,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:surveyName});setCookie(\"surveyPopupInited\",surveyName,365);console.log(\"survey cookie created\")}}surveyInit();window.addEventListener(\"gtmDataOnChange\",function(a){surveyInit()},!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":15
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=500,d=\"RollingCEBUA\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBUA?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":17
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .gtm-survey{\n    position:fixed;\n    left:0;\n    top:51px;\n    width:100%;\n    bottom:0;\n    height:100%;\n    z-index:10001;\n    background:#fff;\n  }\n  .gtm-survey__iframe{\n    width:100%;\n    height:100%;\n    border: none;\n  }\n  .gtm-survey__close{\n    width: 28px;\n    height: 28px;\n    background:#fff;\n    border-radius: 50%;\n    top: 27px;\n    right: 8px;\n    text-align: center;\n    position:absolute;\n    border: 1px solid #ccc;\n    line-height: 28px;\n    cursor: pointer;\n    color: #0098d0;\n    font-weight:bold;\n  }\n  .gtm-survey__close:before{\n    content:'X';\n  }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyRandomMax=8E4,surveyName=\"rollingCEBUA\";function gtmSurveyClose(){document.querySelector(\".js-gtm-survey\").style.display=\"none\";window.dataLayer=window.dataLayer||[];dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:surveyName})}\nfunction gtmSurveyCode(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",gtmSurveyClose);b.appendChild(a);return b}\nfunction generateUUID(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}function surveyRandomizer(a,b){return Math.floor(Math.random()*(1+b-a))+a}\nfunction setCookie(a,b,d){var c=new Date;c.setTime(c.getTime()+864E5*d);d=\"expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+\";\"+d+\";path\\x3d\/\"}function getCookie(a){a+=\"\\x3d\";for(var b=document.cookie.split(\";\"),d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a))return c.substring(a.length,c.length)}return\"\"}function getGTMData(a){a=[\"gtmData:\"+a];return localStorage.hasOwnProperty(a)?String(localStorage[a]):null}var currentPageArray=[\"listing\",\"ad_page\"];\nfunction surveyInit(){if(getCookie(\"surveyPopupInited\")!=surveyName\u0026\u0026!0===currentPageArray.includes(getGTMData(\"currentPage\"))\u0026\u0026\"1\"==this.surveyRandomizer(1,surveyRandomMax)){var a=getGTMData(\"currentCategoryId\"),b=getGTMData(\"adID\")||\"\",d=getCookie(\"user_id\"),c=getCookie(\"user_business_status\"),e=generateUUID();window.survey_id=e;a=\"https:\/\/www.surveymonkey.com\/r\/rollingCEBUA?user_id\\x3d\"+d+\"\\x26clm_session_id\\x3d\"+e+\"\\x26ad_id\\x3d\"+b+\"\\x26category_id\\x3d\"+a+\"\\x26platform\\x3drwd\\x26business_status\\x3d\"+\nc+\"\\x26survey_name\\x3d\"+surveyName;document.body.appendChild(gtmSurveyCode(a));window.dataLayer=window.dataLayer||[];dataLayer.push({gtmSurveyCLMSessionID:e,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:surveyName});setCookie(\"surveyPopupInited\",surveyName,365);console.log(\"survey cookie created\")}}surveyInit();window.addEventListener(\"gtmDataOnChange\",function(a){surveyInit()},!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":18
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=75,d=\"RollingCEBPT\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBPT?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":20
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .gtm-survey{\n    position:fixed;\n    left:0;\n    top:51px;\n    width:100%;\n    bottom:0;\n    height:100%;\n    z-index:10001;\n    background:#fff;\n  }\n  .gtm-survey__iframe{\n    width:100%;\n    height:100%;\n    border: none;\n  }\n  .gtm-survey__close{\n    width: 28px;\n    height: 28px;\n    background:#fff;\n    border-radius: 50%;\n    top: 27px;\n    right: 8px;\n    text-align: center;\n    position:absolute;\n    border: 1px solid #ccc;\n    line-height: 28px;\n    cursor: pointer;\n    color: #0098d0;\n    font-weight:bold;\n  }\n  .gtm-survey__close:before{\n    content:'X';\n  }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyRandomMax=6E3,surveyName=\"rollingCEBPT\";function gtmSurveyClose(){document.querySelector(\".js-gtm-survey\").style.display=\"none\";window.dataLayer=window.dataLayer||[];dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:surveyName})}\nfunction gtmSurveyCode(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",gtmSurveyClose);b.appendChild(a);return b}\nfunction generateUUID(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}function surveyRandomizer(a,b){return Math.floor(Math.random()*(1+b-a))+a}\nfunction setCookie(a,b,d){var c=new Date;c.setTime(c.getTime()+864E5*d);d=\"expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+\";\"+d+\";path\\x3d\/\"}function getCookie(a){a+=\"\\x3d\";for(var b=document.cookie.split(\";\"),d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a))return c.substring(a.length,c.length)}return\"\"}function getGTMData(a){a=[\"gtmData:\"+a];return localStorage.hasOwnProperty(a)?String(localStorage[a]):null}var currentPageArray=[\"listing\",\"ad_page\"];\nfunction surveyInit(){if(getCookie(\"surveyPopupInited\")!=surveyName\u0026\u0026!0===currentPageArray.includes(getGTMData(\"currentPage\"))\u0026\u0026\"1\"==this.surveyRandomizer(1,surveyRandomMax)){var a=getGTMData(\"currentCategoryId\"),b=getGTMData(\"adID\")||\"\",d=getCookie(\"user_id\"),c=getCookie(\"user_business_status\"),e=generateUUID();window.survey_id=e;a=\"https:\/\/www.surveymonkey.com\/r\/rollingCEBPT?user_id\\x3d\"+d+\"\\x26clm_session_id\\x3d\"+e+\"\\x26ad_id\\x3d\"+b+\"\\x26category_id\\x3d\"+a+\"\\x26platform\\x3drwd\\x26business_status\\x3d\"+\nc+\"\\x26survey_name\\x3d\"+surveyName;document.body.appendChild(gtmSurveyCode(a));window.dataLayer=window.dataLayer||[];dataLayer.push({gtmSurveyCLMSessionID:e,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:surveyName});setCookie(\"surveyPopupInited\",surveyName,365);console.log(\"survey cookie created\")}}surveyInit();window.addEventListener(\"gtmDataOnChange\",function(a){surveyInit()},!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":21
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=75,d=\"RollingCEBKZ\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBKZ?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":22
    },{
      "function":"__html",
      "priority":100,
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .gtm-survey{\n    position:fixed;\n    left:0;\n    top:51px;\n    width:100%;\n    bottom:0;\n    height:100%;\n    z-index:10001;\n    background:#fff;\n  }\n  .gtm-survey__iframe{\n    width:100%;\n    height:100%;\n    border: none;\n  }\n  .gtm-survey__close{\n    width: 28px;\n    height: 28px;\n    background:#fff;\n    border-radius: 50%;\n    top: 27px;\n    right: 8px;\n    text-align: center;\n    position:absolute;\n    border: 1px solid #ccc;\n    line-height: 28px;\n    cursor: pointer;\n    color: #0098d0;\n    font-weight:bold;\n  }\n  .gtm-survey__close:before{\n    content:'X';\n  }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyRandomMax=1E4,surveyName=\"rollingCEBKZ\";function gtmSurveyClose(){document.querySelector(\".js-gtm-survey\").style.display=\"none\";window.dataLayer=window.dataLayer||[];dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:surveyName})}\nfunction gtmSurveyCode(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",gtmSurveyClose);b.appendChild(a);return b}\nfunction generateUUID(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}function surveyRandomizer(a,b){return Math.floor(Math.random()*(1+b-a))+a}\nfunction setCookie(a,b,d){var c=new Date;c.setTime(c.getTime()+864E5*d);d=\"expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+\";\"+d+\";path\\x3d\/\"}function getCookie(a){a+=\"\\x3d\";for(var b=document.cookie.split(\";\"),d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a))return c.substring(a.length,c.length)}return\"\"}function getGTMData(a){a=[\"gtmData:\"+a];return localStorage.hasOwnProperty(a)?String(localStorage[a]):null}var currentPageArray=[\"listing\",\"ad_page\"];\nfunction surveyInit(){if(getCookie(\"surveyPopupInited\")!=surveyName\u0026\u0026!0===currentPageArray.includes(getGTMData(\"currentPage\"))\u0026\u0026\"1\"==this.surveyRandomizer(1,surveyRandomMax)){var a=getGTMData(\"currentCategoryId\"),b=getGTMData(\"adID\")||\"\",d=getCookie(\"user_id\"),c=getCookie(\"user_business_status\"),e=generateUUID();window.survey_id=e;a=\"https:\/\/www.surveymonkey.com\/r\/rollingCEBKZ?user_id\\x3d\"+d+\"\\x26clm_session_id\\x3d\"+e+\"\\x26ad_id\\x3d\"+b+\"\\x26category_id\\x3d\"+a+\"\\x26platform\\x3drwd\\x26business_status\\x3d\"+\nc+\"\\x26survey_name\\x3d\"+surveyName;document.body.appendChild(gtmSurveyCode(a));window.dataLayer=window.dataLayer||[];dataLayer.push({gtmSurveyCLMSessionID:e,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:surveyName});setCookie(\"surveyPopupInited\",surveyName,365);console.log(\"survey cookie created\")}}surveyInit();window.addEventListener(\"gtmDataOnChange\",function(a){surveyInit()},!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":24
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar etnhioJSpath=\"21165.js\",etnhioRandomizer=5;function ethnio___CreateCookie(c,b){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=c+'\\x3d[\"'+b+'\"];'+a+\"; path\\x3d\/\"}function ethnio___CheckCookie(c){c+=\"\\x3d\";for(var b=document.cookie.split(\";\"),a=0;a\u003Cb.length;a++){for(var d=b[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(c))return d.substring(c.length,d.length)}return null}\nfunction ethnio___UpdateCookie(c,b){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=c+\"\\x3d\"+b+\";\"+a+\"; path\\x3d\/\"}function ethnio___RunScript(c){var b=document.createElement(\"script\");b.type=\"text\/javascript\";b.src=(\"https:\"===document.location.protocol?\"https:\/\/\":\"http:\/\/\")+\"ethn.io\/\"+c;(document.getElementsByTagName(\"head\")[0]||document.getElementsByTagName(\"body\")[0]).appendChild(b)}etnhioRandomNb=100*Math.random();\nif(etnhioRandomNb\u003C=etnhioRandomizer)if(null===ethnio___CheckCookie(\"ethnioLoaded\"))ethnio___CreateCookie(\"ethnioLoaded\",etnhioJSpath),ethnio___RunScript(etnhioJSpath);else{var myEthnioCookie=JSON.parse(ethnio___CheckCookie(\"ethnioLoaded\"));-1===myEthnioCookie.indexOf(etnhioJSpath)\u0026\u0026(myEthnioCookie.push(etnhioJSpath),ethnio___UpdateCookie(\"ethnioLoaded\",JSON.stringify(myEthnioCookie)),ethnio___RunScript(etnhioJSpath))};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":99
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"800px\";b.style.height=\"640px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=1E3,d=\"RollingCEBUZ_Ru\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBUZRu?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":521
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+d+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],gtmSurveyCLMSessionID:window.survey_id,action_type:\"click_survey_close\",survey_name:d})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=d;b.style.width=\"800px\";b.style.height=\"640px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+\na+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");a.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}\nvar l=1E3,d=\"RollingCEBUZ_Oz\",h=!0;window.onload=function(){a:{var a=\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var e=0;e\u003Cb.length;e++){for(var c=b[e];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(d)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){e=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();window.survey_id=\nb;e=\"https:\/\/www.surveymonkey.com\/r\/RollingCEBUZOz?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+e+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],"+\"\\x26survey_name\\x3d\"+d;document.body.appendChild(g(e));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.trackingData.pageView.trackPage||\"\",survey_name:d});a.push(d);\na=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":522
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":26
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":32
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":36
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":46
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":47
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":67
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":74
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":129
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":130
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":133
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":134
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":135
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":136
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":301
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":451
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":472
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":473
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":474
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":475
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":476
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":477
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":478
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":479
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":480
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":482
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":483
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":484
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":485
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":486
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":487
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":488
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":489
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":490
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":491
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":492
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":493
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":513
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":523
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":524
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2357
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2397
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2400
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2403
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2404
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2408
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2409
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2415
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2424
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2426
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2437
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":2473
    },{
      "function":"__cl",
      "tag_id":2521
    },{
      "function":"__tl",
      "vtp_eventName":"gtm.timer",
      "vtp_interval":"60000",
      "vtp_limit":"1",
      "vtp_uniqueTriggerId":"9947551_2447",
      "tag_id":2522
    },{
      "function":"__tl",
      "vtp_eventName":"gtm.timer",
      "vtp_interval":"60000",
      "vtp_limit":"1",
      "vtp_uniqueTriggerId":"9947551_2460",
      "tag_id":2523
    },{
      "function":"__sdl",
      "vtp_verticalThresholdUnits":"PERCENT",
      "vtp_verticalThresholdsPercent":"80",
      "vtp_verticalThresholdOn":true,
      "vtp_triggerStartOption":"WINDOW_LOAD",
      "vtp_horizontalThresholdOn":false,
      "vtp_uniqueTriggerId":"9947551_2476",
      "vtp_enableTriggerStartOption":true,
      "tag_id":2524
    },{
      "function":"__sdl",
      "vtp_verticalThresholdUnits":"PERCENT",
      "vtp_verticalThresholdsPercent":"80",
      "vtp_verticalThresholdOn":true,
      "vtp_triggerStartOption":"WINDOW_LOAD",
      "vtp_horizontalThresholdOn":false,
      "vtp_uniqueTriggerId":"9947551_2477",
      "vtp_enableTriggerStartOption":true,
      "tag_id":2525
    },{
      "function":"__tl",
      "vtp_eventName":"gtm.timer",
      "vtp_interval":"60000",
      "vtp_limit":"1",
      "vtp_uniqueTriggerId":"9947551_2508",
      "tag_id":2526
    },{
      "function":"__sdl",
      "vtp_verticalThresholdUnits":"PERCENT",
      "vtp_verticalThresholdsPercent":"80",
      "vtp_verticalThresholdOn":true,
      "vtp_triggerStartOption":"WINDOW_LOAD",
      "vtp_horizontalThresholdOn":false,
      "vtp_uniqueTriggerId":"9947551_2509",
      "vtp_enableTriggerStartOption":true,
      "tag_id":2527
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"seCkOtomoto\",\"sell\"+ninjaPV.user_id);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":25
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n\t.surveyMonkeyGTMPopup button.close {\n\t\tfloat: right;\n\t\tmargin: 0px !important;\n\t\tfont-size: 22px;\n\t\tfont-weight: 700;\n\t\topacity: 0.4;\n\t\tcursor: pointer;\n\t}\n\n\timg#surveyMonkeyImageLogo {\n\t\theight: 20%;\n\t\twidth: 20%;\n\t\tpadding-top: 10px;\n\t}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURLSellers;surveyMonkeyURLSellers=user_business?\"https:\/\/www.surveymonkey.com\/r\/CARSellersB2CPL_w3\":\"https:\/\/www.surveymonkey.com\/r\/CARSellersC2CPL\";var surveyMonkeyNotShowSellers=\"PLCarBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCPOtomoto\",surveyMonkeySurveyNameSellers=surveyMonkeyURLSellers.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumberSellers=33;\nfunction surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}function surveyMonkeyReadCookie(b){b+=\"\\x3d\";for(var c=document.cookie.split(\";\"),a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return null}function surveyMonkeyCreateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a+\"; path\\x3d\/\"}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\"; path\\x3d\/\"}function surveyMonkeyEraseCookie(b){surveyMonkeyCreateCookie(b,\"\",-1)}function trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}var userIdSellers=parseInt(surveyMonkeyReadCookie(\"seCkOtomoto\").split(\"sell\")[1]);surveyMonkeyURLSellers=surveyMonkeyURLSellers+\"?user_id\\x3d\"+userIdSellers+\"\\x26platform\\x3d\"+ninjaPV.platform;\nvar box=bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURLSellers+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",show:!1});\nif(null!=surveyMonkeyReadCookie(surveyMonkeyCookieName)){var smCookieArray=JSON.parse(surveyMonkeyReadCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyNameSellers)\u0026\u0026-1===smCookieArray.indexOf(surveyMonkeyNotShowSellers)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyNameSellers),\nsurveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeyCreateCookie(surveyMonkeyCookieName,surveyMonkeySurveyNameSellers));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":27
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/PLCarBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCP\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=200;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+\nninjaPV.cat_l1_name+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026\n(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_name+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":28
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"seCk\",\"sell\"+ninjaPV.user_id);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":29
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n\t.surveyMonkeyGTMPopup button.close {\n\t\tfloat: right;\n\t\tmargin: 0px !important;\n\t\tfont-size: 22px;\n\t\tfont-weight: 700;\n\t\topacity: 0.4;\n\t\tcursor: pointer;\n\t}\n\n\timg#surveyMonkeyImageLogo {\n\t\theight: 20%;\n\t\twidth: 20%;\n\t\tpadding-top: 10px;\n\t}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURLSellers;surveyMonkeyURLSellers=user_business?\"https:\/\/pt.surveymonkey.com\/r\/CarSellersB2CPT-19May\":\"https:\/\/pt.surveymonkey.com\/r\/CARSellersCEB-17Nov\";var surveyMonkeyNotShowSellers=\"CARBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/carspt-statics.akamaized.net\/statics-carspt\/packed\/font\/2fea0e82a7918be7c05e03ac8807ee5c24.svg\",surveyMonkeyCookieName=\"smCPStandvirtual\",surveyMonkeySurveyNameSellers=surveyMonkeyURLSellers.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumberSellers=5;\nfunction surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}function surveyMonkeyReadCookie(b){b+=\"\\x3d\";for(var c=document.cookie.split(\";\"),a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return null}function surveyMonkeyCreateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a+\"; path\\x3d\/\"}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\"; path\\x3d\/\"}function surveyMonkeyEraseCookie(b){surveyMonkeyCreateCookie(b,\"\",-1)}function trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}var userIdSellers=parseInt(surveyMonkeyReadCookie(\"seCk\").split(\"sell\")[1]);surveyMonkeyURLSellers=surveyMonkeyURLSellers+\"?user_id\\x3d\"+userIdSellers+\"\\x26platform\\x3d\"+ninjaPV.platform;\nvar box=bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURLSellers+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",show:!1});\nif(null!=surveyMonkeyReadCookie(surveyMonkeyCookieName)){var smCookieArray=JSON.parse(surveyMonkeyReadCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyNameSellers)\u0026\u0026-1===smCookieArray.indexOf(surveyMonkeyNotShowSellers)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyNameSellers),\nsurveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeyCreateCookie(surveyMonkeyCookieName,surveyMonkeySurveyNameSellers));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":30
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/5.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/pt.surveymonkey.com\/r\/CARBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/carspt-statics.akamaized.net\/statics-carspt\/packed\/font\/2fea0e82a7918be7c05e03ac8807ee5c24.svg\",surveyMonkeyCookieName=\"smCP\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=20;function surveyMonkeyRandomizer(a,c){return Math.floor(Math.random()*(1+c-a))+a}\nfunction surveyMonkeyGetCookie(a){a+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var b=0;b\u003Cc.length;b++){for(var d=c[b];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return\"\"}function surveyMonkeySetCookie(a,c){var b=new Date;b.setTime(b.getTime()+18144E5);b=\"expires\\x3d\"+b.toUTCString();document.cookie=a+'\\x3d[\"'+c+'\"];'+b}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName});logStep(\"user-already-invited\");window.removeEventListener(\"beforeunload\",logUnloadStep)}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName});logStep(\"user-decided-to-close\");window.removeEventListener(\"beforeunload\",logUnloadStep)}function surveyMonkeyUpdateCookie(a,c){var b=new Date;b.setTime(b.getTime()+18144E5);b=\"expires\\x3d\"+b.toUTCString();document.cookie=a+\"\\x3d\"+c+\";\"+b}\nfunction logStep(a,c){\"object\"==typeof newrelic\u0026\u0026(a={step:a,survey:surveyMonkeySurveyName,version:1},c\u0026\u0026(a.message=c),newrelic.addPageAction(\"survey-step\",a))}function logIframeStep(){logStep(\"iframe-loaded\")}function logUnloadStep(){logStep(\"page-closed\");delete e.returnValue}\ntry{logStep(\"injecting-gtm-tag-started\");window.addEventListener(\"beforeunload\",logUnloadStep,{passive:!0});if(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)?1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)?(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe onLoad\\x3d\"logIframeStep()\" src\\x3d\"'+\nsurveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_name+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",onShown:function(){logStep(\"modal-shown\")},onHide:function(){logStep(\"modal-closed\")}}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray))):(logStep(\"user-not-picked\"),window.removeEventListener(\"beforeunload\",logUnloadStep)):(logStep(\"user-already-invited\"),window.removeEventListener(\"beforeunload\",logUnloadStep))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)?(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe onLoad\\x3d\"logIframeStep()\" src\\x3d\"'+\nsurveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_name+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",onShown:function(){logStep(\"modal-shown\")},onHide:function(){logStep(\"modal-closed\")}}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName)):(logStep(\"user-not-picked\"),window.removeEventListener(\"beforeunload\",logUnloadStep));logStep(\"injecting-gtm-tag-finished\")}catch(a){logStep(\"error\",a.message)};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":31
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"seCk\",\"sell\"+ninjaPV.user_id);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":33
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n\t.surveyMonkeyGTMPopup button.close {\n\t\tfloat: right;\n\t\tmargin: 0px !important;\n\t\tfont-size: 22px;\n\t\tfont-weight: 700;\n\t\topacity: 0.4;\n\t\tcursor: pointer;\n\t}\n\n\timg#surveyMonkeyImageLogo {\n\t\theight: 20%;\n\t\twidth: 20%;\n\t\tpadding-top: 10px;\n\t}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURLSellers;surveyMonkeyURLSellers=user_business?\"https:\/\/www.surveymonkey.com\/r\/CARSellersB2CCEB-19May\":\"https:\/\/www.surveymonkey.com\/r\/CARSellersC2CCEB-18Apr\";var surveyMonkeyNotShowSellers=\"CARBuyersCEB-18Apr\",surveyMonkeyTopLogo=\"http:\/\/blog.olx.ro\/wp-content\/uploads\/2018\/04\/logo_nobackground.png\",surveyMonkeyCookieName=\"smCPAutovit\",surveyMonkeySurveyNameSellers=surveyMonkeyURLSellers.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumberSellers=5;\nfunction surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}function surveyMonkeyReadCookie(b){b+=\"\\x3d\";for(var c=document.cookie.split(\";\"),a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return null}function surveyMonkeyCreateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a+\"; path\\x3d\/\"}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\"; path\\x3d\/\"}function surveyMonkeyEraseCookie(b){surveyMonkeyCreateCookie(b,\"\",-1)}function trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}var userIdSellers=parseInt(surveyMonkeyReadCookie(\"seCk\").split(\"sell\")[1]);surveyMonkeyURLSellers=surveyMonkeyURLSellers+\"?user_id\\x3d\"+userIdSellers+\"\\x26platform\\x3d\"+ninjaPV.platform;\nvar box=bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURLSellers+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",show:!1});\nif(null!=surveyMonkeyReadCookie(surveyMonkeyCookieName)){var smCookieArray=JSON.parse(surveyMonkeyReadCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyNameSellers)\u0026\u0026-1===smCookieArray.indexOf(surveyMonkeyNotShowSellers)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyNameSellers),\nsurveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeyCreateCookie(surveyMonkeyCookieName,surveyMonkeySurveyNameSellers));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":34
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/CARBuyersCEB-18Apr\",surveyMonkeyTopLogo=\"http:\/\/blog.olx.ro\/wp-content\/uploads\/2018\/04\/logo_nobackground.png\",surveyMonkeyCookieName=\"smCP\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=25;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+\nninjaPV.cat_l1_name+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026\n(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_name+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":35
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"seCkStoria\",\"sell\"+ninjaPV.user_id);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":39
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n\t.surveyMonkeyGTMPopup button.close {\n\t\tfloat: right;\n\t\tmargin: 0px !important;\n\t\tfont-size: 22px;\n\t\tfont-weight: 700;\n\t\topacity: 0.4;\n\t\tcursor: pointer;\n\t}\n\n\timg#surveyMonkeyImageLogo {\n\t\theight: 20%;\n\t\twidth: 20%;\n\t\tpadding-top: 10px;\n\t}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURLSellers;surveyMonkeyURLSellers=\"private\"!=ninjaPV.business_status?\"https:\/\/www.surveymonkey.com\/r\/RESellersB2CCEB-19May\":\"https:\/\/www.surveymonkey.com\/r\/RESellersC2CCEB-18Apr\";var surveyMonkeyNotShowSellers=\"REBuyersCEB-18Apr\",surveyMonkeyTopLogo=\"http:\/\/blog.olx.ro\/wp-content\/uploads\/2018\/04\/storia_logo_1.png\",surveyMonkeyCookieName=\"smCPStoria\",surveyMonkeySurveyNameSellers=surveyMonkeyURLSellers.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumberSellers=5;\nfunction surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}function surveyMonkeyReadCookie(b){b+=\"\\x3d\";for(var c=document.cookie.split(\";\"),a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return null}function surveyMonkeyCreateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a+\"; path\\x3d\/\"}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\"; path\\x3d\/\"}function surveyMonkeyEraseCookie(b){surveyMonkeyCreateCookie(b,\"\",-1)}function trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}var userIdSellers=parseInt(surveyMonkeyReadCookie(\"seCkStoria\").split(\"sell\")[1]);surveyMonkeyURLSellers=surveyMonkeyURLSellers+\"?user_id\\x3d\"+userIdSellers+\"\\x26platform\\x3d\"+ninjaPV.platform;\nvar box=bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURLSellers+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",show:!1});\nif(null!=surveyMonkeyReadCookie(surveyMonkeyCookieName)){var smCookieArray=JSON.parse(surveyMonkeyReadCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyNameSellers)\u0026\u0026-1===smCookieArray.indexOf(surveyMonkeyNotShowSellers)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyNameSellers),\nsurveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeyCreateCookie(surveyMonkeyCookieName,surveyMonkeySurveyNameSellers));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":40
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/REBuyersCEB-18Apr\",surveyMonkeyTopLogo=\"http:\/\/blog.olx.ro\/wp-content\/uploads\/2018\/04\/storia_logo_1.png\",surveyMonkeyCookieName=\"smCP\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=33;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+\nninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+\nsurveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":41
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"seCkImovirtual\",\"sell\"+ninjaPV.user_id);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":42
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n\t.surveyMonkeyGTMPopup button.close {\n\t\tfloat: right;\n\t\tmargin: 0px !important;\n\t\tfont-size: 22px;\n\t\tfont-weight: 700;\n\t\topacity: 0.4;\n\t\tcursor: pointer;\n\t}\n\n\timg#surveyMonkeyImageLogo {\n\t\theight: 20%;\n\t\twidth: 20%;\n\t\tpadding-top: 10px;\n\t}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURLSellers;surveyMonkeyURLSellers=\"private\"!=ninjaPV.business_status?\"https:\/\/pt.surveymonkey.com\/r\/RESellersB2CPTw3\":\"https:\/\/pt.surveymonkey.com\/r\/RESellersC2CPT\";var surveyMonkeyNotShowSellers=\"REBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/www.imovirtual.com\/frontera\/static\/media\/logo.8035707c.svg\",surveyMonkeyCookieName=\"smCPImovirtual\",surveyMonkeySurveyNameSellers=surveyMonkeyURLSellers.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumberSellers=8;\nfunction surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}function surveyMonkeyReadCookie(b){b+=\"\\x3d\";for(var c=document.cookie.split(\";\"),a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return null}function surveyMonkeyCreateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a+\"; path\\x3d\/\"}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\"; path\\x3d\/\"}function surveyMonkeyEraseCookie(b){surveyMonkeyCreateCookie(b,\"\",-1)}function trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}var userIdSellers=parseInt(surveyMonkeyReadCookie(\"seCkImovirtual\").split(\"sell\")[1]);surveyMonkeyURLSellers=surveyMonkeyURLSellers+\"?user_id\\x3d\"+userIdSellers+\"\\x26platform\\x3d\"+ninjaPV.platform;\nvar box=bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURLSellers+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",show:!1});\nif(null!=surveyMonkeyReadCookie(surveyMonkeyCookieName)){var smCookieArray=JSON.parse(surveyMonkeyReadCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyNameSellers)\u0026\u0026-1===smCookieArray.indexOf(surveyMonkeyNotShowSellers)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyNameSellers),\nsurveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeyCreateCookie(surveyMonkeyCookieName,surveyMonkeySurveyNameSellers));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":43
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/pt.surveymonkey.com\/r\/REBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/www.imovirtual.com\/frontera\/static\/media\/logo.8035707c.svg\",surveyMonkeyCookieName=\"smCP\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=100;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+\nninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+\nsurveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":44
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"seCkOtodom\",\"sell\"+ninjaPV.user_id);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":63
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/PLREBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/otodompl-staticstmp.akamaized.net\/statics-otodompl\/naspersclassifieds-regional\/verticalsre-atlas-web-otodompl\/static\/img\/logo-print.gif\",surveyMonkeyCookieName=\"smCP\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=200;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+\nninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+\nsurveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":64
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n\t.surveyMonkeyGTMPopup button.close {\n\t\tfloat: right;\n\t\tmargin: 0px !important;\n\t\tfont-size: 22px;\n\t\tfont-weight: 700;\n\t\topacity: 0.4;\n\t\tcursor: pointer;\n\t}\n\n\timg#surveyMonkeyImageLogo {\n\t\theight: 20%;\n\t\twidth: 20%;\n\t\tpadding-top: 10px;\n\t}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURLSellers;surveyMonkeyURLSellers=\"private\"!=ninjaPV.business_status?\"https:\/\/www.surveymonkey.com\/r\/RESellersB2CPLw3\":\"https:\/\/www.surveymonkey.com\/r\/RESellersC2CPL\";\nvar surveyMonkeyNotShowSellers=\"PLREBuyersCEB-17Nov\",surveyMonkeyTopLogo=\"https:\/\/otodompl-staticstmp.akamaized.net\/statics-otodompl\/naspersclassifieds-regional\/verticalsre-atlas-web-otodompl\/static\/img\/logo-print.gif\",surveyMonkeyCookieName=\"smCPOtodom\",surveyMonkeySurveyNameSellers=surveyMonkeyURLSellers.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumberSellers=10;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyReadCookie(b){b+=\"\\x3d\";for(var c=document.cookie.split(\";\"),a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return null}function surveyMonkeyCreateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a+\"; path\\x3d\/\"}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"; expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\"; path\\x3d\/\"}function surveyMonkeyEraseCookie(b){surveyMonkeyCreateCookie(b,\"\",-1)}function trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}\nfunction trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyNameSellers})}var userIdSellers=parseInt(surveyMonkeyReadCookie(\"seCkOtodom\").split(\"sell\")[1]);surveyMonkeyURLSellers=surveyMonkeyURLSellers+\"?user_id\\x3d\"+userIdSellers+\"\\x26platform\\x3d\"+ninjaPV.platform;\nvar box=bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURLSellers+'\" style\\x3d\"width:100%;height:420px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\",show:!1});\nif(null!=surveyMonkeyReadCookie(surveyMonkeyCookieName)){var smCookieArray=JSON.parse(surveyMonkeyReadCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyNameSellers)\u0026\u0026-1===smCookieArray.indexOf(surveyMonkeyNotShowSellers)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyNameSellers),\nsurveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumberSellers)\u0026\u0026(box.modal(\"show\"),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeyCreateCookie(surveyMonkeyCookieName,surveyMonkeySurveyNameSellers));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":66
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(a,c,e,f,d,b){a.hj=a.hj||function(){(a.hj.q=a.hj.q||[]).push(arguments)};a._hjSettings={hjid:1150197,hjsv:6};d=c.getElementsByTagName(\"head\")[0];b=c.createElement(\"script\");b.async=1;b.src=e+a._hjSettings.hjid+f+a._hjSettings.hjsv;d.appendChild(b)})(window,document,\"https:\/\/static.hotjar.com\/c\/hotjar-\",\".js?sv\\x3d\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":73
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\n\u003Cscript type=\"text\/gtmscript\" id=\"hs-script-loader\" async defer data-gtmsrc=\"\/\/js.hs-scripts.com\/5701406.js\"\u003E\u003C\/script\u003E\n\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":249
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript id=\"ze-snippet\" data-gtmsrc=\"https:\/\/static.zdassets.com\/ekr\/snippet.js?key=25a57eb2-64d7-4b89-b533-089827ac7154\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003EzE(\"webWidget\",\"setLocale\",\"ro\");\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.zESettings={webWidget:{analytics:!0,helpCenter:{originalArticleButton:!1,searchPlaceholder:{\"*\":\"Ce problema ai intampinat?\",ro:\"Ce problema ai intampinat?\"},title:{\"*\":\"Cauta un articol\",ro:\"Cauta un articol\"}}}};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":253
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cstyle type=\"text\/css\"\u003E\n    .gtm-survey {\n        position: fixed;\n        left: 50%;\n        top: 50%;\n        padding: 2px;\n        z-index: 10001;\n        background: #fff;\n        border: 5px solid #ccc;\n        transform: translate(-50%, -50%);\n        -webkit-box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n        box-shadow: 0 0 0 10000px rgba(0, 0, 0, 0.5);\n    }\n \n    .gtm-survey--in-arrow {\n        left: auto;\n        top: auto;\n        bottom: 20px;\n        right: 20px;\n        transform: none;\n    }\n \n    .gtm-survey__iframe {\n        width: 100%;\n        height: 100%;\n    }\n \n    .gtm-survey__close {\n        width: 28px;\n        height: 28px;\n        background: #fff;\n        border-radius: 50%;\n        top: -16px;\n        right: -16px;\n        text-align: center;\n        position: absolute;\n        border: 1px solid #ccc;\n        line-height: 26px;\n        cursor: pointer;\n        color: #0098d0;\n        font-weight: bold;\n    }\n \n    .gtm-survey__close:before {\n        content: 'X';\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function f(){document.querySelector('[data-surveyname\\x3d\"'+e+'\"]').style.display=\"none\";window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",survey_name:e})}function g(a){var b=document.createElement(\"div\");b.className=\"gtm-survey js-gtm-survey\";b.dataset.surveyname=e;b.style.width=\"600px\";b.style.height=\"475px\";b.innerHTML='\\x3ciframe class\\x3d\"gtm-survey__iframe\" src\\x3d\"'+a+'\"\\x3e\\x3c\/iframe\\x3e';a=document.createElement(\"div\");\na.className=\"gtm-survey__close js-gtm-survey-close\";a.addEventListener(\"click\",f);b.appendChild(a);h\u0026\u0026(b.className+=\" gtm-survey--in-arrow\");return b}function k(){var a=(new Date).getTime();window.performance\u0026\u0026\"function\"===typeof window.performance.now\u0026\u0026(a+=performance.now());var b=\"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx\".replace(\/[xy]\/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a\/16);return(\"x\"==b?c:c\u00263|8).toString(16)});return b}var l=1,e=\"9MG8BKC\",h=!0;window.onload=function(){a:{var a=\n\"surveyPopupInited\\x3d\";var b=decodeURIComponent(document.cookie);b=b.split(\";\");for(var d=0;d\u003Cb.length;d++){for(var c=b[d];\" \"==c.charAt(0);)c=c.substring(1);if(0==c.indexOf(a)){a=c.substring(a.length,c.length);break a}}a=\"\"}a=a?JSON.parse(a):[];if(-1==a.indexOf(e)\u0026\u0026\"1\"==Math.floor(Math.random()*(1+l-1))+1){d=window.category_id||\"\";c=window.adID||\"\";var f=\/user_id=([^;]+)\/i.test(document.cookie)?RegExp.$1:\"\";b=k();d=\"https:\/\/ru.surveymonkey.com\/r\/9MG8BKC?user_id\\x3d\"+f+\"\\x26clm_session_id\\x3d\"+b+\n\"\\x26ad_id\\x3d\"+c+\"\\x26category_id\\x3d\"+d+\"\\x26platform\\x3dDesktop\\x26business_status\\x3d\"+",["escape",["macro",55],8,16],";document.body.appendChild(g(d));window.dataLayer=window.dataLayer||[];window.dataLayer.push({gtmSurveyCLMSessionID:b,trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",survey_name:e});a.push(e);a=JSON.stringify(a);document.cookie=[\"surveyPopupInited\\x3d\",a,\"; path\\x3d\/\",\"; domain\\x3d.\"+window.session_domain].join(\"\")}}})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":494
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E$(document).mouseleave(function(){return dataLayer.push({event:\"mouseleave\"})});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":495
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Efunction ckCounterSetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a+\";domain\\x3d;path\\x3d\/\"}ckCounterSetCookie(\"cC2C\",\"sell\"+",["escape",["macro",65],8,16],");\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":515
    },{
      "function":"__html",
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={pages:[{name:\"page1\",elements:[{type:\"html\",name:\"question5\",html:'\\x3ch4\\x3e\\u041d\\u0443\\u0436\\u043d\\u0430 \\u043f\\u043e\\u043c\\u043e\\u0449\\u044c? \\u041f\\u043e\\u0437\\u0432\\u043e\\u043d\\u0438\\u0442\\u0435 \\u043d\\u0430 \\u0431\\u0435\\u0441\\u043f\\u043b\\u0430\\u0442\\u043d\\u044b\\u0439 \\u043d\\u043e\\u043c\\u0435\\u0440 \\x3ca href\\x3d\"tel:0 800 205 55 55\"\\x3e0 800 205 55 55\\x3c\/a\\x3e\\x3c\/h4\\x3e\\n\\x3cbr\\x3e\\n\\x3ch4\\x3e\\u0418\\u043b\\u0438 \\u043e\\u0441\\u0442\\u0430\\u0432\\u044c\\u0442\\u0435 \\u0441\\u0432\\u043e\\u0439 \\u043d\\u043e\\u043c\\u0435\\u0440 \\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0430, \\u0438 \\u043c\\u044b \\u043f\\u043e\\u0437\\u0432\\u043e\\u043d\\u0438\\u043c \\u0432\\u0430\\u043c \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 48 \\u0447\\u0430\\u0441\\u043e\\u0432**!\\x3c\/h4\\x3e\\n'},\n{type:\"text\",name:\"user_name\",title:\"\\u0418\\u043c\\u044f\",isRequired:!0},{type:\"text\",name:\"phone\",title:\"\\u041d\\u043e\\u043c\\u0435\\u0440 \\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0430\",isRequired:!0,inputType:\"tel\",inputMask:\"phone\"},{type:\"radiogroup\",name:\"question_category\",title:\"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f \\u0432\\u043e\\u043f\\u0440\\u043e\\u0441\\u0430\",isRequired:!0,hasOther:!0,choices:[{value:\"need_invoice\",text:\"\\u041d\\u0443\\u0436\\u0435\\u043d \\u0441\\u0447\\u0435\\u0442 \\u0434\\u043b\\u044f \\u0431\\u0435\\u0437\\u043d\\u0430\\u043b\\u0438\\u0447\\u043d\\u043e\\u0433\\u043e \\u0440\\u0430\\u0441c\\u0447\\u0435\\u0442\\u0430\"},\n{value:\"need_one_post\",text:\"\\u0418\\u043d\\u0442\\u0435\\u0440\\u0435\\u0441\\u0443\\u0435\\u0442 \\u0440\\u0430\\u0437\\u043c\\u0435\\u0449\\u0435\\u043d\\u0438\\u0435 1 \\u0432\\u0430\\u043a\\u0430\\u043d\\u0441\\u0438\\u0438, \\u043d\\u0435 \\u043f\\u0430\\u043a\\u0435\\u0442\\u0430\"},{value:\"need_consultation\",text:\"\\u041d\\u0443\\u0436\\u043d\\u0430 \\u043a\\u043e\\u043d\\u0441\\u0443\\u043b\\u044c\\u0442\\u0430\\u0446\\u0438\\u044f \\u043c\\u0435\\u043d\\u0435\\u0434\\u0436\\u0435\\u0440\\u0430 \\u043f\\u043e \\u0440\\u0430\\u0437\\u043c\\u0435\\u0449\\u0435\\u043d\\u0438\\u044e\/\\u043f\\u0440\\u043e\\u0434\\u0432\\u0438\\u0436\\u0435\\u043d\\u0438\\u044e \\u0432\\u0430\\u043a\\u0430\\u043d\\u0441\\u0438\\u0439\"}],\notherText:\"\\u0414\\u0440\\u0443\\u0433\\u043e\\u0435 (\\u043e\\u043f\\u0438\\u0448\\u0438\\u0442\\u0435)\"},{type:\"html\",name:\"question2\",html:\"\\x3ch6\\x3e*\\u041e\\u0431\\u044f\\u0437\\u0430\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0435 \\u043f\\u043e\\u043b\\u044f \\u0434\\u043b\\u044f \\u0437\\u0430\\u043f\\u043e\\u043b\\u043d\\u0435\\u043d\\u0438\\u044f\\x3c\/h6\\x3e\\n\\x3ch6\\x3e**\\u0410\\u043a\\u0442\\u0443\\u0430\\u043b\\u044c\\u043d\\u043e \\u0434\\u043b\\u044f \\u0437\\u0430\\u043f\\u0440\\u043e\\u0441\\u043e\\u0432, \\u043e\\u0442\\u043f\\u0440\\u0430\\u0432\\u043b\\u0435\\u043d\\u043d\\u044b\\u0445 \\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u043f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0443, \\u0441 09:00 \\u0434\\u043e 17:30. \\u041e\\u0442\\u0432\\u0435\\u0442\\u044b \\u0437\\u0430 \\u0437\\u0430\\u043f\\u0440\\u043e\\u0441\\u044b, \\u043e\\u0442\\u043f\\u0440\\u0430\\u0432\\u043b\\u0435\\u043d\\u043d\\u044b\\u0435 \\u0432 \\u043d\\u0435\\u0440\\u0430\\u0431\\u043e\\u0447\\u0438\\u0435 \\u0447\\u0430\\u0441\\u044b, \\u043c\\u043e\\u0433\\u0443\\u0442 \\u0437\\u0430\\u043d\\u044f\\u0442\\u044c \\u0431\\u043e\\u043b\\u044c\\u0448\\u0435 \\u0432\\u0440\\u0435\\u043c\\u0435\\u043d\\u0438.\\x3c\/h6\\x3e\"}]}]};\ndonkeyGo({name:\"OLX_UA Payment_start popup V2\",id:186,trigger:\"show\",display:\"popup\",mobile_display:\"top\",exposition:100,theme:\"olxeu\",countdown:0,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":528
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/OTOTMv1\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCPOtomotoTM\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=750;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+\nninjaPV.cat_l1_name+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+\n'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_name+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,\nsurveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2387
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.research.net\/r\/decyzje_uczestnikow_rynku_nieruchomosci_Otodom\",surveyMonkeyTopLogo=\"https:\/\/otodompl-staticstmp.akamaized.net\/statics-otodompl\/naspersclassifieds-regional\/verticalsre-atlas-web-otodompl\/static\/img\/logo-print.gif\",surveyMonkeyCookieName=\"smCPRECVDImp\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=200;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+\nninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+\nsurveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26platform\\x3d\"+ninjaPV.platform+\"\\x26category_id\\x3d\"+ninjaPV.cat_l1_id+\"\\x26ad_id\\x3d\"+ninjaPV.ad_id+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",\ntrackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2440
    },{
      "function":"__html",
      "metadata":["map"],
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={completedHtml:\"\\x3cb\\x3e\\u041d\\u0430\\u0439\\u0431\\u043b\\u0438\\u0436\\u0447\\u0438\\u043c \\u0447\\u0430\\u0441\\u043e\\u043c \\u043c\\u0438 \\u0432\\u0430\\u043c \\u0437\\u0430\\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0443\\u0454\\u043c\\u043e!\\x3c\/b\\x3e\",pages:[{name:\"page1\",elements:[{type:\"html\",name:\"question5\",html:\"\\x3cb\\x3e\\u0404 \\u0437\\u0430\\u043f\\u0438\\u0442\\u0430\\u043d\\u043d\\u044f? \\u041c\\u0438 \\u043d\\u0430 \\u043d\\u0438\\u0445 \\u0432\\u0456\\u0434\\u043f\\u043e\\u0432\\u0456\\u043c\\u043e!\\x3c\/b\\x3e\\n\\x3cbr\\x3e\\x3cbr\\x3e\\n\\x3cp\\x3e\\u041f\\u043e\\u0447\\u043d\\u0456\\u0442\\u044c \\u0437\\u0430\\u0440\\u043e\\u0431\\u043b\\u044f\\u0442\\u0438 \\u0437 OLX. \\u0417\\u0430\\u043b\\u0438\\u0448\\u0442\\u0435 \\u0441\\u0432\\u043e\\u0457 \\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0438, \\u0456 \\u043c\\u0438 \\u0434\\u043e\\u043f\\u043e\\u043c\\u043e\\u0436\\u0435\\u043c\\u043e \\u0432\\u0430\\u0448\\u043e\\u043c\\u0443 \\u0431\\u0456\\u0437\\u043d\\u0435\\u0441\\u0443 \\u0440\\u043e\\u0437\\u0432\\u0438\\u0432\\u0430\\u0442\\u0438\\u0441\\u044f \\u0442\\u0430 \\u043f\\u0440\\u0438\\u043d\\u043e\\u0441\\u0438\\u0442\\u0438 \\u043f\\u0440\\u0438\\u0431\\u0443\\u0442\\u043e\\u043a..\\x3c\/p\\x3e\"},\n{type:\"text\",name:\"user_name\",title:\"\\u0406\\u043c'\\u044f\",isRequired:!0},{type:\"text\",name:\"phone\",title:\"\\u041d\\u043e\\u043c\\u0435\\u0440 \\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0443\",isRequired:!0,inputType:\"tel\",inputMask:\"phone\"},{type:\"radiogroup\",name:\"question_category\",title:\"\\u0426\\u0456\\u043b\\u044c \\u0437\\u0430\\u044f\\u0432\\u043a\\u0438\",isRequired:!0,choices:[{value:\"need_ad\",text:\"\\u041f\\u043e\\u0434\\u0430\\u0442\\u0438 \\u043e\\u0433\\u043e\\u043b\\u043e\\u0448\\u0435\\u043d\\u043d\\u044f\"},{value:\"need_promotion\",\ntext:\"\\u041f\\u0440\\u043e\\u0441\\u0443\\u0432\\u0430\\u043d\\u043d\\u044f \\u0431\\u0456\\u0437\\u043d\\u0435\\u0441\\u0443\"}],otherText:\"\\u0414\\u0440\\u0443\\u0433\\u043e\\u0435 (\\u043e\\u043f\\u0438\\u0448\\u0438\\u0442\\u0435)\"},{type:\"text\",name:\"description\",title:\"\\u0417\\u0430\\u043f\\u0438\\u0442\\u0430\\u043d\\u043d\\u044f\",isRequired:!0},{type:\"html\",name:\"question2\",html:\"\\x3ch6\\x3e*\\u041e\\u0431\\u043e\\u0432'\\u044f\\u0437\\u043a\\u043e\\u0432\\u0456 \\u043f\\u043e\\u043b\\u044f \\u0434\\u043b\\u044f \\u0437\\u0430\\u043f\\u043e\\u0432\\u043d\\u0435\\u043d\\u043d\\u044f\\n\\x3cbr\\x3e\\n**\\u041c\\u0438 \\u043f\\u0440\\u0430\\u0446\\u044e\\u0454\\u043c\\u043e \\u0432 \\u0431\\u0443\\u0434\\u043d\\u0456 \\u0437 9.30 \\u0434\\u043e 18.00 \\u0456 \\u0437\\u0430\\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0443\\u0454\\u043c\\u043e \\u0432\\u0430\\u043c \\u044f\\u043a\\u043d\\u0430\\u0439\\u0448\\u0432\\u0438\\u0434\\u0448\\u0435. \\u0412\\u0456\\u0434\\u043f\\u043e\\u0432\\u0456\\u0434\\u044c \\u043d\\u0430 \\u0437\\u0430\\u044f\\u0432\\u043a\\u0438, \\u0437\\u0430\\u043b\\u0438\\u0448\\u0435\\u043d\\u0456 \\u0432 \\u043d\\u0435\\u0440\\u043e\\u0431\\u043e\\u0447\\u0456 \\u0433\\u043e\\u0434\\u0438\\u043d\\u0438, \\u043c\\u043e\\u0436\\u0435 \\u0437\\u0430\\u0439\\u043d\\u044f\\u0442\\u0438 \\u0431\\u0456\\u043b\\u044c\\u0448\\u0435 \\u0447\\u0430\\u0441\\u0443.\\x3c\/h6\\x3e\"}]}],\ncompleteText:\"\\u041d\\u0430\\u0434\\u0456\\u0441\\u043b\\u0430\\u0442\\u0438\"};donkeyGo({name:\"OLX_UA Help_Center popup\",id:196,trigger:\"show\",display:\"popup\",mobile_display:\"top\",exposition:100,theme:\"olxeu\",countdown:0,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2465
    },{
      "function":"__html",
      "metadata":["map"],
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={completedHtml:\"\\u0412 \\u0431\\u043b\\u0438\\u0436\\u0430\\u0439\\u0448\\u0435\\u0435 \\u0432\\u0440\\u0435\\u043c\\u044f \\u043c\\u044b \\u0432\\u0430\\u043c \\u043f\\u0435\\u0440\\u0435\\u0437\\u0432\\u043e\\u043d\\u0438\\u043c!\",pages:[{name:\"page1\",elements:[{type:\"html\",name:\"question5\",html:\"\\x3cb\\x3e\\u041e\\u0441\\u0442\\u0430\\u043b\\u0438\\u0441\\u044c \\u0432\\u043e\\u043f\\u0440\\u043e\\u0441\\u044b? \\u041c\\u044b \\u043d\\u0430 \\u043d\\u0438\\u0445 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0438\\u043c!\\x3c\/b\\x3e\\n\\x3cbr\\x3e\\x3cbr\\x3e\\n\\x3cp\\x3e\\u041d\\u0430\\u0447\\u043d\\u0438\\u0442\\u0435 \\u0437\\u0430\\u0440\\u0430\\u0431\\u0430\\u0442\\u044b\\u0432\\u0430\\u0442\\u044c \\u0441 OLX. \\u041e\\u0441\\u0442\\u0430\\u0432\\u044c\\u0442\\u0435 \\u0441\\u0432\\u043e\\u0438 \\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b, \\u0438 \\u043c\\u044b \\u043f\\u043e\\u043c\\u043e\\u0436\\u0435\\u043c \\u0432\\u0430\\u0448\\u0435\\u043c\\u0443 \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0443 \\u0440\\u0430\\u0437\\u0432\\u0438\\u0432\\u0430\\u0442\\u044c\\u0441\\u044f \\u0438 \\u043f\\u0440\\u0438\\u043d\\u043e\\u0441\\u0438\\u0442\\u044c \\u043f\\u0440\\u0438\\u0431\\u044b\\u043b\\u044c.\\x3c\/p\\x3e\\n\"},\n{type:\"text\",name:\"user_name\",title:\"\\u0418\\u043c\\u044f\",isRequired:!0},{type:\"text\",name:\"phone\",title:\"\\u041d\\u043e\\u043c\\u0435\\u0440 \\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0430\",isRequired:!0,inputType:\"tel\",inputMask:\"phone\"},{type:\"radiogroup\",name:\"question_category\",title:\"\\u0426\\u0435\\u043b\\u044c \\u0437\\u0430\\u044f\\u0432\\u043a\\u0438\",isRequired:!0,choices:[{value:\"need_ad\",text:\"\\u041f\\u043e\\u0434\\u0430\\u0442\\u044c \\u043e\\u0431\\u044a\\u044f\\u0432\\u043b\\u0435\\u043d\\u0438\\u0435\"},{value:\"need_promotion\",\ntext:\"\\u041f\\u0440\\u043e\\u0434\\u0432\\u0438\\u0436\\u0435\\u043d\\u0438\\u0435 \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0430\"}],otherText:\"\\u0414\\u0440\\u0443\\u0433\\u043e\\u0435 (\\u043e\\u043f\\u0438\\u0448\\u0438\\u0442\\u0435)\"},{type:\"text\",name:\"description\",title:\"\\u0412\\u043e\\u043f\\u0440\\u043e\\u0441\",isRequired:!0},{type:\"html\",name:\"question2\",html:\"\\x3ch6\\x3e*\\u041e\\u0431\\u044f\\u0437\\u0430\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0435 \\u043f\\u043e\\u043b\\u044f \\u0434\\u043b\\u044f \\u0437\\u0430\\u043f\\u043e\\u043b\\u043d\\u0435\\u043d\\u0438\\u044f\\n\\x3cbr\\x3e\\n**\\u041c\\u044b \\u0440\\u0430\\u0431\\u043e\\u0442\\u0430\\u0435\\u043c \\u043f\\u043e \\u0431\\u0443\\u0434\\u043d\\u044f\\u043c \\u0441 9.30 \\u0434\\u043e 18.00 \\u0438 \\u043f\\u0435\\u0440\\u0435\\u0437\\u0432\\u043e\\u043d\\u0438\\u043c \\u0432\\u0430\\u043c \\u0432 \\u043a\\u0440\\u0430\\u0442\\u0447\\u0430\\u0439\\u0448\\u0438\\u0435 \\u0441\\u0440\\u043e\\u043a\\u0438. \\u041e\\u0442\\u0432\\u0435\\u0442 \\u043d\\u0430 \\u0437\\u0430\\u044f\\u0432\\u043a\\u0438, \\u043e\\u0441\\u0442\\u0430\\u0432\\u043b\\u0435\\u043d\\u043d\\u044b\\u0435 \\u0432 \\u043d\\u0435\\u0440\\u0430\\u0431\\u043e\\u0447\\u0438\\u0435 \\u0447\\u0430\\u0441\\u044b, \\u043c\\u043e\\u0436\\u0435\\u0442 \\u0437\\u0430\\u043d\\u044f\\u0442\\u044c \\u0431\\u043e\\u043b\\u044c\\u0448\\u0435 \\u0432\\u0440\\u0435\\u043c\\u0435\\u043d\\u0438.\\x3c\/h6\\x3e\"}]}],\ncompleteText:\"\\u041e\\u0442\\u043f\\u0440\\u0430\\u0432\\u0438\\u0442\\u044c\"};donkeyGo({name:\"OLX_UA (RU) Help_Center popup_v2\",id:198,trigger:\"show\",display:\"popup\",mobile_display:\"top\",exposition:100,theme:\"olxeu\",countdown:0,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2467
    },{
      "function":"__html",
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={pages:[{name:\"page1\",elements:[{type:\"text\",name:\"name\",title:\"Name\"},{type:\"text\",name:\"phone\",title:\"Phone\"},{type:\"text\",name:\"email\",title:\"Email\"}]}]};donkeyGo({name:\"OLX_UA_Andrii_chat_test\",id:209,trigger:\"show\",display:\"chat\",mobile_display:\"top\",exposition:100,theme:\"olxeu\",countdown:0,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2482
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/OTOHMSN2\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCPOtomotoHM\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=5;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26channel\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+\nninjaPV.cat_l1_id+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+\n'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26channel\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_id+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,\nsurveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2497
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.surveymonkey.com\/r\/OTOHMT2\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCPOtomotoHM\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=5;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26channel\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+\nninjaPV.cat_l1_id+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+\n'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?user_id\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+\"\\x26channel\\x3d\"+ninjaPV.platform+\"\\x26cat\\x3d\"+ninjaPV.cat_l1_id+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,\nsurveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2498
    },{
      "function":"__html",
      "metadata":["map"],
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={completedHtml:\"\\u0412 \\u0431\\u043b\\u0438\\u0436\\u0430\\u0439\\u0448\\u0435\\u0435 \\u0432\\u0440\\u0435\\u043c\\u044f \\u043c\\u044b \\u0432\\u0430\\u043c \\u043f\\u0435\\u0440\\u0435\\u0437\\u0432\\u043e\\u043d\\u0438\\u043c!\",pages:[{name:\"page1\",elements:[{type:\"html\",name:\"question5\",html:\"\\x3cb\\x3e\\u041e\\u0441\\u0442\\u0430\\u043b\\u0438\\u0441\\u044c \\u0432\\u043e\\u043f\\u0440\\u043e\\u0441\\u044b? \\u041c\\u044b \\u043d\\u0430 \\u043d\\u0438\\u0445 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0438\\u043c!\\x3c\/b\\x3e\\n\\x3cbr\\x3e\\x3cbr\\x3e\\n\\x3cp\\x3e\\u041d\\u0430\\u0447\\u043d\\u0438\\u0442\\u0435 \\u0437\\u0430\\u0440\\u0430\\u0431\\u0430\\u0442\\u044b\\u0432\\u0430\\u0442\\u044c \\u0441 OLX. \\u041e\\u0441\\u0442\\u0430\\u0432\\u044c\\u0442\\u0435 \\u0441\\u0432\\u043e\\u0438 \\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b, \\u0438 \\u043c\\u044b \\u043f\\u043e\\u043c\\u043e\\u0436\\u0435\\u043c \\u0432\\u0430\\u0448\\u0435\\u043c\\u0443 \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0443 \\u0440\\u0430\\u0437\\u0432\\u0438\\u0432\\u0430\\u0442\\u044c\\u0441\\u044f \\u0438 \\u043f\\u0440\\u0438\\u043d\\u043e\\u0441\\u0438\\u0442\\u044c \\u043f\\u0440\\u0438\\u0431\\u044b\\u043b\\u044c.\\x3c\/p\\x3e\\n\"},\n{type:\"text\",name:\"user_name\",title:\"\\u0418\\u043c\\u044f\",isRequired:!0},{type:\"text\",name:\"phone\",title:\"\\u041d\\u043e\\u043c\\u0435\\u0440 \\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u0430\",isRequired:!0,inputType:\"tel\",inputMask:\"phone\"},{type:\"radiogroup\",name:\"question_category\",title:\"\\u0426\\u0435\\u043b\\u044c \\u0437\\u0430\\u044f\\u0432\\u043a\\u0438\",isRequired:!0,choices:[{value:\"need_ad\",text:\"\\u041f\\u043e\\u0434\\u0430\\u0442\\u044c \\u043e\\u0431\\u044a\\u044f\\u0432\\u043b\\u0435\\u043d\\u0438\\u0435\"},{value:\"need_promotion\",\ntext:\"\\u041f\\u0440\\u043e\\u0434\\u0432\\u0438\\u0436\\u0435\\u043d\\u0438\\u0435 \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0430\"}],otherText:\"\\u0414\\u0440\\u0443\\u0433\\u043e\\u0435 (\\u043e\\u043f\\u0438\\u0448\\u0438\\u0442\\u0435)\"},{type:\"text\",name:\"description\",title:\"\\u0412\\u043e\\u043f\\u0440\\u043e\\u0441\",isRequired:!0},{type:\"html\",name:\"question2\",html:\"\\x3ch6\\x3e*\\u041e\\u0431\\u044f\\u0437\\u0430\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0435 \\u043f\\u043e\\u043b\\u044f \\u0434\\u043b\\u044f \\u0437\\u0430\\u043f\\u043e\\u043b\\u043d\\u0435\\u043d\\u0438\\u044f\\n\\x3cbr\\x3e\\n**\\u041c\\u044b \\u0440\\u0430\\u0431\\u043e\\u0442\\u0430\\u0435\\u043c \\u043f\\u043e \\u0431\\u0443\\u0434\\u043d\\u044f\\u043c \\u0441 9.30 \\u0434\\u043e 18.00 \\u0438 \\u043f\\u0435\\u0440\\u0435\\u0437\\u0432\\u043e\\u043d\\u0438\\u043c \\u0432\\u0430\\u043c \\u0432 \\u043a\\u0440\\u0430\\u0442\\u0447\\u0430\\u0439\\u0448\\u0438\\u0435 \\u0441\\u0440\\u043e\\u043a\\u0438. \\u041e\\u0442\\u0432\\u0435\\u0442 \\u043d\\u0430 \\u0437\\u0430\\u044f\\u0432\\u043a\\u0438, \\u043e\\u0441\\u0442\\u0430\\u0432\\u043b\\u0435\\u043d\\u043d\\u044b\\u0435 \\u0432 \\u043d\\u0435\\u0440\\u0430\\u0431\\u043e\\u0447\\u0438\\u0435 \\u0447\\u0430\\u0441\\u044b, \\u043c\\u043e\\u0436\\u0435\\u0442 \\u0437\\u0430\\u043d\\u044f\\u0442\\u044c \\u0431\\u043e\\u043b\\u044c\\u0448\\u0435 \\u0432\\u0440\\u0435\\u043c\\u0435\\u043d\\u0438.\\x3c\/h6\\x3e\"}]}],\ncompleteText:\"\\u041e\\u0442\\u043f\\u0440\\u0430\\u0432\\u0438\\u0442\\u044c\"};donkeyGo({name:\"OLX_KZ (RU) Help_Center popup\",id:216,trigger:\"show\",display:\"popup\",mobile_display:\"top\",exposition:100,theme:\"olxeu\",countdown:0,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2507
    },{
      "function":"__html",
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={locale:\"ro\",title:{ro:'Vrem sa imbunatatim sectiunea de \"Ajutor\" pentru tine'},description:{ro:'Doar cu ajutorul tau putem scoate mereu la suprafata informatiile intr-adevar relevante. Ajuta-ne cu un raspuns sincer legat de experienta avuta in sectiunea de \"Ajutor OLX\". Sondajul dureaza maxim 2 minute.'},completedHtml:{ro:\"Multumim de raspunsuri. O sa punem informatia asta la treaba :)\"},pages:[{name:\"page1\",elements:[{type:\"rating\",name:\"question1\",title:\"Per total, cum ti s-a parut experienta de la Centrul de asistenta OLX de astazi?\",\nrateValues:[{value:1,text:\"1 - Foarte nemultumitoare\"},2,3,4,{value:5,text:\"5 - Foarte multumitoare\"}]}]},{name:\"page2\",elements:[{type:\"radiogroup\",name:\"question2\",title:\"Care a fost principalul scop al vizitei tale la Centrul de asistenta OLX de astazi?\",hasOther:!0,choices:[{value:\"item1\",text:\"Am dorit sa aflu notiunile de baza despre folosirea platformei\"},{value:\"item2\",text:\"Cunosc notiunile de baza, dar doream sa aflu mai multe\"},{value:\"item3\",text:\"Am venit pentru a afla cum sa rezolv personal o problema\"},\n{value:\"item4\",text:\"Am venit pentru a contacta asistenta pentru clienti\"},{value:\"item5\",text:\"Am venit ca urmare a unui tichet de asistenta anterior\"}],otherText:\"Vizita mea a avut un alt scop (descrie)\"}]},{name:\"page3\",elements:[{type:\"radiogroup\",name:\"question3\",title:\"Ti-ai atins astazi scopul propus?\",choices:[{value:\"item1\",text:\"Da\"},{value:\"item2\",text:\"Nu\"},{value:\"item3\",text:\"Nu sunt sigur(a)\"}]}]},{name:\"page4\",elements:[{type:\"comment\",name:\"question4\",visibleIf:'{question3} \\x3d \"item2\" or {question3} \\x3d \"item3\"',\ntitle:\"Ce informatie anume era neclara sau nu a acoperit toata problema? Linkul catre articolul incomplet sau cat mai multe detalii ar ajuta :)\"}],visibleIf:'{question3} \\x3d \"item2\" or {question3} \\x3d \"item3\"'},{name:\"page5\",elements:[{type:\"comment\",name:\"question5\",title:\"Ai o intrebare la care nu ai gasit raspuns in Centrul nostru de asistenta? Crezi ca si altor persoane le-ar fi util un raspuns? Te ascultam :)\"}]},{name:\"page6\",elements:[{type:\"comment\",name:\"question6\",title:\"Specifica orice alt feedback cu privire la Centrul nostru de asistenta:\"}]}],\nshowProgressBar:\"top\",startSurveyText:{ro:\"Start\"},pagePrevText:{ro:\"Inapoi\"},pageNextText:{ro:\"Inainte\"},completeText:{ro:\"Trimite raspunsurile\"}};donkeyGo({name:\"OLX-RO HC content quality\",id:213,trigger:\"show\",display:\"popup\",mobile_display:\"top\",exposition:5,theme:\"olxeu\",countdown:10,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2513
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.research.net\/r\/825JWCP\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCPOtomotoPF\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=30;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?userId\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',\nsize:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+\nsurveyMonkeyURL+\"?userId\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2516
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/bootbox.js\/4.4.0\/bootbox.min.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cstyle type=\"text\/css\"\u003E\n    .surveyMonkeyGTMPopup button.close {\n        float: right;\n        margin: 0px !important;\n        font-size: 22px;\n        font-weight: 700;\n        opacity: 0.4;\n        cursor: pointer;\n    }\n\n    img#surveyMonkeyImageLogo {\n        height: 20%;\n        width: 20%;\n        padding-top: 10px;\n    }\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar surveyMonkeyURL=\"https:\/\/www.research.net\/r\/DMTYRWC\",surveyMonkeyTopLogo=\"https:\/\/nowe.otomoto.pl\/images\/animations\/a-w_anim2-logo.svg\",surveyMonkeyCookieName=\"smCPOtomotoPF\",surveyMonkeySurveyName=surveyMonkeyURL.split(\"\/r\/\")[1],surveyMonkeyRandomizerNumber=30;function surveyMonkeyRandomizer(b,c){return Math.floor(Math.random()*(1+c-b))+b}\nfunction surveyMonkeyGetCookie(b){b+=\"\\x3d\";var c=decodeURIComponent(document.cookie);c=c.split(\";\");for(var a=0;a\u003Cc.length;a++){for(var d=c[a];\" \"==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(b))return d.substring(b.length,d.length)}return\"\"}function surveyMonkeySetCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+'\\x3d[\"'+c+'\"];'+a}\nfunction trackSurveyStart(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"start\"],action_type:\"click_survey_start\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}function trackSurveyClose(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({trackEvent:[\"click\",\"survey\",\"close\"],action_type:\"click_survey_close\",touch_point_page:window.ninjaPV.trackPage||\"\",survey_name:surveyMonkeySurveyName})}\nfunction surveyMonkeyUpdateCookie(b,c){var a=new Date;a.setTime(a.getTime()+18144E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=b+\"\\x3d\"+c+\";\"+a}\nif(0\u003CsurveyMonkeyGetCookie(surveyMonkeyCookieName).length){var smCookieArray=JSON.parse(surveyMonkeyGetCookie(surveyMonkeyCookieName));-1===smCookieArray.indexOf(surveyMonkeySurveyName)\u0026\u00261===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+surveyMonkeyURL+\"?userId\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',\nsize:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),smCookieArray.push(surveyMonkeySurveyName),surveyMonkeyUpdateCookie(surveyMonkeyCookieName,JSON.stringify(smCookieArray)))}else 1===surveyMonkeyRandomizer(1,surveyMonkeyRandomizerNumber)\u0026\u0026(bootbox.dialog({message:'\\x3cimg src\\x3d\"'+surveyMonkeyTopLogo+'\" id\\x3d\"surveyMonkeyImageLogo\" \/\\x3e\\x3ciframe src\\x3d\"'+\nsurveyMonkeyURL+\"?userId\\x3d\"+(ninjaPV.user_id||surveyMonkeyGetCookie(\"onap\").split(\"-\")[2])+'\" style\\x3d\"width:100%;height:640px\"\\x3e\\x3c\/iframe\\x3e',size:\"large\",closeButton:!0,className:\"surveyMonkeyGTMPopup\"}),trackSurveyStart(),document.getElementsByClassName(\"bootbox-close-button close\")[0].addEventListener(\"click\",trackSurveyClose),surveyMonkeySetCookie(surveyMonkeyCookieName,surveyMonkeySurveyName));\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2518
    },{
      "function":"__html",
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/surveydonkey.s3-eu-west-1.amazonaws.com\/prod\/donkeyGo.min.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Evar survey={locale:\"ro\",title:{ro:\"Te rug\\u0103m s\\u0103 ne acorzi c\\u00e2teva minute\"},description:\"Ajut\\u0103-ne s\\u0103 \\u00een\\u021belegem mai bine cum a afectat pandemia pia\\u021ba imobiliar\\u0103 din Rom\\u00e2nia. \\u00ce\\u021bi va lua maxim 5 minute s\\u0103 r\\u0103spunzi la \\u00eentreb\\u0103rile noastre.\",pages:[{name:\"page1\",elements:[{type:\"radiogroup\",name:\"question1\",title:\"Aveai \\u00een plan vreo tranzac\\u021bie imobiliar\\u0103 pentru acest an? \",choices:[{value:\"item1\",text:\"Pl\\u0103nuiam s\\u0103 cump\\u0103r o proprietate\"},\n{value:\"item2\",text:\"Pl\\u0103nuiam s\\u0103 v\\u00e2nd o proprietate\"},{value:\"item3\",text:\"Pl\\u0103nuiam s\\u0103 \\u00eenchiriez o proprietate de la cineva\"},{value:\"item4\",text:\"Pl\\u0103nuiam s\\u0103 dau \\u00een chirie o proprietate c\\u0103tre cineva\"},{value:\"item5\",text:\"Nu aveam \\u00een plan tranzac\\u021bii imobiliare\"}]}]},{name:\"page2\",elements:[{type:\"radiogroup\",name:\"question2\",title:\"Ce tip de proprietate e afectat\\u0103 de aceste planuri?\",choices:[{value:\"item1\",text:\"Apartament\"},{value:\"item2\",\ntext:\"Cas\\u0103\"},{value:\"item3\",text:\"Birou\"},{value:\"item4\",text:\"Teren\"},{value:\"item5\",text:\"Spa\\u021biu comercial\"}]}]},{name:\"page3\",elements:[{type:\"radiogroup\",name:\"question3\",visibleIf:'{question1} \\x3d \"item1\"',title:\"In ce stadiu al procesului de achizitie ai ajuns?\",hasOther:!0,choices:[{value:\"item1\",text:\"Mi-am identificat nevoile, cum ar fi num\\u0103rul de camere, suprafa\\u021ba total\\u0103 etc. \"},{value:\"item2\",text:\"Mi-am aflat bugetul disponibil\/op\\u021biunile de creditare aplicabile mie\"},\n{value:\"item3\",text:\"Am urm\\u0103rit anun\\u021burile imobiliare\"},{value:\"item4\",text:\"Am vizionat c\\u00e2teva propriet\\u0103\\u021bi\"},{value:\"item5\",text:\"Am identificat proprietatea dorit\\u0103\"},{value:\"item6\",text:\"Am semnat un pre-contract\"},{value:\"item7\",text:\"A\\u0219tept semn\\u0103tura final\\u0103 pentru \\u00eencheierea contractului\"}],otherText:\"Alt stadiu (care?)\"}]},{name:\"page4\",elements:[{type:\"radiogroup\",name:\"question4\",title:\"E posibil ca informa\\u021biile noi despre pandemia COVID-19 s\\u0103 \\u00ee\\u021bi influen\\u021beze planurile?\",\nchoices:[{value:\"item1\",text:\"da\"},{value:\"item2\",text:\"nu\"}]}]},{name:\"page5\",elements:[{type:\"radiogroup\",name:\"question5\",visibleIf:'{question1} \\x3d \"item1\"',title:\"\\u00cen ce fel e influen\\u021bat de pandemie momentul cump\\u0103r\\u0103rii pl\\u0103nuite de tine?\",hasOther:!0,choices:[{value:\"item1\",text:\"\\u00cen niciun fel\"},{value:\"item2\",text:\"M\\u0103 gr\\u0103besc s\\u0103 cump\\u0103r\"},{value:\"item3\",text:\"Pot am\\u00e2na \\u00eenc\\u0103 3 luni\"},{value:\"item4\",text:\"Pot am\\u00e2na \\u00eenc\\u0103 6 luni\"},\n{value:\"item5\",text:\"Probabil voi am\\u00e2na p\\u00e2n\\u0103 la 1 an\"},{value:\"item6\",text:\"Cel mai probabil voi renun\\u021ba cu totul la plan\"},{value:\"item7\",text:\"Probabil voi am\\u00e2na mai mult de 1 an\"}],otherText:\"\\u00cen alt fel (care?)\"}]},{name:\"page6\",elements:[{type:\"radiogroup\",name:\"question6\",visibleIf:'{question1} \\x3d \"item3\"',title:\"\\u00cen ce fel e influen\\u021bat de pandemie momentul \\u00eenchirierii pl\\u0103nuite de tine?\",hasOther:!0,choices:[{value:\"item1\",text:\"\\u00cen niciun fel\"},\n{value:\"item2\",text:\"M\\u0103 gr\\u0103besc s\\u0103 \\u00eenchiriez\"},{value:\"item3\",text:\"Pot am\\u00e2na \\u00eenc\\u0103 3 luni\"},{value:\"item4\",text:\"Pot am\\u00e2na \\u00eenc\\u0103 6 luni\"},{value:\"item5\",text:\"Probabil voi am\\u00e2na p\\u00e2n\\u0103 la 1 an\"},{value:\"item6\",text:\"Probabil voi am\\u00e2na mai mult de 1 an\"},{value:\"item7\",text:\"Cel mai probabil voi renun\\u021ba cu totul la plan\"}],otherText:\"\\u00cen alt fel (care?)\"}]},{name:\"page7\",elements:[{type:\"radiogroup\",name:\"question7\",visibleIf:'{question1} \\x3d \"item3\"',\ntitle:\"\\u00cen ce fel \\u00ee\\u021bi pot influen\\u021ba planurile informa\\u021biile despre COVID-19? \",hasOther:!0,choices:[{value:\"item1\",text:\"\\u00cen niciun fel\"},{value:\"item2\",text:\"M\\u0103 g\\u00e2ndesc s\\u0103 cump\\u0103r \\u00een loc s\\u0103 \\u00eenchiriez\"},{value:\"item3\",text:\"M\\u0103 g\\u00e2ndesc s\\u0103 \\u00eenchiriez \\u00een loc s\\u0103 cump\\u0103r\"},{value:\"item4\",text:\"M\\u0103 g\\u00e2ndesc s\\u0103 aleg o proprietate mai ieftin\\u0103\"},{value:\"item5\",text:\"M\\u0103 g\\u00e2ndesc s\\u0103 aleg o proprietate mai scump\\u0103\"},\n{value:\"item6\",text:\"M\\u0103 g\\u00e2ndesc s\\u0103 caut propriet\\u0103\\u021bi \\u00een alt\\u0103 zon\\u0103\"},{value:\"item7\",text:\"Iau \\u00een calcul alte criterii de c\\u0103utare (alt num\\u0103r de camere etc)\"},{value:\"item8\",text:\"Iau \\u00een calcul alt tip de proprietate (ex: apartament \\u00een loc de cas\\u0103)\"}],otherText:\"\\u00cen alt fel (care?)\"}]},{name:\"page8\",elements:[{type:\"radiogroup\",name:\"question8\",visibleIf:'{question1} \\x3d \"item1\"',title:\"Crezi c\\u0103 preturile propriet\\u0103\\u021bilor de cump\\u0103rat se vor modifica pe parcursul urm\\u0103torului an? \",\nchoices:[{value:\"item1\",text:\"Ar putea sc\\u0103dea pre\\u021burile\"},{value:\"item2\",text:\"Nu se vor schimba pre\\u021burile\"},{value:\"item3\",text:\"Ar putea cre\\u0219te pre\\u021burile\"},{value:\"item4\",text:\"E greu de spus acum\"}]}]},{name:\"page9\",elements:[{type:\"radiogroup\",name:\"question9\",visibleIf:'{question1} \\x3d \"item3\"',title:\"Crezi c\\u0103 preturile propriet\\u0103\\u021bilor de \\u00eenchiriat se vor modifica pe parcursul urm\\u0103torului an? \",choices:[{value:\"item1\",text:\"Ar putea sc\\u0103dea pre\\u021burile\"},\n{value:\"item2\",text:\"Nu se vor schimba pre\\u021burile\"},{value:\"item3\",text:\"Ar putea cre\\u0219te pre\\u021burile\"},{value:\"item4\",text:\"E greu de spus acum\"}]}]},{name:\"page10\",elements:[{type:\"radiogroup\",name:\"question10\",visibleIf:'{question1} \\x3d \"item1\"',title:\"Cum pl\\u0103nuie\\u0219ti s\\u0103 finan\\u021bezi achizi\\u021bia imobiliar\\u0103 din plan? \",hasOther:!0,choices:[{value:\"item1\",text:\"Am toat\\u0103 suma necesar\\u0103 pentru a \\u00eencheia tranzac\\u021bia\"},{value:\"item2\",text:\"Prin credit ipotecar, de achitarea c\\u0103ruia nu \\u00eemi fac griji\"},\n{value:\"item3\",text:\"Prin credit ipotecar, a c\\u0103rui achitare m\\u0103 \\u00eengrijoreaz\\u0103\"},{value:\"item4\",text:\"Prin \\u00eemprumut de la rude\"},{value:\"item5\",text:\"Prin rate la dezvoltator\"}],otherText:\"\\u00cen alt fel (care?)\"}]},{name:\"page11\",elements:[{type:\"radiogroup\",name:\"question11\",visibleIf:'{question1} \\x3d \"item3\"',title:\"Cum pl\\u0103nuie\\u0219ti s\\u0103 pl\\u0103te\\u0219ti chiria?\",hasOther:!0,choices:[{value:\"item1\",text:\"Am suma necesar\\u0103 pentru a \\u00eenchiria\"},{value:\"item2\",\ntext:\"Prin \\u00eemprumut, cum ar fi unul bancar\"},{value:\"item3\",text:\"Prin \\u00eemprumut de la rude\"},{value:\"item4\",text:\"Voi sta cu cineva \\u00een chirie \\u0219i vom \\u00eemp\\u0103r\\u021bi plata\"}],otherText:\"Altfel (cum?)\"}]},{name:\"page12\",elements:[{type:\"radiogroup\",name:\"question12\",visibleIf:'{question1} \\x3d \"item1\" or {question1} \\x3d \"item3\"',title:\"Iei \\u00een calcul accesarea serviciilor unui agent imobiliar? \",choices:[{value:\"item1\",text:\"da\"},{value:\"item2\",text:\"nu\"}]}]},{name:\"page13\",\nelements:[{type:\"radiogroup\",name:\"question13\",visibleIf:'{question1} \\x3d \"item1\"',title:\"Ce etape ale cump\\u0103r\\u0103rii ai \\u00een plan s\\u0103 \\u00eenchei \\u00een viitorul apropiat? \",hasOther:!0,choices:[{value:\"item1\",text:\"Exploratul ofertelor interesante\"},{value:\"item2\",text:\"Rezervarea ofertelor interesante\"},{value:\"item3\",text:\"Vizion\\u0103ri ale propriet\\u0103\\u021bilor\"},{value:\"item4\",text:\"Semnarea pre-contractului\"},{value:\"item5\",text:\"Semnarea actelor finale\"}],otherText:\"Altele (care?)\"}]},\n{name:\"page14\",elements:[{type:\"radiogroup\",name:\"question14\",visibleIf:'{question1} \\x3d \"item3\"',title:\"Ce etape ale \\u00eenchirierii ai \\u00een plan s\\u0103 \\u00eenchei \\u00een viitorul apropiat? \",hasOther:!0,choices:[{value:\"item1\",text:\"Exploratul ofertelor interesante\"},{value:\"item2\",text:\"Rezervarea ofertelor interesante\"},{value:\"item3\",text:\"Vizion\\u0103ri ale propriet\\u0103\\u021bilor\"},{value:\"item4\",text:\"Semnarea actelor finale\"}],otherText:\"Altele (care?)\"}]},{name:\"page15\",elements:[{type:\"radiogroup\",\nname:\"question15\",visibleIf:'{question1} \\x3d \"item1\"',title:\"Care dintre urm\\u0103torii factori \\u021bi-ar face mai u\\u0219oar\\u0103 decizia de a cump\\u0103ra o proprietate?\",hasOther:!0,choices:[{value:\"item1\",text:\"Vizionarea propriet\\u0103\\u021bii prin tur virtual\"},{value:\"item2\",text:\"Vizionarea propriet\\u0103\\u021bii \\u00eentr-un video de prezentare \"},{value:\"item3\",text:\"Posibilitatea de a stabili o videoconferin\\u021b\\u0103 cu proprietarul sau agentul\"},{value:\"item4\",text:\"Posibilitatea de a rezerva proprietatea online\"},\n{value:\"item5\",text:\"Posibilitatea de a semna un contract f\\u0103r\\u0103 s\\u0103 ies din cas\\u0103, doar cu mijloace online\"},{value:\"item6\",text:\"Posibilitatea de a ob\\u021bine un credit ipotecar online\"}],otherText:\"Al\\u021bi factori (care?)\"}]},{name:\"page16\",elements:[{type:\"radiogroup\",name:\"question16\",visibleIf:'{question1} \\x3d \"item3\"',title:\"Care dintre urm\\u0103torii factori \\u021bi-ar face mai u\\u0219oar\\u0103 decizia de a \\u00eenchiria o proprietate?\",hasOther:!0,choices:[{value:\"item1\",\ntext:\"Vizionarea propriet\\u0103\\u021bii prin tur virtual\"},{value:\"item2\",text:\"Vizionarea propriet\\u0103\\u021bii \\u00eentr-un video de prezentare \"},{value:\"item3\",text:\"Posibilitatea de a stabili o videoconferin\\u021b\\u0103 cu proprietarul sau agentul\"},{value:\"item4\",text:\"Posibilitatea de a rezerva proprietatea online\"},{value:\"item5\",text:\"Posibilitatea de a semna un contract f\\u0103r\\u0103 s\\u0103 ies din cas\\u0103, doar cu mijloace online\"}],otherText:\"Al\\u021bi factori (care?)\"}]},{name:\"page17\",\nelements:[{type:\"radiogroup\",name:\"question17\",visibleIf:'{question1} \\x3d \"item2\"',title:\"\\u00cen ce etap\\u0103 a v\\u00e2nz\\u0103rii e\\u0219ti \\u00een acest moment?\",hasOther:!0,choices:[{value:\"item1\",text:\"Am renovat proprietatea pentru a-i cre\\u0219te valoarea\"},{value:\"item2\",text:\"Am ales moduri \\u0219i locuri \\u00een care s\\u0103 promovez anun\\u021bul\"},{value:\"item3\",text:\"Caut un agent care s\\u0103 intermedieze \\u00eentregul proces\"},{value:\"item4\",text:\"Agentul imobiliar intermediaz\\u0103 \\u00eentregul proces\"},\n{value:\"item5\",text:\"Oferta mea e disponibil\\u0103 online acum\"},{value:\"item6\",text:\"Am un client foarte interesat\"},{value:\"item7\",text:\"Am un pre-contract semnat\"},{value:\"item8\",text:\"M\\u0103 preg\\u0103tesc s\\u0103 \\u00eenchei tranzac\\u021bia\"}],otherText:\"Alta (care?)\"}]},{name:\"page18\",elements:[{type:\"radiogroup\",name:\"question18\",visibleIf:'{question1} \\x3d \"item4\"',title:\" \\u00cen ce etap\\u0103 a \\u00eenchirierii e\\u0219ti \\u00een acest moment?\",hasOther:!0,choices:[{value:\"item1\",text:\"Am renovat proprietatea pentru a-i cre\\u0219te valoarea\"},\n{value:\"item2\",text:\"Am ales moduri \\u0219i locuri \\u00een care s\\u0103 promovez anun\\u021bul\"},{value:\"item3\",text:\"Caut un agent care s\\u0103 intermedieze \\u00eentregul proces\"},{value:\"item4\",text:\"Agentul intermediaz\\u0103 \\u00eentregul proces\"},{value:\"item5\",text:\"Oferta mea e disponibil\\u0103 online acum\"},{value:\"item6\",text:\"Am un client foarte interesat\"},{value:\"item7\",text:\"M\\u0103 preg\\u0103tesc s\\u0103 \\u00eenchei tranzac\\u021bia\"}],otherText:\"Alta (care?)\"}]},{name:\"page19\",elements:[{type:\"radiogroup\",\nname:\"question19\",visibleIf:'{question1} \\x3d \"item2\"',title:\"Crezi c\\u0103 pre\\u021burile propriet\\u0103\\u021bilor de v\\u00e2nzare se vor modifica pe parcursul urm\\u0103torului an? \",choices:[{value:\"item1\",text:\"Ar putea sc\\u0103dea pre\\u021burile\"},{value:\"item2\",text:\"Nu se vor schimba pre\\u021burile\"},{value:\"item3\",text:\"Ar putea cre\\u0219te pre\\u021burile\"},{value:\"item4\",text:\"E greu de spus acum\"}]}]},{name:\"page20\",elements:[{type:\"radiogroup\",name:\"question20\",visibleIf:'{question1} \\x3d \"item4\"',\ntitle:\"Crezi c\\u0103 pre\\u021burile propriet\\u0103\\u021bilor de \\u00eenchiriat se vor modifica pe parcursul urm\\u0103torului an? \",choices:[{value:\"item1\",text:\"Ar putea sc\\u0103dea pre\\u021burile\"},{value:\"item2\",text:\"Nu se vor schimba pre\\u021burile\"},{value:\"item3\",text:\"Ar putea cre\\u0219te pre\\u021burile\"},{value:\"item4\",text:\"E greu de spus acum\"}],otherText:\"E greu de spus acum\"}]},{name:\"page21\",elements:[{type:\"radiogroup\",name:\"question21\",visibleIf:'{question1} \\x3d \"item4\"',title:\"Publicarea unui anun\\u021b pe o platform\\u0103 de imobiliare\",\nhasOther:!0,choices:[{value:\"item1\",text:\"Primirea la vizionare a poten\\u021bialilor chiria\\u0219i\"},{value:\"item2\",text:\"Semnarea actelor finale\"}],otherText:\"Altele (care?)\"}]},{name:\"page22\",elements:[{type:\"radiogroup\",name:\"question22\",visibleIf:'{question1} \\x3d \"item2\"',title:\"Ce etape ale v\\u00e2nz\\u0103rii unei propriet\\u0103\\u021bi pl\\u0103nuie\\u0219ti s\\u0103 parcurgi \\u00een viitorul apropiat? \",hasOther:!0,choices:[{value:\"item1\",text:\"Publicarea unui anun\\u021b pe o platform\\u0103 de imobiliare\"},\n{value:\"item2\",text:\"Primirea la vizionare a poten\\u021bialilor cump\\u0103r\\u0103tori\"},{value:\"item3\",text:\"Semnarea unui pre-contract\"},{value:\"item4\",text:\"Semnarea actelor finale\"}],otherText:\"Altele (care?)\"}]},{name:\"page23\",elements:[{type:\"radiogroup\",name:\"question24\",visibleIf:'{question1} \\x3d \"item2\"',title:{\"default\":\"Care dintre urm\\u0103torii factori pot face mai simpl\\u0103 v\\u00e2nzarea unei proprit\\u0103\\u021bi? \",ro:\"Care dintre urm\\u0103torii factori pot face mai simpl\\u0103 v\\u00e2nzarea unei propriet\\u0103\\u021bi? \"},\nhasOther:!0,choices:[{value:\"item1\",text:\"Filmarea unui tur virtual al propriet\\u0103\\u021bii\"},{value:\"item2\",text:\"Filmarea unui video de prezentare a propriet\\u0103\\u021bii\"},{value:\"item3\",text:\"Posibilitatea de a stabili o videoconferin\\u021b\\u0103 cu proprietarul sau agentul\"},{value:\"item4\",text:\"Posibilitatea de a rezerva o proprietate online\"},{value:\"item5\",text:\"Posibilitatea de a semna un contract f\\u0103r\\u0103 ie\\u0219irea din cas\\u0103, doar cu mijloace digitale\"}],otherText:\"Altul (care?)\"}]},\n{name:\"page24\",elements:[{type:\"radiogroup\",name:\"question23\",visibleIf:'{question1} \\x3d \"item4\"',title:\"Care dintre urm\\u0103torii factori pot face mai simpl\\u0103 \\u00eenchirierea unei propriet\\u0103\\u021bi? \",hasOther:!0,choices:[{value:\"item1\",text:\"Filmarea unui tur virtual al propriet\\u0103\\u021bii\"},{value:\"item2\",text:\"Filmarea unui video de prezentare a propriet\\u0103\\u021bii\"},{value:\"item3\",text:\"Posibilitatea de a stabili o videoconferin\\u021b\\u0103 cu proprietarul sau agentul\"},{value:\"item4\",\ntext:\"Posibilitatea de a rezerva o proprietate online\"},{value:\"item5\",text:\"Posibilitatea de a semna un contract f\\u0103r\\u0103 ie\\u0219irea din cas\\u0103, doar cu mijloace digitale\"}],otherText:\"Altul (care?)\"}]},{name:\"page25\",elements:[{type:\"text\",name:\"question25\",visibleIf:'{question1} \\x3d \"item2\"',title:\"E ceva ce te preocup\\u0103 \\u00een mod special acum referitor la v\\u00e2nzarea unei propriet\\u0103\\u021bi c\\u0103tre cineva?\"}]},{name:\"page26\",elements:[{type:\"text\",name:\"question27\",visibleIf:'{question1} \\x3d \"item4\"',\ntitle:\"E ceva ce te preocup\\u0103 \\u00een mod special acum referitor la \\u00eenchirierea unei proprit\\u0103\\u021bi c\\u0103tre cineva?\"}]},{name:\"page27\",elements:[{type:\"text\",name:\"question28\",visibleIf:'{question1} \\x3d \"item1\"',title:\"E ceva ce te preocup\\u0103 \\u00een mod special acum referitor la cump\\u0103rarea unei propriet\\u0103\\u021bi de la cineva?\"}]},{name:\"page28\",elements:[{type:\"text\",name:\"question29\",visibleIf:'{question1} \\x3d \"item3\"',title:\"E ceva ce te preocup\\u0103 \\u00een mod special acum referitor la \\u00eenchirierea unei propriet\\u0103\\u021bi de la cineva?\"}]},\n{name:\"page29\",elements:[{type:\"radiogroup\",name:\"question30\",title:\"Te rug\\u0103m s\\u0103 alegi cuvintele care descriu cel mai bine situa\\u021bia ta actual\\u0103:\",choices:[{value:\"item1\",text:\"Locuiesc singur\/singur\\u0103\"},{value:\"item2\",text:\"Locuiesc al\\u0103turi de familia mea\"},{value:\"item3\",text:\"Locuiesc al\\u0103turi de p\\u0103rin\\u021bii mei\"},{value:\"item4\",text:\"Locuiesc al\\u0103turi de prietenii mei\"}]}]},{name:\"page30\",elements:[{type:\"radiogroup\",name:\"question31\",title:\"Te rug\\u0103m s\\u0103 alegi cuvintele care descriu cel mai bine situa\\u021bia ta locativ\\u0103.\",\nchoices:[{value:\"item1\",text:\"Am propriul apartament\"},{value:\"item2\",text:\"Am propria cas\\u0103\"},{value:\"item3\",text:\"Locuiesc la c\\u0103min\"},{value:\"item4\",text:\"\\u00cenchiriez un apartament de la cineva\"},{value:\"item5\",text:\"\\u00cenchiriez o cas\\u0103 de la cineva\"},{value:\"item6\",text:\"\\u00cenchiriez o camer\\u0103 de la cineva\"},{value:\"item7\",text:\"Stau \\u00een locuin\\u021ba familiei\"},{value:\"item8\",text:\"Alta (care?)\"}]}]},{name:\"page31\",elements:[{type:\"radiogroup\",name:\"question32\",title:\"Te identifici cu genul:\",\nchoices:[{value:\"item1\",text:\"masculin\"},{value:\"item2\",text:\"feminin\"}]}]},{name:\"page32\",elements:[{type:\"radiogroup\",name:\"question33\",title:\"Domiciliul t\\u0103u e \\u00eentr-un:\",choices:[{value:\"item1\",text:\"Ora\\u0219 de peste 200 de mii de locuitori\"},{value:\"item2\",text:\"Ora\\u0219 cu 100-199 de mii de locuitori \"},{value:\"item3\",text:\"Ora\\u0219 cu 40-99 de mii de locuitori \"},{value:\"item4\",text:\"Ora\\u0219 de p\\u00e2n\\u0103 la 49 de mii de locuitori \"},{value:\"item5\",text:\"Sat\"}]}]},{name:\"page33\",\nelements:[{type:\"radiogroup\",name:\"question34\",title:\"Statutul meu profesional este de: \",choices:[{value:\"item1\",text:\"Liber profesionist\/antreprenor\"},{value:\"item2\",text:\"Angajat cu norm\\u0103 \\u00eentreag\\u0103\"},{value:\"item3\",text:\"Angajat cu norm\\u0103 redus\\u0103\"},{value:\"item4\",text:\"Student\"},{value:\"item5\",text:\"Nu lucrez\"}]}]}],showProgressBar:\"top\",startSurveyText:\"Start\",pagePrevText:\"Inapoi\",pageNextText:\"Inainte\",completeText:\"Trimite raspunsurile\"};\ndonkeyGo({name:\"Storia RO Desktop\",id:210,trigger:\"show\",display:\"popup\",mobile_display:\"top\",exposition:20,theme:\"storia\",countdown:1,debug:!1},survey);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":2520
    }],
  "predicates":[{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"otomoto.pl"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"1"
    },{
      "function":"_cn",
      "arg0":["macro",2],
      "arg1":"platnosci\/ok"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"gtm.js"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"standvirtual.com"
    },{
      "function":"_cn",
      "arg0":["macro",2],
      "arg1":"pagamento\/ok"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"autovit.ro"
    },{
      "function":"_cn",
      "arg0":["macro",2],
      "arg1":"plata-prin-autovit\/ok"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"desktop"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.pt"
    },{
      "function":"_eq",
      "arg0":["macro",5],
      "arg1":"undefined"
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":".*-1-.*-.*",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"ad_page"
    },{
      "function":"_eq",
      "arg0":["macro",8],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",9],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",10],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",11],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",12],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",13],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",14],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"gtm.load"
    },{
      "function":"_eq",
      "arg0":["macro",15],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"posting_form"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.pt"
    },{
      "function":"_re",
      "arg0":["macro",3],
      "arg1":"ad_page|listing"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"https\\:\\\/\\\/www\\.standvirtual\\.com\\\/contapessoal\\\/pacotes\\\/",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",16],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",0],
      "arg1":"https:\/\/www.autovit.ro\/autoturisme\/?search%5Bnew_used%5D=on"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"listing"
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":".*-1-.*-.*"
    },{
      "function":"_eq",
      "arg0":["macro",18],
      "arg1":"from_listing"
    },{
      "function":"_cn",
      "arg0":["macro",19],
      "arg1":"sell"
    },{
      "function":"_eq",
      "arg0":["macro",20],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",21],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",22],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",23],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",24],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"imovirtual.com"
    },{
      "function":"_cn",
      "arg0":["macro",25],
      "arg1":"sell"
    },{
      "function":"_eq",
      "arg0":["macro",26],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"listing"
    },{
      "function":"_eq",
      "arg0":["macro",27],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",28],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",29],
      "arg1":"sell"
    },{
      "function":"_eq",
      "arg0":["macro",30],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",31],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",32],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",33],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",34],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",35],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",36],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"otodom.pl"
    },{
      "function":"_cn",
      "arg0":["macro",37],
      "arg1":"sell"
    },{
      "function":"_eq",
      "arg0":["macro",38],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",39],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"storia.ro"
    },{
      "function":"_cn",
      "arg0":["macro",40],
      "arg1":"sell"
    },{
      "function":"_eq",
      "arg0":["macro",41],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"region_id%5D=11"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"VirtualPageview"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"https:\/\/spot.olx.pl\/kokpit-pracodawcy\/moje-ogloszenia"
    },{
      "function":"_re",
      "arg0":["macro",42],
      "arg1":"browse|search",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",43],
      "arg1":"desktop"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"190"
    },{
      "function":"_cn",
      "arg0":["macro",45],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",5],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",9],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"gtm.dom"
    },{
      "function":"_eq",
      "arg0":["macro",45],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"reply_chat_sent"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.bg"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"606"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.pl"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"4"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.ro"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.ua"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"6"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.kz"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"olx.uz"
    },{
      "function":"_eq",
      "arg0":["macro",46],
      "arg1":"ru"
    },{
      "function":"_eq",
      "arg0":["macro",47],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"3"
    },{
      "function":"_eq",
      "arg0":["macro",48],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.uz"
    },{
      "function":"_eq",
      "arg0":["macro",46],
      "arg1":"oz"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"161"
    },{
      "function":"_eq",
      "arg0":["macro",49],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"57"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"1"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"9"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"31"
    },{
      "function":"_eq",
      "arg0":["macro",50],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"661"
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"my_ads_active"
    },{
      "function":"_eq",
      "arg0":["macro",51],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"67"
    },{
      "function":"_re",
      "arg0":["macro",52],
      "arg1":"(listing|ad_impressions)",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",53],
      "arg1":"306"
    },{
      "function":"_eq",
      "arg0":["macro",54],
      "arg1":"292"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"help.olx.ua\\\/hc\\\/uk\\\/articles\\\/(360011216820|360000739369|212179945|206715799)"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"help.olx.ua\\\/hc\\\/ru\\\/articles\\\/(360011216820|360000739369|212179945|206715799)"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"https:\/\/help.olx.kz\/hc\/ru\/articles\/(360044360734|360044360894|360044886653|360044360634)"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.bg"
    },{
      "function":"_eq",
      "arg0":["macro",56],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",57],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",58],
      "arg1":"undefined"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.pl"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.ro"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.ua"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"m.olx.kz"
    },{
      "function":"_re",
      "arg0":["macro",3],
      "arg1":"multipay_page|my_account"
    },{
      "function":"_eq",
      "arg0":["macro",59],
      "arg1":"undefined"
    },{
      "function":"_eq",
      "arg0":["macro",60],
      "arg1":"undefined"
    },{
      "function":"_re",
      "arg0":["macro",3],
      "arg1":"listing|my_ads_active|ad_page"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"ad_page"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"mystoria.ro"
    },{
      "function":"_re",
      "arg0":["macro",3],
      "arg1":".*"
    },{
      "function":"_re",
      "arg0":["macro",3],
      "arg1":"listing|my_ads_active"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"myimovirtual.pt"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"myotodom.pl"
    },{
      "function":"_eq",
      "arg0":["macro",61],
      "arg1":"undefined"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"https\\:\\\/\\\/www\\.otomoto\\.pl\\\/mojekonto\\\/statystyki\\\/",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",55],
      "arg1":"business"
    },{
      "function":"_eq",
      "arg0":["macro",44],
      "arg1":"29"
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"my_ads"
    },{
      "function":"_eq",
      "arg0":["macro",55],
      "arg1":"private"
    },{
      "function":"_cn",
      "arg0":["macro",62],
      "arg1":"sell"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"http.*\\\/\\\/www\\.olx\\.ro\\\/(myaccount)"
    },{
      "function":"_cn",
      "arg0":["macro",52],
      "arg1":"reply_chat_page"
    },{
      "function":"_re",
      "arg0":["macro",44],
      "arg1":"36|3|899|37|891|903"
    },{
      "function":"_eq",
      "arg0":["macro",63],
      "arg1":"logged"
    },{
      "function":"_cn",
      "arg0":["macro",64],
      "arg1":"Хочу купить с OLX доставкой"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"gtm.click"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"payment_start"
    },{
      "function":"_eq",
      "arg0":["macro",54],
      "arg1":"84"
    },{
      "function":"_re",
      "arg0":["macro",3],
      "arg1":"posting_success"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"mouseleave"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"gtm.timer"
    },{
      "function":"_re",
      "arg0":["macro",66],
      "arg1":"(^$|((^|,)9947551_2447($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"gtm.scrollDepth"
    },{
      "function":"_re",
      "arg0":["macro",66],
      "arg1":"(^$|((^|,)9947551_2476($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",66],
      "arg1":"(^$|((^|,)9947551_2460($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",66],
      "arg1":"(^$|((^|,)9947551_2477($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",65],
      "arg1":"367556145"
    },{
      "function":"_re",
      "arg0":["macro",66],
      "arg1":"(^$|((^|,)9947551_2508($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",66],
      "arg1":"(^$|((^|,)9947551_2509($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"ajutor.olx.ro"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"help_center"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"https:\/\/www.otomoto.pl\/platnosci\/ok\/postpay\/"
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"multipay_confirmation_page"
    },{
      "function":"_eq",
      "arg0":["macro",67],
      "arg1":"desktop"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"https:\/\/www.otomoto.pl\/platnosci\/ok\/account\/"
    }],
  "rules":[
    [["if",0,1,2,3],["add",15]],
    [["if",1,3,4,5],["add",16]],
    [["if",1,3,6,7],["add",17]],
    [["if",8,9,10,12,13,14,15,16,17,18,19,20],["unless",11],["add",18]],
    [["if",8,9,10,13,14,15,16,17,18,19,20],["unless",11,21,22],["add",18]],
    [["if",10,13,23,24],["unless",11],["add",19,9]],
    [["if",20,25],["add",20]],
    [["if",6,26,28],["unless",11,27],["add",21]],
    [["if",0,12,14,20,26,30,32,33,34,35,36],["unless",29,31],["add",22]],
    [["if",20,26,37,39,40,41,42],["unless",29,38],["add",23]],
    [["if",4,12,14,20,26,30,33,44,45,46,47],["unless",29,43],["add",24]],
    [["if",6,12,14,20,26,30,33,48,49,50],["unless",29,43],["add",25]],
    [["if",20,26,40,41,42,51,53,54],["unless",29,52],["add",26]],
    [["if",20,26,40,41,42,55,57],["unless",29,56],["add",27]],
    [["if",14,20,26,37,39,45,58],["unless",21,29],["add",28]],
    [["if",14,26,37,39,45,58,59],["unless",21,29],["add",28]],
    [["if",3,60],["add",29]],
    [["if",9,61,62,63,64,65,66,67,68],["unless",21],["add",30]],
    [["if",9,10,12,13,14,62,63,68,69],["add",31]],
    [["if",9,10,13,14,62,63,69,70],["add",32]],
    [["if",61,62,64,65,67,68,71,72],["unless",21],["add",33]],
    [["if",10,12,14,62,68,69,71,72],["add",34]],
    [["if",10,14,62,69,70,71,72],["add",35]],
    [["if",61,62,64,65,67,68,73,74],["unless",21],["add",36]],
    [["if",10,12,14,62,68,69,73,74],["add",37]],
    [["if",10,14,62,69,70,73,74],["add",38]],
    [["if",61,62,64,65,67,68,74,75],["unless",21],["add",39]],
    [["if",10,12,14,62,68,69,74,75],["add",40]],
    [["if",10,14,62,69,70,74,75],["add",41]],
    [["if",61,62,64,65,67,68,76,77],["unless",21],["add",42]],
    [["if",10,12,14,62,68,69,76,77],["add",43]],
    [["if",10,14,62,69,70,76,77],["add",44]],
    [["if",61,62,64,65,67,68,77,78],["unless",21],["add",45]],
    [["if",10,12,14,62,68,69,77,78],["add",46]],
    [["if",10,14,62,69,70,77,78],["add",47]],
    [["if",61,62,64,65,67,68,77,79,80],["unless",21],["add",48]],
    [["if",10,12,14,62,68,69,77,79,80],["add",49]],
    [["if",10,14,62,69,70,77,79,80],["add",50]],
    [["if",8,10,14,68,69,73,81,83],["unless",11,21,22,82],["add",51]],
    [["if",10,24,80,84],["unless",11],["add",52]],
    [["if",10,24,84,85],["unless",11],["add",53]],
    [["if",0,14,20,26,32,33,34,35,86],["unless",21,29],["add",54]],
    [["if",0,14,20,26,32,35,36,87],["unless",21,29,86,88,89,90,91],["add",55]],
    [["if",4,14,20,26,44,45,92],["unless",21,29,93],["add",56]],
    [["if",0,20,26,31,32,87,94],["add",57]],
    [["if",0,20,26,31,32,87],["unless",21,86,88,89,90,91],["add",57]],
    [["if",4,14,20,26,43,44,45,92,94],["add",58]],
    [["if",4,12,14,20,26,43,44,45,92],["unless",93],["add",58]],
    [["if",6,14,20,26,48,95],["unless",21,29,96],["add",59]],
    [["if",6,14,20,26,43,48,94,95],["add",60]],
    [["if",6,14,20,26,43,48,95],["unless",21,96],["add",60]],
    [["if",4,14,20,26,44,45,92,93],["unless",21,29],["add",61]],
    [["if",0,14,20,26,32,35,36,86,87],["unless",21,29],["add",62]],
    [["if",6,14,20,26,48,95,96],["unless",21,29],["add",63]],
    [["if",8,10,68,69,73,82,97],["unless",11,21,22],["add",64]],
    [["if",8,10,12,68,69,73,82],["unless",11],["add",64]],
    [["if",8,10,12,68,73,98],["unless",11],["add",65]],
    [["if",8,10,12,68,73,99],["unless",11],["add",65]],
    [["if",8,10,68,73,98],["unless",11,21,22],["add",65]],
    [["if",8,10,68,73,99],["unless",11,21,22],["add",65]],
    [["if",3],["add",66]],
    [["if",3,100],["add",67]],
    [["if",3,101],["add",68]],
    [["if",20],["add",69,70,72]],
    [["if",3,102],["add",71]],
    [["if",8,10,12,68,69,71],["unless",11],["add",0]],
    [["if",8,10,68,69,71],["unless",11,21,22],["add",0]],
    [["if",10,24,103],["unless",11],["add",1]],
    [["if",8,10,12,68,73,81,104,105,106],["unless",11],["add",2]],
    [["if",8,10,68,73,81,104,105,106],["unless",11,21,22],["add",2]],
    [["if",10,24,81,105,107],["unless",11],["add",3]],
    [["if",8,10,12,68,69,75],["unless",11],["add",4]],
    [["if",8,10,68,69,75],["unless",11,21,22],["add",4]],
    [["if",10,24,108],["unless",11],["add",5]],
    [["if",8,10,12,68,69,76],["unless",11],["add",6]],
    [["if",8,10,68,69,76],["unless",11,21,22],["add",6]],
    [["if",10,24,109],["unless",11],["add",7]],
    [["if",8,9,10,12,13,14,15,16,17,18,19,68],["unless",11],["add",8]],
    [["if",8,9,10,13,14,15,16,17,18,19,68],["unless",11,21,22],["add",8]],
    [["if",8,10,12,68,78],["unless",11],["add",10]],
    [["if",8,10,68,78],["unless",11,21,22],["add",10]],
    [["if",10,24,110],["unless",11],["add",11]],
    [["if",0,111],["add",73]],
    [["if",0,26,31,32,36,87,112,113,114],["add",74]],
    [["if",0,26,30,32,36,87,112,113,115],["unless",29,31],["add",75]],
    [["if",4,111],["add",76]],
    [["if",4,14,26,43,44,45,92,114],["add",77]],
    [["if",4,26,30,44,45,92,115],["unless",29,43],["add",78]],
    [["if",6,111],["add",79]],
    [["if",6,14,26,33,43,48,114],["add",80]],
    [["if",6,26,30,48,95,115],["unless",29,43],["add",81]],
    [["if",55,111],["add",82]],
    [["if",55,56,57,118],["add",83]],
    [["if",26,28,41,42,55,57],["unless",29,56],["add",84]],
    [["if",37,111],["add",85]],
    [["if",37,38,39,41,42,118],["add",86]],
    [["if",26,28,37,39,41,42],["unless",29,38],["add",87]],
    [["if",51,111],["add",88]],
    [["if",26,28,51,53,121],["unless",29,52],["add",89]],
    [["if",41,42,51,52,53,54,118],["add",90]],
    [["if",20,122,123],["add",91]],
    [["if",4,14,20,26,44,45,69,92,124],["unless",11,21],["add",12]],
    [["if",10,68,75,125,127],["unless",11,126],["add",92]],
    [["if",8,10,68,128],["add",93]],
    [["if",68,76,129,130,131],["add",94]],
    [["if",76,131,132,133],["add",94]],
    [["if",62,76,77,134],["add",95]],
    [["if",73,126,135,136],["add",96]],
    [["if",8,10,68,79,80],["unless",11,21,22],["add",13]],
    [["if",8,10,12,68,79,80],["unless",11],["add",13]],
    [["if",8,10,12,68,79,85],["unless",11],["add",14]],
    [["if",8,10,68,79,85],["unless",11,21,22],["add",14]],
    [["if",62,76,137],["add",97]],
    [["if",0,14,20,26,32,36,87,112,113],["unless",21,29],["add",98]],
    [["if",20,26,40,51,53,121],["unless",29,120],["add",99]],
    [["if",100,138,139],["add",100]],
    [["if",100,140,141],["add",100]],
    [["if",101,138,142],["add",101]],
    [["if",101,140,143],["add",101]],
    [["if",62,76,115,144],["add",102]],
    [["if",0,14,20,26,32,36,40,89,112],["unless",29],["add",103,104]],
    [["if",0,14,20,26,32,36,40,90,112],["unless",29],["add",103,104]],
    [["if",0,14,20,26,32,36,40,91,112],["unless",29],["add",103,104]],
    [["if",0,14,20,26,32,36,40,88,112],["unless",29],["add",103,104]],
    [["if",102,138,145],["add",105]],
    [["if",102,140,146],["add",105]],
    [["if",62,75,147,148],["add",106]],
    [["if",14,20,26,31,32,36,87,112,113,123,149,150,151],["unless",29],["add",107]],
    [["if",14,20,26,31,32,36,87,112,113,126,150,151,152],["unless",29],["add",108]],
    [["if",28,55,62],["add",109]],
    [["if",116,117],["block",82,83,84]],
    [["if",117,119],["block",85,86,87]],
    [["if",117,120],["block",88,89,90]]]
},
"runtime":[]




};
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var ca,da="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},fa;if("function"==typeof Object.setPrototypeOf)fa=Object.setPrototypeOf;else{var ha;a:{var ia={Hf:!0},ja={};try{ja.__proto__=ia;ha=ja.Hf;break a}catch(a){}ha=!1}fa=ha?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var ka=fa,la=this||self,ma=/^[\w+/_-]+[=]{0,2}$/,na=null;var pa=function(){},qa=function(a){return"function"==typeof a},g=function(a){return"string"==typeof a},ra=function(a){return"number"==typeof a&&!isNaN(a)},sa=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},n=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},wa=function(a,b){if(a&&sa(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},xa=function(a,b){if(!ra(a)||
!ra(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},za=function(a,b){for(var c=new ya,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},Aa=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Ba=function(a){return Math.round(Number(a))||0},Ca=function(a){return"false"==String(a).toLowerCase()?!1:!!a},Da=function(a){var b=[];if(sa(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Fa=function(a){return a?
a.replace(/^\s+|\s+$/g,""):""},Ga=function(){return(new Date).getTime()},ya=function(){this.prefix="gtm.";this.values={}};ya.prototype.set=function(a,b){this.values[this.prefix+a]=b};ya.prototype.get=function(a){return this.values[this.prefix+a]};
var Ha=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Ia=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},Ja=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ka=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},La=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},Ma=function(a,b){for(var c={},d=c,e=a.split("."),f=0;f<e.length-1;f++)d=d[e[f]]={};d[e[e.length-1]]=b;return c},Na=function(a){var b=
[];Aa(a,function(c,d){10>c.length&&d&&b.push(c)});return b.join(",")};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Oa=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Pa=function(a){if(null==a)return String(a);var b=Oa.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Qa=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Ra=function(a){if(!a||"object"!=Pa(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Qa(a,"constructor")&&!Qa(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Qa(a,b)},C=function(a,b){var c=b||("array"==Pa(a)?[]:{}),d;for(d in a)if(Qa(a,d)){var e=a[d];"array"==Pa(e)?("array"!=Pa(c[d])&&(c[d]=[]),c[d]=C(e,c[d])):Ra(e)?(Ra(c[d])||(c[d]={}),c[d]=C(e,c[d])):c[d]=e}return c};
var Sa=[],Ta={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},Ua=function(a){return Ta[a]},Va=/[\x00\x22\x26\x27\x3c\x3e]/g;var Za=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,$a={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},db=function(a){return $a[a]};
Sa[8]=function(a){if(null==a)return" null ";switch(typeof a){case "boolean":case "number":return" "+a+" ";default:return"'"+String(String(a)).replace(Za,db)+"'"}};var lb=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,mb={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},ob=function(a){return mb[a]};Sa[16]=function(a){return a};var qb;
var rb=[],sb=[],tb=[],ub=[],vb=[],wb={},xb,yb,Ab,Bb=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},Cb=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=wb[c],e={},f;for(f in a)a.hasOwnProperty(f)&&0===f.indexOf("vtp_")&&(e[void 0!==d?f:f.substr(4)]=a[f]);return void 0!==d?d(e):qb(c,e,b)},Eb=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=Db(a[e],b,c));
return d},Fb=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=wb[b];return c?c.priorityOverride||0:0},Db=function(a,b,c){if(sa(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(Db(a[e],b,c));return d;case "macro":var f=a[1];if(c[f])return;var h=rb[f];if(!h||b.Vc(h))return;c[f]=!0;try{var k=Eb(h,b,c);k.vtp_gtmEventId=b.id;d=Cb(k,b);Ab&&(d=Ab.fg(d,k))}catch(x){b.De&&b.De(x,Number(f)),d=!1}c[f]=
!1;return d;case "map":d={};for(var l=1;l<a.length;l+=2)d[Db(a[l],b,c)]=Db(a[l+1],b,c);return d;case "template":d=[];for(var m=!1,q=1;q<a.length;q++){var r=Db(a[q],b,c);yb&&(m=m||r===yb.Gb);d.push(r)}return yb&&m?yb.ig(d):d.join("");case "escape":d=Db(a[1],b,c);if(yb&&sa(a[1])&&"macro"===a[1][0]&&yb.Ig(a))return yb.$g(d);d=String(d);for(var u=2;u<a.length;u++)Sa[a[u]]&&(d=Sa[a[u]](d));return d;case "tag":var p=a[1];if(!ub[p])throw Error("Unable to resolve tag reference "+p+".");return d={pe:a[2],
index:p};case "zb":var t={arg0:a[2],arg1:a[3],ignore_case:a[5]};t["function"]=a[1];var v=Gb(t,b,c),w=!!a[4];return w||2!==v?w!==(1===v):null;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},Gb=function(a,b,c){try{return xb(Eb(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Hb=function(){var a=function(b){return{toString:function(){return b}}};return{yd:a("convert_case_to"),zd:a("convert_false_to"),Ad:a("convert_null_to"),Bd:a("convert_true_to"),Cd:a("convert_undefined_to"),Hh:a("debug_mode_metadata"),va:a("function"),ff:a("instance_name"),lf:a("live_only"),pf:a("malware_disabled"),qf:a("metadata"),Ih:a("original_vendor_template_id"),uf:a("once_per_event"),Jd:a("once_per_load"),Rd:a("setup_tags"),Td:a("tag_id"),Ud:a("teardown_tags")}}();var Ib=null,Lb=function(a){function b(r){for(var u=0;u<r.length;u++)d[r[u]]=!0}var c=[],d=[];Ib=Jb(a);for(var e=0;e<sb.length;e++){var f=sb[e],h=Kb(f);if(h){for(var k=f.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(f.block||[])}else null===h&&b(f.block||[])}for(var m=[],q=0;q<ub.length;q++)c[q]&&!d[q]&&(m[q]=!0);return m},Kb=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Ib(b[c]);if(0===d)return!1;if(2===d)return null}for(var e=a.unless||[],f=0;f<e.length;f++){var h=Ib(e[f]);if(2===h)return null;
if(1===h)return!1}return!0},Jb=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Gb(tb[c],a));return b[c]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */
var D=window,E=document,gc=navigator,hc=E.currentScript&&E.currentScript.src,ic=function(a,b){var c=D[a];D[a]=void 0===c?b:c;return D[a]},jc=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},kc=function(a,b,c){var d=E.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;jc(d,b);c&&(d.onerror=c);var e;if(null===na)b:{var f=la.document,h=f.querySelector&&f.querySelector("script[nonce]");
if(h){var k=h.nonce||h.getAttribute("nonce");if(k&&ma.test(k)){na=k;break b}}na=""}e=na;e&&d.setAttribute("nonce",e);var l=E.getElementsByTagName("script")[0]||E.body||E.head;l.parentNode.insertBefore(d,l);return d},lc=function(){if(hc){var a=hc.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},mc=function(a,b){var c=E.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=E.body&&E.body.lastChild||
E.body||E.head;d.parentNode.insertBefore(c,d);jc(c,b);void 0!==a&&(c.src=a);return c},nc=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},oc=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},pc=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},H=function(a){D.setTimeout(a,0)},qc=function(a,b){return a&&
b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},rc=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},sc=function(a){var b=E.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},tc=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var f=a,h=0;f&&h<=c;h++){if(d[String(f.tagName).toLowerCase()])return f;
f=f.parentElement}return null},uc=function(a){gc.sendBeacon&&gc.sendBeacon(a)||nc(a)},vc=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var xc=function(a){return wc?E.querySelectorAll(a):null},yc=function(a,b){if(!wc)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!E.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},zc=!1;if(E.querySelectorAll)try{var Ac=E.querySelectorAll(":root");Ac&&1==Ac.length&&Ac[0]==E.documentElement&&(zc=!0)}catch(a){}var wc=zc;var I={},Qc=null,Rc=Math.random();I.s="GTM-P976MC3";I.Kb="4m0";I.Id="";var Sc={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0,__paused:!0,__tg:!0},Tc="www.googletagmanager.com/gtm.js";
var Uc=Tc,Vc=null,Wc=null,Xc=null,Yc="//www.googletagmanager.com/a?id="+I.s+"&cv=1816",Zc={},$c={},ad=function(){var a=Qc.sequence||0;Qc.sequence=a+1;return a};var bd={},J=function(a,b){bd[a]=bd[a]||[];bd[a][b]=!0},cd=function(a){for(var b=[],c=bd[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};
var dd=function(){return"&tc="+ub.filter(function(a){return a}).length},gd=function(){ed||(ed=D.setTimeout(fd,500))},fd=function(){ed&&(D.clearTimeout(ed),ed=void 0);void 0===id||jd[id]&&!kd&&!ld||(md[id]||nd.Kg()||0>=od--?(J("GTM",1),md[id]=!0):(nd.ih(),nc(pd()),jd[id]=!0,qd=rd=ld=kd=""))},pd=function(){var a=id;if(void 0===a)return"";var b=cd("GTM"),c=cd("TAGGING");return[sd,jd[a]?"":"&es=1",td[a],b?"&u="+b:"",c?"&ut="+c:"",dd(),kd,ld,rd,qd,"&z=0"].join("")},ud=function(){return[Yc,"&v=3&t=t","&pid="+
xa(),"&rv="+I.Kb].join("")},vd="0.005000">Math.random(),sd=ud(),wd=function(){sd=ud()},jd={},kd="",ld="",qd="",rd="",id=void 0,td={},md={},ed=void 0,nd=function(a,b){var c=0,d=0;return{Kg:function(){if(c<a)return!1;Ga()-d>=b&&(c=0);return c>=a},ih:function(){Ga()-d>=b&&(c=0);c++;d=Ga()}}}(2,1E3),od=1E3,xd=function(a,b){if(vd&&!md[a]&&id!==a){fd();id=a;qd=kd="";var c;c=0===b.indexOf("gtm.")?encodeURIComponent(b):"*";td[a]="&e="+c+"&eid="+a;gd()}},yd=function(a,b,c){if(vd&&!md[a]&&
b){a!==id&&(fd(),id=a);var d,e=String(b[Hb.va]||"").replace(/_/g,"");0===e.indexOf("cvt")&&(e="cvt");d=e;var f=c+d;kd=kd?kd+"."+f:"&tr="+f;var h=b["function"];if(!h)throw Error("Error: No function name given for function call.");var k=(wb[h]?"1":"2")+d;qd=qd?qd+"."+k:"&ti="+k;gd();2022<=pd().length&&fd()}},zd=function(a,b,c){if(vd&&!md[a]){a!==id&&(fd(),id=a);var d=c+b;ld=ld?ld+
"."+d:"&epr="+d;gd();2022<=pd().length&&fd()}};var Ad={},Bd=new ya,Cd={},Dd={},Gd={name:"dataLayer",set:function(a,b){C(Ma(a,b),Cd);Ed()},get:function(a){return Fd(a,2)},reset:function(){Bd=new ya;Cd={};Ed()}},Fd=function(a,b){if(2!=b){var c=Bd.get(a);if(vd){var d=Hd(a);c!==d&&J("GTM",5)}return c}return Hd(a)},Hd=function(a){var b=a.split("."),c=!1,d=void 0;return c?d:Id(b)},Id=function(a){for(var b=Cd,c=0;c<a.length;c++){if(null===b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var Jd=function(a,b){Dd.hasOwnProperty(a)||(Bd.set(a,b),C(Ma(a,b),Cd),Ed())},Ed=function(a){Aa(Dd,function(b,c){Bd.set(b,c);C(Ma(b,void 0),Cd);C(Ma(b,c),Cd);a&&delete Dd[b]})},Kd=function(a,b,c){Ad[a]=Ad[a]||{};var d=1!==c?Hd(b):Bd.get(b);"array"===Pa(d)||"object"===Pa(d)?Ad[a][b]=C(d):Ad[a][b]=d},Ld=function(a,b){if(Ad[a])return Ad[a][b]},Md=function(a,b){Ad[a]&&delete Ad[a][b]};var Q={ra:"_ee",Kh:"_uci",yc:"event_callback",Fb:"event_timeout",D:"gtag.config",aa:"allow_ad_personalization_signals",zc:"restricted_data_processing",Za:"allow_google_signals",ba:"cookie_expires",Eb:"cookie_update",$a:"session_duration",ja:"user_properties"};Q.ze=[Q.aa,Q.Za,Q.Eb];Q.Ce=[Q.ba,Q.Fb,Q.$a];var Pd=/[A-Z]+/,Qd=/\s/,Rd=function(a){if(g(a)&&(a=Fa(a),!Qd.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Pd.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],w:d}}}}},Td=function(a){for(var b={},c=0;c<a.length;++c){var d=Rd(a[c]);d&&(b[d.id]=d)}Sd(b);var e=[];Aa(b,function(f,h){e.push(h)});return e};
function Sd(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.w[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var Ud=function(){var a=!1;return a};var T=function(a,b,c,d){return(2===Vd()||d||"http:"!=D.location.protocol?a:b)+c},Vd=function(){var a=lc(),b;if(1===a)a:{var c=Uc;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,f=1,h=E.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===f&&0===l.indexOf(d)&&(f=2)}}b=f}else b=a;return b};var ie=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),je={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},ke={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},le="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var ne=function(a){var b=Fd("gtm.whitelist");b&&J("GTM",9);var c=b&&La(Da(b),je),d=Fd("gtm.blacklist");d||(d=Fd("tagTypeBlacklist"))&&J("GTM",3);d?
J("GTM",8):d=[];me()&&(d=Da(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=n(Da(d),"google")&&J("GTM",2);var e=d&&La(Da(d),ke),f={};return function(h){var k=h&&h[Hb.va];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==f[k])return f[k];var l=$c[k]||[],m=a(k,l);if(b){var q;if(q=m)a:{if(0>n(c,k))if(l&&0<l.length)for(var r=0;r<
l.length;r++){if(0>n(c,l[r])){J("GTM",11);q=!1;break a}}else{q=!1;break a}q=!0}m=q}var u=!1;if(d){var p=0<=n(e,k);if(p)u=p;else{var t=za(e,l||[]);t&&J("GTM",10);u=t}}var v=!m||u;v||!(0<=n(l,"sandboxedScripts"))||c&&-1!==n(c,"sandboxedScripts")||(v=za(e,le));return f[k]=v}},me=function(){return ie.test(D.location&&D.location.hostname)};var oe={fg:function(a,b){b[Hb.yd]&&"string"===typeof a&&(a=1==b[Hb.yd]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Hb.Ad)&&null===a&&(a=b[Hb.Ad]);b.hasOwnProperty(Hb.Cd)&&void 0===a&&(a=b[Hb.Cd]);b.hasOwnProperty(Hb.Bd)&&!0===a&&(a=b[Hb.Bd]);b.hasOwnProperty(Hb.zd)&&!1===a&&(a=b[Hb.zd]);return a}};var pe={active:!0,isWhitelisted:function(){return!0}},qe=function(a){var b=Qc.zones;!b&&a&&(b=Qc.zones=a());return b};var re=function(){};var se=!1,te=0,ue=[];function ve(a){if(!se){var b=E.createEventObject,c="complete"==E.readyState,d="interactive"==E.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){se=!0;for(var e=0;e<ue.length;e++)H(ue[e])}ue.push=function(){for(var f=0;f<arguments.length;f++)H(arguments[f]);return 0}}}function we(){if(!se&&140>te){te++;try{E.documentElement.doScroll("left"),ve()}catch(a){D.setTimeout(we,50)}}}var xe=function(a){se?a():ue.push(a)};var ye={},ze={},Ae=function(a,b,c,d){if(!ze[a]||Sc[b]||"__zone"===b)return-1;var e={};Ra(d)&&(e=C(d,e));e.id=c;e.status="timeout";return ze[a].tags.push(e)-1},Be=function(a,b,c,d){if(ze[a]){var e=ze[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function Ce(a){for(var b=ye[a]||[],c=0;c<b.length;c++)b[c]();ye[a]={push:function(d){d(I.s,ze[a])}}}
var Fe=function(a,b,c){ze[a]={tags:[]};qa(b)&&De(a,b);c&&D.setTimeout(function(){return Ce(a)},Number(c));return Ee(a)},De=function(a,b){ye[a]=ye[a]||[];ye[a].push(Ia(function(){return H(function(){b(I.s,ze[a])})}))};function Ee(a){var b=0,c=0,d=!1;return{add:function(){c++;return Ia(function(){b++;d&&b>=c&&Ce(a)})},Sf:function(){d=!0;b>=c&&Ce(a)}}};var Ge=function(){function a(d){return!ra(d)||0>d?0:d}if(!Qc._li&&D.performance&&D.performance.timing){var b=D.performance.timing.navigationStart,c=ra(Gd.get("gtm.start"))?Gd.get("gtm.start"):0;Qc._li={cst:a(c-b),cbt:a(Wc-b)}}};var Ke={},Le=function(){return D.GoogleAnalyticsObject&&D[D.GoogleAnalyticsObject]},Me=!1;
var Qe=function(a){},Pe=function(){return D.GoogleAnalyticsObject||"ga"};var Se=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var Te=/:[0-9]+$/,Ue=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var f=d[e].split("=");if(decodeURIComponent(f[0]).replace(/\+/g," ")===b){var h=f.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},Xe=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=Ve(a.protocol)||Ve(D.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:D.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||D.location.hostname).replace(Te,"").toLowerCase());return We(a,b,c,d,e)},We=function(a,b,c,d,e){var f,h=Ve(a.protocol);b&&(b=String(b).toLowerCase());switch(b){case "url_no_fragment":f=Ye(a);break;case "protocol":f=h;break;case "host":f=a.hostname.replace(Te,"").toLowerCase();if(c){var k=/^www\d*\./.exec(f);k&&k[0]&&(f=f.substr(k[0].length))}break;case "port":f=String(Number(a.port)||("http"==h?80:"https"==h?443:""));break;case "path":a.pathname||a.hostname||J("TAGGING",1);
f="/"==a.pathname.substr(0,1)?a.pathname:"/"+a.pathname;var l=f.split("/");0<=n(d||[],l[l.length-1])&&(l[l.length-1]="");f=l.join("/");break;case "query":f=a.search.replace("?","");e&&(f=Ue(f,e,void 0));break;case "extension":var m=a.pathname.split(".");f=1<m.length?m[m.length-1]:"";f=f.split("/")[0];break;case "fragment":f=a.hash.replace("#","");break;default:f=a&&a.href}return f},Ve=function(a){return a?a.replace(":","").toLowerCase():""},Ye=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");
b=0>c?a.href:a.href.substr(0,c)}return b},Ze=function(a){var b=E.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||J("TAGGING",1),c="/"+c);var d=b.hostname.replace(Te,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}};function df(a,b,c,d){var e=ub[a],f=ef(a,b,c,d);if(!f)return null;var h=Db(e[Hb.Rd],c,[]);if(h&&h.length){var k=h[0];f=df(k.index,{C:f,B:1===k.pe?b.terminate:f,terminate:b.terminate},c,d)}return f}
function ef(a,b,c,d){function e(){if(f[Hb.pf])k();else{var w=Eb(f,c,[]),x=Ae(c.id,String(f[Hb.va]),Number(f[Hb.Td]),w[Hb.qf]),y=!1;w.vtp_gtmOnSuccess=function(){if(!y){y=!0;var A=Ga()-z;yd(c.id,ub[a],"5");Be(c.id,x,"success",A);h()}};w.vtp_gtmOnFailure=function(){if(!y){y=!0;var A=Ga()-z;yd(c.id,ub[a],"6");Be(c.id,x,"failure",A);k()}};w.vtp_gtmTagId=f.tag_id;
w.vtp_gtmEventId=c.id;yd(c.id,f,"1");var B=function(){var A=Ga()-z;yd(c.id,f,"7");Be(c.id,x,"exception",A);y||(y=!0,k())};var z=Ga();try{Cb(w,c)}catch(A){B(A)}}}var f=ub[a],h=b.C,k=b.B,l=b.terminate;if(c.Vc(f))return null;var m=Db(f[Hb.Ud],c,[]);if(m&&m.length){var q=m[0],r=df(q.index,{C:h,B:k,terminate:l},c,d);if(!r)return null;h=r;k=2===q.pe?l:r}if(f[Hb.Jd]||f[Hb.uf]){var u=f[Hb.Jd]?vb:c.rh,p=h,t=k;if(!u[a]){e=Ia(e);var v=ff(a,u,e);h=v.C;k=v.B}return function(){u[a](p,t)}}return e}
function ff(a,b,c){var d=[],e=[];b[a]=gf(d,e,c);return{C:function(){b[a]=hf;for(var f=0;f<d.length;f++)d[f]()},B:function(){b[a]=jf;for(var f=0;f<e.length;f++)e[f]()}}}function gf(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function hf(a){a()}function jf(a,b){b()};var mf=function(a,b){for(var c=[],d=0;d<ub.length;d++)if(a.ub[d]){var e=ub[d];var f=b.add();try{var h=df(d,{C:f,B:f,terminate:f},a,d);h?c.push({Te:d,Ne:Fb(e),qg:h}):(kf(d,a),f())}catch(l){f()}}b.Sf();c.sort(lf);for(var k=0;k<c.length;k++)c[k].qg();return 0<c.length};function lf(a,b){var c,d=b.Ne,e=a.Ne;c=d>e?1:d<e?-1:0;var f;if(0!==c)f=c;else{var h=a.Te,k=b.Te;f=h>k?1:h<k?-1:0}return f}
function kf(a,b){if(!vd)return;var c=function(d){var e=b.Vc(ub[d])?"3":"4",f=Db(ub[d][Hb.Rd],b,[]);f&&f.length&&c(f[0].index);yd(b.id,ub[d],e);var h=Db(ub[d][Hb.Ud],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var nf=!1,of=function(a,b,c,d,e){if("gtm.js"==b){if(nf)return!1;nf=!0}xd(a,b);var f=Fe(a,d,e);Kd(a,"event",1);Kd(a,"ecommerce",1);Kd(a,"gtm");var h={id:a,name:b,Vc:ne(c),ub:[],rh:[],De:function(){J("GTM",6)}};h.ub=Lb(h);var k=mf(h,f);"gtm.js"!==b&&"gtm.sync"!==b||Qe(I.s);if(!k)return k;for(var l=0;l<h.ub.length;l++)if(h.ub[l]){var m=ub[l];if(m&&!Sc[String(m[Hb.va])])return!0}return!1};var pf=[];function qf(){var a=ic("google_tag_data",{});a.ics||(a.ics={entries:{},set:rf,update:sf,addListener:tf,notifyListeners:uf,active:!1});return a.ics}function rf(a,b,c,d,e){var f=qf();f.active=!0;if(void 0!=b){var h=f.entries,k=h[a]||{},l=k.region,m=c&&g(c)?c.toUpperCase():void 0;d=d.toUpperCase();e=e.toUpperCase();m!==e&&(m===d?l===e:m||l)||(h[a]={region:m,initial:"granted"===b,update:k.update})}}
function sf(a,b){var c=qf();c.active=!0;if(void 0!=b){var d=vf(a),e=c.entries;e[a]=e[a]||{};e[a].update="granted"===b;if(vf(a)!==d)for(var f=0;f<pf.length;++f){var h=pf[f];sa(h.je)&&-1!==h.je.indexOf(a)&&(h.Me=!0)}}}function tf(a,b){pf.push({je:a,sg:b})}function uf(){for(var a=0;a<pf.length;++a){var b=pf[a];if(b.Me){b.Me=!1;try{b.sg.call()}catch(c){}}}}
var vf=function(a){var b=qf().entries[a]||{};return void 0!==b.update?b.update:void 0!==b.initial?b.initial:void 0},wf=function(){return qf().active},xf=function(a,b){qf().addListener(a,b)},yf=function(a,b){if(!1===vf(b)){var c=!1;xf([b],function(){!c&&vf(b)&&(a(),c=!0)})}};var zf=[Q.o,Q.J],Af=function(a){var b=a.region;b&&J("GTM",40);for(var c=sa(b)?b:[b],d=0;d<c.length;++d)for(var e=0;e<zf.length;e++){var f=zf[e],h=a[zf[e]],k=c[d];qf().set(f,h,k,"RU","RU-MOW")}},Bf=function(a){for(var b=0;b<zf.length;b++){var c=zf[b],d=a[zf[b]];qf().update(c,d)}qf().notifyListeners()},Cf=function(a){var b=vf(a);return void 0!=b?b:!0},Df=function(){for(var a=[],b=0;b<zf.length;b++){var c=vf(zf[b]);a[b]=!0===c?"1":!1===c?"0":"-"}return"G1"+a.join("")};function Ff(a,b){}function Gf(a,b){return Hf()?Ff(a,b):void 0}function Hf(){var a=!1;return a};var If=function(){this.eventModel={};this.targetConfig={};this.containerConfig={};this.h={};this.globalConfig={};this.C=function(){};this.B=function(){};this.ie=void 0},Jf=function(a){var b=new If;b.eventModel=a;return b},Kf=function(a,b){a.targetConfig=b;return a},Lf=function(a,b){a.containerConfig=b;return a},Mf=function(a,b){a.h=b;return a},Nf=function(a,b){a.globalConfig=b;return a},Of=function(a,b){a.C=b;return a},Pf=function(a,b){a.B=b;return a};
If.prototype.getWithConfig=function(a){if(void 0!==this.eventModel[a])return this.eventModel[a];if(void 0!==this.targetConfig[a])return this.targetConfig[a];if(void 0!==this.containerConfig[a])return this.containerConfig[a];if(void 0!==this.h[a])return this.h[a];if(void 0!==this.globalConfig[a])return this.globalConfig[a]};
var Qf=function(a){function b(e){Aa(e,function(f){c[f]=null})}var c={};b(a.eventModel);b(a.targetConfig);b(a.containerConfig);b(a.globalConfig);var d=[];Aa(c,function(e){d.push(e)});return d};function Rf(a,b,c){for(var d=[],e=b.split(";"),f=0;f<e.length;f++){var h=e[f].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d};var Sf={},Tf=function(a){return void 0==Sf[a]?!1:Sf[a]};var Vf=function(a,b,c,d){return Uf(d)?Rf(a,String(b||document.cookie),c):[]},Yf=function(a,b,c,d,e){if(Uf(e)){var f=Wf(a,d,e);if(1===f.length)return f[0].id;if(0!==f.length){f=Xf(f,function(h){return h.Sb},b);if(1===f.length)return f[0].id;f=Xf(f,function(h){return h.vb},c);return f[0]?f[0].id:void 0}}};function Zf(a,b,c,d){var e=document.cookie;document.cookie=a;var f=document.cookie;return e!=f||void 0!=c&&0<=Vf(b,f,!1,d).indexOf(c)}
var cg=function(a,b,c){function d(p,t,v){if(null==v)return delete h[t],p;h[t]=v;return p+"; "+t+"="+v}function e(p,t){if(null==t)return delete h[t],p;h[t]=!0;return p+"; "+t}if(!Uf(c.Ca))return!1;var f;void 0==b?f=a+"=deleted; expires="+(new Date(0)).toUTCString():(c.encode&&(b=encodeURIComponent(b)),b=$f(b),f=a+"="+b);var h={};f=d(f,"path",c.path);var k;c.expires instanceof Date?k=c.expires.toUTCString():null!=c.expires&&(k=""+c.expires);f=d(f,"expires",k);f=d(f,"max-age",c.Uh);f=d(f,"samesite",
c.$h);c.ai&&(f=e(f,"secure"));f=e(f,c.flags);var l=c.domain;if("auto"===l){for(var m=ag(),q=0;q<m.length;++q){var r="none"!==m[q]?m[q]:void 0,u=d(f,"domain",r);if(!bg(r,c.path)&&Zf(u,a,b,c.Ca))return!0}return!1}l&&"none"!==l&&(f=d(f,"domain",l));return bg(l,c.path)?!1:Zf(f,a,b,c.Ca)},dg=function(a,b,c){null==c.path&&(c.path="/");c.domain||(c.domain="auto");return cg(a,b,c)};
function Xf(a,b,c){for(var d=[],e=[],f,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===f||l<f?(e=[k],f=l):l===f&&e.push(k)}return 0<d.length?d:e}function Wf(a,b,c){for(var d=[],e=Vf(a,void 0,void 0,c),f=0;f<e.length;f++){var h=e[f].split("."),k=h.shift();if(!b||-1!==b.indexOf(k)){var l=h.shift();l&&(l=l.split("-"),d.push({id:h.join("."),Sb:1*l[0]||1,vb:1*l[1]||1}))}}return d}
var $f=function(a){a&&1200<a.length&&(a=a.substring(0,1200));return a},eg=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,fg=/(^|\.)doubleclick\.net$/i,bg=function(a,b){return fg.test(document.location.hostname)||"/"===b&&eg.test(a)},ag=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));var e=document.location.hostname;fg.test(e)||eg.test(e)||a.push("none");
return a},Uf=function(a){if(!Tf("gtag_cs_api")||!a||!wf())return!0;var b=vf(a);return null==b?!0:!!b};var gg=function(){for(var a=gc.userAgent+(E.cookie||"")+(E.referrer||""),b=a.length,c=D.history.length;0<c;)a+=c--^b++;var d=1,e,f,h;if(a)for(d=0,f=a.length-1;0<=f;f--)h=a.charCodeAt(f),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(Ga()/1E3)].join(".")},jg=function(a,b,c,d,e){var f=hg(b);return Yf(a,f,ig(c),d,e)},kg=function(a,b,c,d){var e=""+hg(c),f=ig(d);1<f&&(e+="-"+f);return[b,e,a].join(".")},hg=function(a){if(!a)return 1;
a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},ig=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};function lg(a,b,c){var d,e=a.tb;null==e&&(e=7776E3);0!==e&&(d=new Date((b||Ga())+1E3*e));return{path:a.path,domain:a.domain,flags:a.flags,encode:!!c,expires:d}};function mg(){for(var a=ng,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function og(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var ng,pg;function rg(a){ng=ng||og();pg=pg||mg();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,f=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=f>>2,m=(f&3)<<4|h>>4,q=(h&15)<<2|k>>6,r=k&63;e||(r=64,d||(q=64));b.push(ng[l],ng[m],ng[q],ng[r])}return b.join("")}
function sg(a){function b(l){for(;d<a.length;){var m=a.charAt(d++),q=pg[m];if(null!=q)return q;if(!/^[\s\xa0]*$/.test(m))throw Error("Unknown base64 encoding at char: "+m);}return l}ng=ng||og();pg=pg||mg();for(var c="",d=0;;){var e=b(-1),f=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|f>>4);64!=h&&(c+=String.fromCharCode(f<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var tg;var xg=function(){var a=ug,b=vg,c=wg(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){oc(E,"mousedown",d);oc(E,"keyup",d);oc(E,"submit",e);var f=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);f.call(this)};c.init=!0}},yg=function(a,b,c,d,e){var f={callback:a,domains:b,fragment:2===c,placement:c,forms:d,sameHost:e};wg().decorators.push(f)},zg=function(a,b,c){for(var d=wg().decorators,e={},f=0;f<d.length;++f){var h=
d[f],k;if(k=!c||h.forms)a:{var l=h.domains,m=a;if(l&&(h.sameHost||m!==E.location.hostname))for(var q=0;q<l.length;q++)if(l[q]instanceof RegExp){if(l[q].test(m)){k=!0;break a}}else if(0<=m.indexOf(l[q])){k=!0;break a}k=!1}if(k){var r=h.placement;void 0==r&&(r=h.fragment?2:1);r===b&&Ja(e,h.callback())}}return e},wg=function(){var a=ic("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var Ag=/(.*?)\*(.*?)\*(.*)/,Bg=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,Cg=/^(?:www\.|m\.|amp\.)+/,Dg=/([^?#]+)(\?[^#]*)?(#.*)?/;function Eg(a){return new RegExp("(.*?)(^|&)"+a+"=([^&]*)&?(.*)")}
var Gg=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(rg(String(d))))}var e=b.join("*");return["1",Fg(e),e].join("*")},Fg=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=tg)){for(var e=Array(256),f=0;256>f;f++){for(var h=f,k=0;8>k;k++)h=
h&1?h>>>1^3988292384:h>>>1;e[f]=h}d=e}tg=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^tg[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},Ig=function(){return function(a){var b=Ze(D.location.href),c=b.search.replace("?",""),d=Ue(c,"_gl",!0)||"";a.query=Hg(d)||{};var e=Xe(b,"fragment").match(Eg("_gl"));a.fragment=Hg(e&&e[3]||"")||{}}},Jg=function(){var a=Ig(),b=wg();b.data||(b.data={query:{},fragment:{}},a(b.data));var c={},d=b.data;d&&(Ja(c,d.query),Ja(c,d.fragment));return c},Hg=function(a){var b;
b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var f=Ag.exec(d);if(f){c=f;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var m=h[2],q=0;q<b;++q)if(m===Fg(k,q)){l=!0;break a}l=!1}if(l){for(var r={},u=k?k.split("*"):[],p=0;p<u.length;p+=2)r[u[p]]=sg(u[p+1]);return r}}}}catch(t){}};
function Kg(a,b,c,d){function e(q){var r=q,u=Eg(a).exec(r),p=r;if(u){var t=u[2],v=u[4];p=u[1];v&&(p=p+t+v)}q=p;var w=q.charAt(q.length-1);q&&"&"!==w&&(q+="&");return q+m}d=void 0===d?!1:d;var f=Dg.exec(c);if(!f)return"";var h=f[1],k=f[2]||"",l=f[3]||"",m=a+"="+b;d?l="#"+e(l.substring(1)):k="?"+e(k.substring(1));return""+h+k+l}
function Lg(a,b){var c="FORM"===(a.tagName||"").toUpperCase(),d=zg(b,1,c),e=zg(b,2,c),f=zg(b,3,c);if(Ka(d)){var h=Gg(d);c?Mg("_gl",h,a):Ng("_gl",h,a,!1)}if(!c&&Ka(e)){var k=Gg(e);Ng("_gl",k,a,!0)}for(var l in f)if(f.hasOwnProperty(l))a:{var m=l,q=f[l],r=a;if(r.tagName){if("a"===r.tagName.toLowerCase()){Ng(m,q,r,void 0);break a}if("form"===r.tagName.toLowerCase()){Mg(m,q,r);break a}}"string"==typeof r&&Kg(m,q,r,void 0)}}
function Ng(a,b,c,d){if(c.href){var e=Kg(a,b,c.href,void 0===d?!1:d);Se.test(e)&&(c.href=e)}}
function Mg(a,b,c){if(c&&c.action){var d=(c.method||"").toLowerCase();if("get"===d){for(var e=c.childNodes||[],f=!1,h=0;h<e.length;h++){var k=e[h];if(k.name===a){k.setAttribute("value",b);f=!0;break}}if(!f){var l=E.createElement("input");l.setAttribute("type","hidden");l.setAttribute("name",a);l.setAttribute("value",b);c.appendChild(l)}}else if("post"===d){var m=Kg(a,b,c.action);Se.test(m)&&(c.action=m)}}}
var ug=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var f=e.protocol;"http:"!==f&&"https:"!==f||Lg(e,e.hostname)}}catch(h){}},vg=function(a){try{if(a.action){var b=Xe(Ze(a.action),"host");Lg(a,b)}}catch(c){}},Og=function(a,b,c,d){xg();yg(a,b,"fragment"===c?2:1,!!d,!1)},Pg=function(a,b){xg();yg(a,[We(D.location,"host",!0)],b,!0,!0)},Qg=function(){var a=E.location.hostname,b=Bg.exec(E.referrer);if(!b)return!1;
var c=b[2],d=b[1],e="";if(c){var f=c.split("/"),h=f[1];e="s"===h?decodeURIComponent(f[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var k=a.replace(Cg,""),l=e.replace(Cg,""),m;if(!(m=k===l)){var q="."+l;m=k.substring(k.length-q.length,k.length)===q}return m},Rg=function(a,b){return!1===a?!1:a||b||Qg()};var Sg=/^\w+$/,Tg=/^[\w-]+$/,Ug=/^~?[\w-]+$/,Vg={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp"},Wg=function(){if(!Tf("gtag_cs_api")||!wf())return!0;var a=vf("ad_storage");return null==a?!0:!!a},Xg=function(a){Wg()?a():yf(a,"ad_storage")};function Yg(a){return a&&"string"==typeof a&&a.match(Sg)?a:"_gcl"}
var $g=function(){var a=Ze(D.location.href),b=Xe(a,"query",!1,void 0,"gclid"),c=Xe(a,"query",!1,void 0,"gclsrc"),d=Xe(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||Ue(e,"gclid",void 0);c=c||Ue(e,"gclsrc",void 0)}return Zg(b,c,d)},Zg=function(a,b,c){var d={},e=function(f,h){d[h]||(d[h]=[]);d[h].push(f)};d.gclid=a;d.gclsrc=b;d.dclid=c;if(void 0!==a&&a.match(Tg))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":Tf("gtm_3pds")&&
e(a,"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha");break;case "gp":e(a,"gp")}c&&e(c,"dc");return d},bh=function(a){var b=$g();Xg(function(){return ah(b,a)})};
function ah(a,b,c){function d(m,q){var r=ch(m,e);r&&(dg(r,q,f),h=!0)}b=b||{};var e=Yg(b.prefix);c=c||Ga();var f=lg(b,c,!0);f.Ca="ad_storage";var h=!1,k=Math.round(c/1E3),l=function(m){return["GCL",k,m].join(".")};a.aw&&(!0===b.ei?d("aw",l("~"+a.aw[0])):d("aw",l(a.aw[0])));a.dc&&d("dc",l(a.dc[0]));a.gf&&d("gf",l(a.gf[0]));a.ha&&d("ha",l(a.ha[0]));a.gp&&d("gp",l(a.gp[0]));return h}
var eh=function(a,b){var c=Jg();Xg(function(){for(var d=Yg(b.prefix),e=0;e<a.length;++e){var f=a[e];if(void 0!==Vg[f]){var h=ch(f,d),k=c[h];if(k){var l=Math.min(dh(k),Ga()),m;b:{for(var q=l,r=Vf(h,E.cookie,void 0,"ad_storage"),u=0;u<r.length;++u)if(dh(r[u])>q){m=!0;break b}m=!1}if(!m){var p=lg(b,l,!0);p.Ca="ad_storage";dg(h,k,p)}}}}ah(Zg(c.gclid,c.gclsrc),b)})},ch=function(a,b){var c=Vg[a];if(void 0!==c)return b+c},dh=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||
0)};function fh(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var gh=function(a,b,c,d,e){if(sa(b)){var f=Yg(e),h=function(){for(var k={},l=0;l<a.length;++l){var m=ch(a[l],f);if(m){var q=Vf(m,E.cookie,void 0,"ad_storage");q.length&&(k[m]=q.sort()[q.length-1])}}return k};Xg(function(){Og(h,b,c,d)})}},hh=function(a){return a.filter(function(b){return Ug.test(b)})},ih=function(a,b){for(var c=Yg(b.prefix),d={},e=0;e<a.length;e++)Vg[a[e]]&&(d[a[e]]=Vg[a[e]]);Xg(function(){Aa(d,function(f,h){var k=Vf(c+h,E.cookie,void 0,"ad_storage");if(k.length){var l=k[0],m=dh(l),
q={};q[f]=[fh(l)];ah(q,b,m)}})})};function jh(a){for(var b=["aw","dc"],c=0;c<b.length;++c)if(a[b[c]])return!0;return!1}
var kh=function(){function a(d,e,f){f&&(d[e]=f)}var b=$g();if(jh(b)){var c={};a(c,"gclid",b.gclid);a(c,"dclid",b.dclid);a(c,"gclsrc",b.gclsrc);Pg(function(){return c},3);Pg(function(){var d={};return d._up="1",d},1)}},lh=function(){var a;if(Wg()){for(var b=[],c=E.cookie.split(";"),d=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,e=0;e<c.length;e++){var f=c[e].match(d);f&&b.push({nd:f[1],value:f[2]})}var h={};if(b&&b.length)for(var k=0;k<b.length;k++){var l=b[k].value.split(".");"1"==l[0]&&3==l.length&&l[1]&&
(h[b[k].nd]||(h[b[k].nd]=[]),h[b[k].nd].push({timestamp:l[1],vg:l[2]}))}a=h}else a={};return a};function mh(){var a=!1;return a}
function nh(a){function b(l){var m;Qc.reported_gclid||(Qc.reported_gclid={});m=Qc.reported_gclid;var q=d+(l?"gcu":"gcs");if(!m[q]){m[q]=!0;var r=[],u=function(v,w){w&&r.push(v+"="+encodeURIComponent(w))},p=d;u("gclid",p);u("gclsrc",e);var t="https://www.google.com/pagead/landing?"+r.join("&");uc(t)}}var c=$g(),d=c.gclid||"",e=c.gclsrc,
f=!a&&(!d||e&&"aw.ds"!==e?!1:!0),h=mh();if(f||h){var k=""+gg();b();}};var oh;if(3===I.Kb.length)oh="g";else{var ph="G";oh=ph}
var qh={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:oh,OPT:"o"},rh=function(a){var b=I.s.split("-"),c=b[0].toUpperCase(),d=qh[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",f;if(3===I.Kb.length){var h=void 0;f="2"+(h||"w")}else f=
"";return f+d+I.Kb+e};var Bh=["1"],Ch={},Gh=function(a){var b=Dh(a.prefix);Ch[b]||Eh(b,a.path,a.domain)||(Fh(b,gg(),a),Eh(b,a.path,a.domain))};function Fh(a,b,c){var d=kg(b,"1",c.domain,c.path),e=lg(c);e.Ca="ad_storage";dg(a,d,e)}function Eh(a,b,c){var d=jg(a,b,c,Bh,"ad_storage");d&&(Ch[a]=d);return d}function Dh(a){return(a||"_gcl")+"_au"};var Hh=/^\d+\.fls\.doubleclick\.net$/;function Ih(a){Cf("ad_storage")?a():yf(a,"ad_storage")}function Jh(a){var b=Ze(D.location.href),c=Xe(b,"host",!1);if(c&&c.match(Hh)){var d=Xe(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function Kh(a,b){if("aw"==a||"dc"==a){var c=Jh("gcl"+a);if(c)return c.split(".")}var d=Yg(b);if(Cf("ad_storage")&&"_gcl"==d){var e;e=$g()[a]||[];if(0<e.length)return e}var f=ch(a,d),h;if(f){var k=[];if(E.cookie){var l=Vf(f,E.cookie,void 0,"ad_storage");if(l&&0!=l.length){for(var m=0;m<l.length;m++){var q=fh(l[m]);q&&-1===n(k,q)&&k.push(q)}h=hh(k)}else h=k}else h=k}else h=[];return h}
var Lh=function(){var a=Jh("gac");if(a)return decodeURIComponent(a);var b=lh(),c=[];Aa(b,function(d,e){for(var f=[],h=0;h<e.length;h++)f.push(e[h].vg);f=hh(f);f.length&&c.push(d+":"+f.join(","))});return c.join(";")},Mh=function(a,b){var c=$g().dc||[];Ih(function(){Gh(b);var d=Ch[Dh(b.prefix)],e=!1;if(d&&0<c.length){var f=Qc.joined_au=Qc.joined_au||{},h=b.prefix||"_gcl";if(!f[h])for(var k=0;k<c.length;k++){var l="https://adservice.google.com/ddm/regclk";l=l+"?gclid="+c[k]+"&auiddc="+d;uc(l);e=f[h]=!0}}null==a&&
(a=e);if(a&&d){var m=Dh(b.prefix),q=Ch[m];q&&Fh(m,q,b)}})};var Gi={},Hi=["G","GP"];Gi.Ve="";var Ii=Gi.Ve.split(",");function Ji(){var a=Qc;return a.gcq=a.gcq||new Ki}
var Li=function(a,b,c){Ji().register(a,b,c)},Mi=function(a,b,c,d){Ji().push("event",[b,a],c,d)},Ni=function(a,b){Ji().push("config",[a],b)},Oi={},Pi=function(a){return!0},Qi=function(){this.status=1;this.containerConfig={};this.targetConfig={};this.i={};this.m=null;this.h=!1},Ri=function(a,b,c,d,e){this.type=a;this.m=b;this.Y=c||"";
this.h=d;this.i=e},Ki=function(){this.m={};this.i={};this.h=[]},Si=function(a,b){var c=Rd(b);return a.m[c.containerId]=a.m[c.containerId]||new Qi},Ti=function(a,b,c){if(b){var d=Rd(b);if(d&&1===Si(a,b).status&&Pi(d.prefix)){Si(a,b).status=2;var e={};vd&&(e.timeoutId=D.setTimeout(function(){J("GTM",38);gd()},3E3));a.push("require",[e],d.containerId);Oi[d.containerId]=Ga();if(Ud()){}else{var h="/gtag/js?id="+encodeURIComponent(d.containerId)+"&l=dataLayer&cx=c",k=("http:"!=D.location.protocol?"https:":"http:")+("//www.googletagmanager.com"+h),l=Gf(c,h)||k;kc(l)}}}},Ui=function(a,b,c,d){if(d.Y){var e=Si(a,d.Y),
f=e.m;if(f){var h=C(c),k=C(e.targetConfig[d.Y]),l=C(e.containerConfig),m=C(e.i),q=C(a.i),r=Fd("gtm.uniqueEventId"),u=Rd(d.Y).prefix,p=Pf(Of(Nf(Mf(Lf(Kf(Jf(h),k),l),m),q),function(){zd(r,u,"2");}),function(){zd(r,u,"3");});try{zd(r,u,"1");f(d.Y,b,d.m,p)}catch(t){
zd(r,u,"4");}}}};
Ki.prototype.register=function(a,b,c){if(3!==Si(this,a).status){Si(this,a).m=b;Si(this,a).status=3;c&&(Si(this,a).i=c);var d=Rd(a),e=Oi[d.containerId];if(void 0!==e){var f=Qc[d.containerId].bootstrap,h=d.prefix.toUpperCase();Qc[d.containerId]._spx&&(h=h.toLowerCase());var k=Fd("gtm.uniqueEventId"),l=h,m=Ga()-f;if(vd&&!md[k]){k!==id&&(fd(),id=k);var q=l+"."+Math.floor(f-e)+"."+Math.floor(m);rd=rd?rd+","+q:"&cl="+q}delete Oi[d.containerId]}this.flush()}};
Ki.prototype.push=function(a,b,c,d){var e=Math.floor(Ga()/1E3);Ti(this,c,b[0][Q.xa]||this.i[Q.xa]);this.h.push(new Ri(a,e,c,b,d));d||this.flush()};
Ki.prototype.flush=function(a){for(var b=this;this.h.length;){var c=this.h[0];if(c.i)c.i=!1,this.h.push(c);else switch(c.type){case "require":if(3!==Si(this,c.Y).status&&!a)return;vd&&D.clearTimeout(c.h[0].timeoutId);break;case "set":Aa(c.h[0],function(l,m){C(Ma(l,m),b.i)});break;case "config":var d=c.h[0],e=!!d[Q.bc];delete d[Q.bc];var f=Si(this,c.Y),h=Rd(c.Y),k=h.containerId===h.id;e||(k?f.containerConfig={}:f.targetConfig[c.Y]={});f.h&&e||Ui(this,Q.D,d,c);f.h=!0;delete d[Q.ra];k?C(d,f.containerConfig):
C(d,f.targetConfig[c.Y]);break;case "event":Ui(this,c.h[1],c.h[0],c)}this.h.shift()}};var Vi=["GP","G"],Wi="G".split(/,/);Wi.push("GF");Wi.push("HA");var Xi=!1;Xi=!0;var Yi=null,Zi={},$i={},aj;function bj(a,b){var c={event:a};b&&(c.eventModel=C(b),b[Q.yc]&&(c.eventCallback=b[Q.yc]),b[Q.Fb]&&(c.eventTimeout=b[Q.Fb]));return c}
var hj={config:function(a){},event:function(a){var b=a[1];if(g(b)&&!(3<a.length)){var c;if(2<a.length){if(!Ra(a[2])&&void 0!=a[2])return;c=a[2]}var d=bj(b,c);return d}},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(){},set:function(a){var b;2==a.length&&Ra(a[1])?b=C(a[1]):3==a.length&&
g(a[1])&&(b={},Ra(a[2])||sa(a[2])?b[a[1]]=C(a[2]):b[a[1]]=a[2]);if(b){b._clear=!0;return b}}};var ij={policy:!0};var jj=function(a,b){var c=a.hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}},lj=function(a){var b=kj(),c=b&&b.hide;c&&c.end&&(c[a]=!0)};var mj=!1,nj=[];function oj(){if(!mj){mj=!0;for(var a=0;a<nj.length;a++)H(nj[a])}}var pj=function(a){mj?H(a):nj.push(a)};var Hj=function(a){if(Gj(a))return a;this.h=a};Hj.prototype.zg=function(){return this.h};var Gj=function(a){return!a||"object"!==Pa(a)||Ra(a)?!1:"getUntrustedUpdateValue"in a};Hj.prototype.getUntrustedUpdateValue=Hj.prototype.zg;var Ij=[],Jj=!1,Kj=function(a){return D["dataLayer"].push(a)},Lj=function(a){var b=Qc["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}};
function Mj(a){var b=a._clear;Aa(a,function(f,h){"_clear"!==f&&(b&&Jd(f,void 0),Jd(f,h))});Vc||(Vc=a["gtm.start"]);var c=a.event;if(!c)return!1;var d=a["gtm.uniqueEventId"];d||(d=ad(),a["gtm.uniqueEventId"]=d,Jd("gtm.uniqueEventId",d));Xc=c;var e=Nj(a);Xc=null;switch(c){case "gtm.init":J("GTM",19),e&&J("GTM",20)}return e}
function Nj(a){var b=a.event,c=a["gtm.uniqueEventId"],d,e=Qc.zones;d=e?e.checkState(I.s,c):pe;return d.active?of(c,b,d.isWhitelisted,a.eventCallback,a.eventTimeout)?!0:!1:!1}
function Oj(){for(var a=!1;!Jj&&0<Ij.length;){Jj=!0;delete Cd.eventModel;Ed();var b=Ij.shift();if(null!=b){var c=Gj(b);if(c){var d=b;b=Gj(d)?d.getUntrustedUpdateValue():void 0;for(var e=["gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],f=0;f<e.length;f++){var h=e[f],k=Fd(h,1);if(sa(k)||Ra(k))k=C(k);Dd[h]=k}}try{if(qa(b))try{b.call(Gd)}catch(v){}else if(sa(b)){var l=b;if(g(l[0])){var m=
l[0].split("."),q=m.pop(),r=l.slice(1),u=Fd(m.join("."),2);if(void 0!==u&&null!==u)try{u[q].apply(u,r)}catch(v){}}}else{var p=b;if(p&&("[object Arguments]"==Object.prototype.toString.call(p)||Object.prototype.hasOwnProperty.call(p,"callee"))){a:{if(b.length&&g(b[0])){var t=hj[b[0]];if(t&&(!c||!ij[b[0]])){b=t(b);break a}}b=void 0}if(!b){Jj=!1;continue}}a=Mj(b)||a}}finally{c&&Ed(!0)}}Jj=!1}
return!a}function Pj(){var a=Oj();try{jj(D["dataLayer"],I.s)}catch(b){}return a}
var Rj=function(){var a=ic("dataLayer",[]),b=ic("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};xe(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});pj(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||0)+1;var c=a.push;a.push=function(){var d;if(0<Qc.SANDBOXED_JS_SEMAPHORE){d=[];for(var e=0;e<arguments.length;e++)d[e]=new Hj(arguments[e])}else d=[].slice.call(arguments,0);var f=c.apply(a,d);Ij.push.apply(Ij,d);if(300<
this.length)for(J("GTM",4);300<this.length;)this.shift();var h="boolean"!==typeof f||f;return Oj()&&h};Ij.push.apply(Ij,a.slice(0));Qj()&&H(Pj)},Qj=function(){var a=!0;return a};var Sj={};Sj.Gb=new String("undefined");
var Tj=function(a){this.h=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===Sj.Gb?b:a[d]);return c.join("")}};Tj.prototype.toString=function(){return this.h("undefined")};Tj.prototype.valueOf=Tj.prototype.toString;Sj.Df=Tj;Sj.Hc={};Sj.ig=function(a){return new Tj(a)};var Uj={};Sj.jh=function(a,b){var c=ad();Uj[c]=[a,b];return c};Sj.ke=function(a){var b=a?0:1;return function(c){var d=Uj[c];if(d&&"function"===typeof d[b])d[b]();Uj[c]=void 0}};Sj.Ig=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=
b||8===a[d],c=c||16===a[d];return b&&c};Sj.$g=function(a){if(a===Sj.Gb)return a;var b=ad();Sj.Hc[b]=a;return'google_tag_manager["'+I.s+'"].macro('+b+")"};Sj.Sg=function(a,b,c){a instanceof Sj.Df&&(a=a.h(Sj.jh(b,c)),b=pa);return{Tc:a,C:b}};var Vj=function(a,b,c){function d(f,h){var k=f[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||qc(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},Wj=function(a){Qc.hasOwnProperty("autoEventsSettings")||(Qc.autoEventsSettings={});var b=Qc.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},Xj=function(a,b,c){Wj(a)[b]=c},Yj=function(a,b,c,d){var e=Wj(a),f=Ha(e,b,d);e[b]=c(f)},Zj=function(a,b,c){var d=Wj(a);return Ha(d,b,c)};var ak=["input","select","textarea"],bk=["button","hidden","image","reset","submit"],ck=function(a){var b=a.tagName.toLowerCase();return!wa(ak,function(c){return c===b})||"input"===b&&wa(bk,function(c){return c===a.type.toLowerCase()})?!1:!0},dk=function(a){return a.form?a.form.tagName?a.form:E.getElementById(a.form):tc(a,["form"],100)},ek=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,f=1;e<a.elements.length;e++){var h=a.elements[e];if(ck(h)){if(h.getAttribute(c)===d)return f;
f++}}return 0};var fk=!!D.MutationObserver,gk=void 0,hk=function(a){if(!gk){var b=function(){var c=E.body;if(c)if(fk)(new MutationObserver(function(){for(var e=0;e<gk.length;e++)H(gk[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;oc(c,"DOMNodeInserted",function(){d||(d=!0,H(function(){d=!1;for(var e=0;e<gk.length;e++)H(gk[e])}))})}};gk=[];E.body?b():H(b)}gk.push(a)};
var sk=function(){var a=E.body,b=E.documentElement||a&&a.parentElement,c,d;if(E.compatMode&&"BackCompat"!==E.compatMode)c=b?b.clientHeight:0,d=b?b.clientWidth:0;else{var e=function(f,h){return f&&h?Math.min(f,h):Math.max(f,h)};J("GTM",7);c=e(b?b.clientHeight:0,a?a.clientHeight:0);d=e(b?b.clientWidth:0,a?a.clientWidth:0)}return{width:d,height:c}},tk=function(a){var b=sk(),c=b.height,d=b.width,e=a.getBoundingClientRect(),f=e.bottom-e.top,h=e.right-e.left;return f&&h?(1-Math.min((Math.max(0-e.left,0)+
Math.max(e.right-d,0))/h,1))*(1-Math.min((Math.max(0-e.top,0)+Math.max(e.bottom-c,0))/f,1)):0},uk=function(a){if(E.hidden)return!0;var b=a.getBoundingClientRect();if(b.top==b.bottom||b.left==b.right||!D.getComputedStyle)return!0;var c=D.getComputedStyle(a,null);if("hidden"===c.visibility)return!0;for(var d=a,e=c;d;){if("none"===e.display)return!0;var f=e.opacity,h=e.filter;if(h){var k=h.indexOf("opacity(");0<=k&&(h=h.substring(k+8,h.indexOf(")",k)),"%"==h.charAt(h.length-1)&&(h=h.substring(0,h.length-
1)),f=Math.min(h,f))}if(void 0!==f&&0>=f)return!0;(d=d.parentElement)&&(e=D.getComputedStyle(d,null))}return!1};var Ck=D.clearTimeout,Dk=D.setTimeout,U=function(a,b,c){if(Ud()){b&&H(b)}else return kc(a,b,c)},Ek=function(){return D.location.href},Fk=function(a){return Xe(Ze(a),"fragment")},Gk=function(a){return Ye(Ze(a))},V=function(a,b){return Fd(a,b||2)},Hk=function(a,b,c){var d;b?(a.eventCallback=b,c&&(a.eventTimeout=c),d=Kj(a)):d=Kj(a);return d},Ik=function(a,b){D[a]=b},W=function(a,b,c){b&&(void 0===D[a]||c&&!D[a])&&(D[a]=
b);return D[a]},Jk=function(a,b,c){return Vf(a,b,void 0===c?!0:!!c)},Kk=function(a,b){if(Ud()){b&&H(b)}else mc(a,b)},Lk=function(a){return!!Zj(a,"init",!1)},Mk=function(a){Xj(a,"init",!0)},Nk=function(a,b){var c=(void 0===b?0:b)?"www.googletagmanager.com/gtag/js":Uc;c+="?id="+encodeURIComponent(a)+"&l=dataLayer";U(T("https://","http://",c))},Ok=function(a,b){var c=a[b];return c};var Pk=Sj.Sg;var ll=new ya;function ml(a,b){function c(h){var k=Ze(h),l=Xe(k,"protocol"),m=Xe(k,"host",!0),q=Xe(k,"port"),r=Xe(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==q||"https"==l&&"443"==q)l="web",q="default";return[l,m,q,r]}for(var d=c(String(a)),e=c(String(b)),f=0;f<d.length;f++)if(d[f]!==e[f])return!1;return!0}
function nl(a){return ol(a)?1:0}
function ol(a){var b=a.arg0,c=a.arg1;if(a.any_of&&sa(c)){for(var d=0;d<c.length;d++)if(nl({"function":a["function"],arg0:b,arg1:c[d]}))return!0;return!1}switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var e;a:{if(b){var f=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var h=0;h<f.length;h++)if(b[f[h]]){e=b[f[h]](c);break a}}catch(v){}}e=!1}return e;case "_ew":var k,l;k=String(b);l=String(c);var m=k.length-
l.length;return 0<=m&&k.indexOf(l,m)==m;case "_eq":return String(b)==String(c);case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var q;q=String(b).split(",");return 0<=n(q,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var r;var u=a.ignore_case?"i":void 0;try{var p=String(c)+u,t=ll.get(p);t||(t=new RegExp(c,u),ll.set(p,t));r=t.test(b)}catch(v){r=!1}return r;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return ml(b,
c)}return!1};var pl=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var ql={},rl=encodeURI,X=encodeURIComponent,sl=nc;var tl=function(a,b){if(!a)return!1;var c=Xe(Ze(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var f=c.length-e.length;0<f&&"."!=e.charAt(0)&&(f--,e="."+e);if(0<=f&&c.indexOf(e,f)==f)return!0}}return!1};
var ul=function(a,b,c){for(var d={},e=!1,f=0;a&&f<a.length;f++)a[f]&&a[f].hasOwnProperty(b)&&a[f].hasOwnProperty(c)&&(d[a[f][b]]=a[f][c],e=!0);return e?d:null};ql.Jg=function(){var a=!1;return a};var Im=function(){var a=D.gaGlobal=D.gaGlobal||{};a.hid=a.hid||xa();return a.hid};var Tm=window,Um=document,Vm=function(a){var b=Tm._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===Tm["ga-disable-"+a])return!0;try{var c=Tm.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(f){}for(var d=Rf("AMP_TOKEN",String(Um.cookie),!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return Um.getElementById("__gaOptOutExtension")?!0:!1};
var Ym=function(a){Aa(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[Q.ja]||{};Aa(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var bn=function(a,b,c){Mi(b,c,a)},cn=function(a,b,c){Mi(b,c,a,!0)},en=function(a,b){};
function dn(a,b){}var Y={a:{}};

Y.a.sdl=["google"],function(){function a(){return!!(Object.keys(l("horiz.pix")).length||Object.keys(l("horiz.pct")).length||Object.keys(l("vert.pix")).length||Object.keys(l("vert.pct")).length)}function b(y){for(var B=[],z=y.split(","),A=0;A<z.length;A++){var F=Number(z[A]);if(isNaN(F))return[];q.test(z[A])||B.push(F)}return B}function c(){var y=0,B=0;return function(){var z=sk(),A=z.height;y=Math.max(v.scrollLeft+z.width,y);B=Math.max(v.scrollTop+A,B);return{lg:y,mg:B}}}function d(){p=W("self");
t=p.document;v=t.scrollingElement||t.body&&t.body.parentNode;x=c()}function e(y,B,z,A){var F=l(B),G={},L;for(L in F){G.Ga=L;if(F.hasOwnProperty(G.Ga)){var R=Number(G.Ga);y<R||(Hk({event:"gtm.scrollDepth","gtm.scrollThreshold":R,"gtm.scrollUnits":z.toLowerCase(),"gtm.scrollDirection":A,"gtm.triggers":F[G.Ga].join(",")}),Yj("sdl",B,function(aa){return function(ba){delete ba[aa.Ga];return ba}}(G),{}))}G={Ga:G.Ga}}}function f(){var y=x(),B=y.lg,z=y.mg,A=B/v.scrollWidth*100,F=z/v.scrollHeight*100;e(B,
"horiz.pix",r.Ib,u.Ed);e(A,"horiz.pct",r.Hb,u.Ed);e(z,"vert.pix",r.Ib,u.Yd);e(F,"vert.pct",r.Hb,u.Yd);Xj("sdl","pending",!1)}function h(){var y=250,B=!1;t.scrollingElement&&t.documentElement&&p.addEventListener&&(y=50,B=!0);var z=0,A=!1,F=function(){A?z=Dk(F,y):(z=0,f(),Lk("sdl")&&!a()&&(pc(p,"scroll",G),pc(p,"resize",G),Xj("sdl","init",!1)));A=!1},G=function(){B&&x();z?A=!0:(z=Dk(F,y),Xj("sdl","pending",!0))};return G}function k(y,B,z){if(B){var A=b(String(y));Yj("sdl",z,function(F){for(var G=0;G<
A.length;G++){var L=String(A[G]);F.hasOwnProperty(L)||(F[L]=[]);F[L].push(B)}return F},{})}}function l(y){return Zj("sdl",y,{})}function m(y){H(y.vtp_gtmOnSuccess);var B=y.vtp_uniqueTriggerId,z=y.vtp_horizontalThresholdsPixels,A=y.vtp_horizontalThresholdsPercent,F=y.vtp_verticalThresholdUnits,G=y.vtp_verticalThresholdsPixels,L=y.vtp_verticalThresholdsPercent;switch(y.vtp_horizontalThresholdUnits){case r.Ib:k(z,B,"horiz.pix");break;case r.Hb:k(A,B,"horiz.pct")}switch(F){case r.Ib:k(G,B,"vert.pix");
break;case r.Hb:k(L,B,"vert.pct")}Lk("sdl")?Zj("sdl","pending")||(w||(d(),w=!0),H(function(){return f()})):(d(),w=!0,v&&(Mk("sdl"),Xj("sdl","pending",!0),H(function(){f();if(a()){var R=h();oc(p,"scroll",R);oc(p,"resize",R)}else Xj("sdl","init",!1)})))}var q=/^\s*$/,r={Hb:"PERCENT",Ib:"PIXELS"},u={Yd:"vertical",Ed:"horizontal"},p,t,v,w=!1,x;(function(y){Y.__sdl=y;Y.__sdl.b="sdl";Y.__sdl.g=!0;Y.__sdl.priorityOverride=0})(function(y){y.vtp_triggerStartOption?m(y):pj(function(){m(y)})})}();

Y.a.jsm=["customScripts"],function(){(function(a){Y.__jsm=a;Y.__jsm.b="jsm";Y.__jsm.g=!0;Y.__jsm.priorityOverride=0})(function(a){if(void 0!==a.vtp_javascript){var b=a.vtp_javascript;try{var c=W("google_tag_manager");return c&&c.e&&c.e(b)}catch(d){}}})}();

Y.a.e=["google"],function(){(function(a){Y.__e=a;Y.__e.b="e";Y.__e.g=!0;Y.__e.priorityOverride=0})(function(a){return String(Ld(a.vtp_gtmEventId,"event"))})}();
Y.a.f=["google"],function(){(function(a){Y.__f=a;Y.__f.b="f";Y.__f.g=!0;Y.__f.priorityOverride=0})(function(a){var b=V("gtm.referrer",1)||E.referrer;return b?a.vtp_component&&"URL"!=a.vtp_component?Xe(Ze(String(b)),a.vtp_component,a.vtp_stripWww,a.vtp_defaultPages,a.vtp_queryKey):Gk(String(b)):String(b)})}();
Y.a.cl=["google"],function(){function a(b){var c=b.target;if(c){var d=Vj(c,"gtm.click");Hk(d)}}(function(b){Y.__cl=b;Y.__cl.b="cl";Y.__cl.g=!0;Y.__cl.priorityOverride=0})(function(b){if(!Lk("cl")){var c=W("document");oc(c,"click",a,!0);Mk("cl")}H(b.vtp_gtmOnSuccess)})}();Y.a.k=["google"],function(){(function(a){Y.__k=a;Y.__k.b="k";Y.__k.g=!0;Y.__k.priorityOverride=0})(function(a){return Jk(a.vtp_name,V("gtm.cookie",1),!!a.vtp_decodeCookie)[0]})}();

Y.a.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){Y.__u=b;Y.__u.b="u";Y.__u.g=!0;Y.__u.priorityOverride=0})(function(b){var c;b.vtp_customUrlSource?c=b.vtp_customUrlSource:c=V("gtm.url",1);c=c||Ek();var d=b[a("vtp_component")];if(!d||"URL"==d)return Gk(String(c));var e=Ze(String(c)),f;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],m;h?sa(k)?m=k:m=String(k).replace(/\s+/g,
"").split(","):m=[String(k)];for(var q=0;q<m.length;q++){var r=Xe(e,"QUERY",void 0,void 0,m[q]);if(void 0!=r&&(!l||""!==r)){f=r;break a}}f=void 0}else f=Xe(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return f})}();
Y.a.v=["google"],function(){(function(a){Y.__v=a;Y.__v.b="v";Y.__v.g=!0;Y.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=V(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
Y.a.tl=["google"],function(){function a(b){return function(){if(b.Yc&&b.$c>=b.Yc)b.Uc&&W("self").clearInterval(b.Uc);else{b.$c++;var c=(new Date).getTime();Hk({event:b.ca,"gtm.timerId":b.Uc,"gtm.timerEventNumber":b.$c,"gtm.timerInterval":b.interval,"gtm.timerLimit":b.Yc,"gtm.timerStartTime":b.Se,"gtm.timerCurrentTime":c,"gtm.timerElapsedTime":c-b.Se,"gtm.triggers":b.vh})}}}(function(b){Y.__tl=b;Y.__tl.b="tl";Y.__tl.g=!0;Y.__tl.priorityOverride=0})(function(b){H(b.vtp_gtmOnSuccess);if(!isNaN(b.vtp_interval)){var c=
{ca:b.vtp_eventName,$c:0,interval:Number(b.vtp_interval),Yc:isNaN(b.vtp_limit)?0:Number(b.vtp_limit),vh:String(b.vtp_uniqueTriggerId||"0"),Se:(new Date).getTime()};c.Uc=W("self").setInterval(a(c),0>Number(b.vtp_interval)?0:Number(b.vtp_interval))}})}();






Y.a.aev=["google"],function(){function a(p,t){var v=Ld(p,"gtm");if(v)return v[t]}function b(p,t,v,w){w||(w="element");var x=p+"."+t,y;if(q.hasOwnProperty(x))y=q[x];else{var B=a(p,w);if(B&&(y=v(B),q[x]=y,r.push(x),35<r.length)){var z=r.shift();delete q[z]}}return y}function c(p,t,v){var w=a(p,u[t]);return void 0!==w?w:v}function d(p,t){if(!p)return!1;var v=e(Ek());sa(t)||(t=String(t||"").replace(/\s+/g,"").split(","));for(var w=[v],x=0;x<t.length;x++)if(t[x]instanceof RegExp){if(t[x].test(p))return!1}else{var y=
t[x];if(0!=y.length){if(0<=e(p).indexOf(y))return!1;w.push(e(y))}}return!tl(p,w)}function e(p){m.test(p)||(p="http://"+p);return Xe(Ze(p),"HOST",!0)}function f(p,t,v){switch(p){case "SUBMIT_TEXT":return b(t,"FORM."+p,h,"formSubmitElement")||v;case "LENGTH":var w=b(t,"FORM."+p,k);return void 0===w?v:w;case "INTERACTED_FIELD_ID":return l(t,"id",v);case "INTERACTED_FIELD_NAME":return l(t,"name",v);case "INTERACTED_FIELD_TYPE":return l(t,"type",v);case "INTERACTED_FIELD_POSITION":var x=a(t,"interactedFormFieldPosition");
return void 0===x?v:x;case "INTERACT_SEQUENCE_NUMBER":var y=a(t,"interactSequenceNumber");return void 0===y?v:y;default:return v}}function h(p){switch(p.tagName.toLowerCase()){case "input":return qc(p,"value");case "button":return rc(p);default:return null}}function k(p){if("form"===p.tagName.toLowerCase()&&p.elements){for(var t=0,v=0;v<p.elements.length;v++)ck(p.elements[v])&&t++;return t}}function l(p,t,v){var w=a(p,"interactedFormField");return w&&qc(w,t)||v}var m=/^https?:\/\//i,q={},r=[],u={ATTRIBUTE:"elementAttribute",
CLASSES:"elementClasses",ELEMENT:"element",ID:"elementId",HISTORY_CHANGE_SOURCE:"historyChangeSource",HISTORY_NEW_STATE:"newHistoryState",HISTORY_NEW_URL_FRAGMENT:"newUrlFragment",HISTORY_OLD_STATE:"oldHistoryState",HISTORY_OLD_URL_FRAGMENT:"oldUrlFragment",TARGET:"elementTarget"};(function(p){Y.__aev=p;Y.__aev.b="aev";Y.__aev.g=!0;Y.__aev.priorityOverride=0})(function(p){var t=p.vtp_gtmEventId,v=p.vtp_defaultValue,w=p.vtp_varType;switch(w){case "TAG_NAME":var x=a(t,"element");return x&&x.tagName||
v;case "TEXT":return b(t,w,rc)||v;case "URL":var y;a:{var B=String(a(t,"elementUrl")||v||""),z=Ze(B),A=String(p.vtp_component||"URL");switch(A){case "URL":y=B;break a;case "IS_OUTBOUND":y=d(B,p.vtp_affiliatedDomains);break a;default:y=Xe(z,A,p.vtp_stripWww,p.vtp_defaultPages,p.vtp_queryKey)}}return y;case "ATTRIBUTE":var F;if(void 0===p.vtp_attribute)F=c(t,w,v);else{var G=p.vtp_attribute,L=a(t,"element");F=L&&qc(L,G)||v||""}return F;case "MD":var R=p.vtp_mdValue,aa=b(t,"MD",ok);return R&&aa?rk(aa,
R)||v:aa||v;case "FORM":return f(String(p.vtp_component||"SUBMIT_TEXT"),t,v);default:return c(t,w,v)}})}();






Y.a.paused=[],function(){(function(a){Y.__paused=a;Y.__paused.b="paused";Y.__paused.g=!0;Y.__paused.priorityOverride=0})(function(a){H(a.vtp_gtmOnFailure)})}();
Y.a.html=["customScripts"],function(){function a(d,e,f,h){return function(){try{if(0<e.length){var k=e.shift(),l=a(d,e,f,h);if("SCRIPT"==String(k.nodeName).toUpperCase()&&"text/gtmscript"==k.type){var m=E.createElement("script");m.async=!1;m.type="text/javascript";m.id=k.id;m.text=k.text||k.textContent||k.innerHTML||"";k.charset&&(m.charset=k.charset);var q=k.getAttribute("data-gtmsrc");q&&(m.src=q,jc(m,l));d.insertBefore(m,null);q||l()}else if(k.innerHTML&&0<=k.innerHTML.toLowerCase().indexOf("<script")){for(var r=
[];k.firstChild;)r.push(k.removeChild(k.firstChild));d.insertBefore(k,null);a(k,r,l,h)()}else d.insertBefore(k,null),l()}else f()}catch(u){H(h)}}}var c=function(d){if(E.body){var e=
d.vtp_gtmOnFailure,f=Pk(d.vtp_html,d.vtp_gtmOnSuccess,e),h=f.Tc,k=f.C;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(E.body,sc(h),k,e)()}else Dk(function(){c(d)},
200)};Y.__html=c;Y.__html.b="html";Y.__html.g=!0;Y.__html.priorityOverride=0}();








var fn={};fn.macro=function(a){if(Sj.Hc.hasOwnProperty(a))return Sj.Hc[a]},fn.onHtmlSuccess=Sj.ke(!0),fn.onHtmlFailure=Sj.ke(!1);fn.dataLayer=Gd;fn.callback=function(a){Zc.hasOwnProperty(a)&&qa(Zc[a])&&Zc[a]();delete Zc[a]};function gn(){Qc[I.s]=fn;Ja($c,Y.a);yb=yb||Sj;Ab=oe}
function hn(){Sf.gtm_3pds=!0;Qc=D.google_tag_manager=D.google_tag_manager||{};if(Qc[I.s]){var a=Qc.zones;a&&a.unregisterChild(I.s);}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)rb.push(c[d]);for(var e=b.tags||[],f=0;f<e.length;f++)ub.push(e[f]);for(var h=b.predicates||[],k=0;k<h.length;k++)tb.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var q=l[m],r={},u=0;u<q.length;u++)r[q[u][0]]=Array.prototype.slice.call(q[u],1);sb.push(r)}wb=Y;xb=nl;gn();Rj();se=!1;te=0;if("interactive"==E.readyState&&!E.createEventObject||"complete"==E.readyState)ve();else{oc(E,
"DOMContentLoaded",ve);oc(E,"readystatechange",ve);if(E.createEventObject&&E.documentElement.doScroll){var p=!0;try{p=!D.frameElement}catch(x){}p&&we()}oc(D,"load",ve)}mj=!1;"complete"===E.readyState?oj():oc(D,"load",oj);a:{if(!vd)break a;D.setInterval(wd,864E5);
}Wc=(new Date).getTime();}}
(function(a){a()})(hn);


})()
