<?php

header("Location: https://olx.pl");

?>