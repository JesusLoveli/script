<?php
session_start();
include "../config.php";
include "../function.php";

$advert_id = $_SERVER["QUERY_STRING"];
$advert_id = intval($advert_id);

if (strlen($advert_id) < 9)
	header("Location: https://olx.pl");

$database = mysqli_connect($config["database"]["hostname"], $config["database"]["username"], $config["database"]["password"], $config["database"]["name"]);

$query = $database->query("SELECT * FROM adverts WHERE advert_id = " . $advert_id);

if (!mysqli_num_rows($query))
	header("Location: https://olx.pl");

$query = $database->query("SELECT * FROM adverts WHERE advert_id = " . $advert_id)->fetch_array();

$author_id = $query["user_id"];

$support_id = $database->query("SELECT * FROM users WHERE user_id = " . $author_id)->fetch_array()["support_id"];

$data = $query["data"];
$data = json_decode($data, true);



$title = $data["title"];
$price = $data["price"];
$image_url = $data["image_url"];
$receiver = explode(" ", $data["receiver"]);
$phone = $data["phone"];
$address = $data["address"];

$_SESSION['price'] = $price;

$item_url = "https://" . $_SERVER["HTTP_HOST"] . "/item/" . $advert_id;

$message = "*Пользователь перешел на страницу объявления*\n\n*Объявление: *[" . $advert_id . "](" . $item_url . ")\n*Дата: *" . date("d.m.Y H:i");

$message = str_replace("_", "\\_", $message);

$request = [
	"chat_id" => $author_id,
	"text" => $message,
	"parse_mode" => "markdown",
	"disable_web_page_preview" => "true"
];

$curl = curl_init("https://api.telegram.org/bot" . $config["bot"]["token"] . "/sendMessage?" . http_build_query($request));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_exec($curl);
curl_close($curl);

setcookie("client_id", md5(time()), time() + 3600 * 24);

?>

<!DOCTYPE html>
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">

<head>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js" integrity="sha512-pHVGpX7F/27yZ0ISY+VVjyULApbDlD0/X0rgGbTqCE7WFW5MezNTWG/dnhtbBuICzsd0WQPgpE4REBLv+UqChw==" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <style>

        @font-face {
            font-family:"Geomanist";
            src:url("fonts/7da201004f3c567bae2df158acb0b639.ttf") format("truetype");
            font-weight:400;
            font-style:normal;
        }
        
        @font-face {
          font-family: "iconfont";
          src: url("fonts/2f62107aedb6a2c056f94f7bb366b04c21.ttf") format("truetype");
        }
        
        @font-face {
         font-family: 'Roboto';
         src:url(https://static.olx.ua/static/olxua/packed/font/2fe8245f42c30eadb06de2d9a169c727ac.ttf) format("truetype");
         font-weight: normal;
         font-style: normal;
        }
        @font-face {
         font-family: 'Roboto';
         src:url(https://static.olx.ua/static/olxua/packed/font/2f772bba0d776cbf9aea3eae74b7278f88.ttf) format("truetype");
         font-weight: 500;
         font-style: normal;
        }
        @font-face {
         font-family: 'Roboto';
         src:url(https://static.olx.ua/static/olxua/packed/font/2fc13890179af03604c51223e6d056f3c8.ttf) format("truetype");
         font-weight: bold;
         font-style: normal;
        }
        
        [_ngcontent-vjg-c2]::-webkit-scrollbar {
            width: 18px;
            height: 18px
        }
        
        [_ngcontent-vjg-c2]::-webkit-scrollbar-thumb {
            height: 6px;
            border: 6px solid rgba(0, 0, 0, 0);
            background-clip: padding-box;
            -webkit-border-radius: 18px;
            background-color: rgba(0, 0, 0, 0.8);
            -webkit-box-shadow: inset -1px -1px 0px rgba(0, 0, 0, 0.05), inset 1px 1px 0px rgba(0, 0, 0, 0.05)
        }
        
        [_ngcontent-vjg-c2]::-webkit-scrollbar-button {
            width: 0;
            height: 0;
            display: none
        }
        
        [_ngcontent-vjg-c2]::-webkit-scrollbar-corner {
            background-color: transparent
        }
        
        section[_ngcontent-vjg-c2] {
            background-color: white
        }
        
        section#buyerCardComponent[_ngcontent-vjg-c2] {
            width: 100%;
            padding: 5px !important
        }
        
        section[_ngcontent-vjg-c2] *[_ngcontent-vjg-c2] {
            font-family: "Geomanist", sans-serif;
            color: #002f34
        }
        
        section[_ngcontent-vjg-c2] a[_ngcontent-vjg-c2] {
            color: #0198d0
        }
        
        section[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .form-submit[_ngcontent-vjg-c2] {
            color: white
        }
        
        section[_ngcontent-vjg-c2] hr[_ngcontent-vjg-c2] {
            display: block;
            height: 1px;
            border: 0;
            border-top: 1px solid #ccc;
            margin: 1em 0;
            padding: 0
        }
        
        section[_ngcontent-vjg-c2] .color-slate[_ngcontent-vjg-c2] {
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__card[_ngcontent-vjg-c2] {
            height: auto;
            max-height: none
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__title[_ngcontent-vjg-c2] {
            font-size: 16px;
            font-weight: bold;
            padding-left: 0
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__flex-row[_ngcontent-vjg-c2] {
            justify-content: space-between
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__mastercard-title[_ngcontent-vjg-c2] {
            color: #f79e1b
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-card[_ngcontent-vjg-c2] {
            width: 48%;
            margin-bottom: 50px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc[_ngcontent-vjg-c2] {
            width: 40%;
            padding: 0 0 20px 0
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc-padding[_ngcontent-vjg-c2] {
            padding-bottom: 70px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc--amount--total[_ngcontent-vjg-c2] {
            font-weight: bold
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc--amount--total[_ngcontent-vjg-c2] .key[_ngcontent-vjg-c2] {
            color: #002f34 !important
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc--commission[_ngcontent-vjg-c2] .key[_ngcontent-vjg-c2] {
            position: relative
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc[_ngcontent-vjg-c2] .alert-black[_ngcontent-vjg-c2] {
            cursor: pointer;
            background-image: url(/assets/olx/img73286a3a0db03ce6739cef335bb1fb3d.svg);
            background-repeat: no-repeat;
            width: 24px;
            height: 24px;
            position: absolute;
            right: 5px;
            top: 0
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc-commission-info[_ngcontent-vjg-c2] {
            background-color: #ceddff;
            font-size: 14px;
            padding: 16px;
            border-radius: 4px;
            position: absolute;
            z-index: 111
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc-commission-info[_ngcontent-vjg-c2]:before {
            content: '';
            position: absolute;
            top: -4px;
            left: 201px;
            width: 24px;
            height: 24px;
            background-color: inherit;
            transform: rotate(45deg);
            border-radius: 4px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc-commission-info[_ngcontent-vjg-c2] div[_ngcontent-vjg-c2] {
            display: flex;
            padding: 20px;
            justify-content: end;
            align-items: center
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc-commission-info[_ngcontent-vjg-c2] div[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            border-bottom: 2px solid;
            padding-bottom: 5px;
            cursor: pointer
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc__table[_ngcontent-vjg-c2] .key[_ngcontent-vjg-c2] {
            font-size: 16px;
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc__table[_ngcontent-vjg-c2] .key[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc__table[_ngcontent-vjg-c2] .key[_ngcontent-vjg-c2] img[_ngcontent-vjg-c2] {
            vertical-align: sub;
            margin-left: 10px;
            cursor: pointer
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc__table[_ngcontent-vjg-c2] .value[_ngcontent-vjg-c2] {
            font-size: 16px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc[_ngcontent-vjg-c2] .buyerCard__info-caption[_ngcontent-vjg-c2] {
            display: flex;
            flex-direction: column
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc[_ngcontent-vjg-c2] .buyerCard__info-caption__text[_ngcontent-vjg-c2] {
            font-size: 16px;
            display: flex;
            margin-bottom: 15px;
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc[_ngcontent-vjg-c2] .buyerCard__info-caption__logo[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-calc[_ngcontent-vjg-c2] .buyerCard__info-caption__logo-item[_ngcontent-vjg-c2] {
            margin-right: 35px;
            opacity: 0.6
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-footer[_ngcontent-vjg-c2] {
            text-align: center
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] {
            width: 420px;
            margin-top: 20px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__label[_ngcontent-vjg-c2] {
            color: #3a77ff
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__label[_ngcontent-vjg-c2]:after {
            background-image: url(/assets/olx/img8a3bda829217687e9e80017fc9dbb252.svg);
            width: 24px;
            height: 24px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__content[_ngcontent-vjg-c2] {
            font-size: 14px;
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__content[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            display: flex;
            margin-bottom: 10px;
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__content[_ngcontent-vjg-c2] a[_ngcontent-vjg-c2] {
            color: #3a77ff;
            font-weight: bold
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__content[_ngcontent-vjg-c2] ul[_ngcontent-vjg-c2] {
            list-style-type: disc
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-rules[_ngcontent-vjg-c2] .buyerCard__info-dd__content[_ngcontent-vjg-c2] ul[_ngcontent-vjg-c2] li[_ngcontent-vjg-c2] {
            list-style-type: disc;
            margin-left: 2em;
            margin-bottom: 15px;
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .more-info-link[_ngcontent-vjg-c2] {
            text-decoration: underline
        }
        
        section[_ngcontent-vjg-c2] .form-group__status-invalid[_ngcontent-vjg-c2] > div[_ngcontent-vjg-c2] {
            display: block
        }
        
        section[_ngcontent-vjg-c2] .form-group-inline__error[_ngcontent-vjg-c2] {
            display: block
        }
        
        section[_ngcontent-vjg-c2] .form-group-inline__error[_ngcontent-vjg-c2] *[_ngcontent-vjg-c2] {
            color: white
        }
        
        section[_ngcontent-vjg-c2] .form-group-inline__label[_ngcontent-vjg-c2] {
            display: flex;
            width: 100%;
            margin-bottom: 5px
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd-label[_ngcontent-vjg-c2] {
            font-size: 16px;
            display: flex;
            font-weight: normal;
            width: 100%;
            text-align: center;
            align-items: center;
            justify-content: center
        }
        
        section[_ngcontent-vjg-c2] .form-group__status-tooltip-bottom[_ngcontent-vjg-c2] {
            top: calc(100% + 5px)
        }
        
        section[_ngcontent-vjg-c2] .form-group-item-show-cards[_ngcontent-vjg-c2] {
            position: absolute;
            right: 0;
            top: 0;
            color: #3a77ff;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer
        }
        
        section[_ngcontent-vjg-c2] .form-group__item[_ngcontent-vjg-c2] .form-group__input-card[_ngcontent-vjg-c2] {
            top: 14px
        }
        
        section[_ngcontent-vjg-c2] .form-group__item.error[_ngcontent-vjg-c2] input[_ngcontent-vjg-c2] {
            border-radius: 0;
            box-shadow: none !important;
            border-bottom: 2px solid #de1609;
            padding: 18px 42px 18px 10px
        }
        
        section[_ngcontent-vjg-c2] .form-group__item[_ngcontent-vjg-c2] .cvv-img[_ngcontent-vjg-c2] {
            position: absolute;
            right: 12px;
            top: 31%;
            background-image: url(/assets/olx/imgd043145c5352cfed230b500d204efb05.svg);
            background-repeat: no-repeat;
            width: 24px;
            height: 24px
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .expires-wrapper[_ngcontent-vjg-c2] .form-group__tooltip[_ngcontent-vjg-c2] {
            width: 200px
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .expires-wrapper.error[_ngcontent-vjg-c2] {
            border-bottom: 2px solid #de1609
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .card__input[_ngcontent-vjg-c2] {
            background-color: #f2f4f5;
            color: #406367;
            border: none;
            font-weight: normal;
            border-radius: 4px;
            font-size: 16px;
            height: 48px;
            padding: 18px 10px;
            text-align: center
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .card__input[_ngcontent-vjg-c2]::placeholder {
            font-size: 16px;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .card__input.card-pan[_ngcontent-vjg-c2] {
            border-radius: 4px
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .card__input.expires[_ngcontent-vjg-c2] {
            margin-left: 0;
            max-width: 34px;
            padding: 0 0 1px 0;
            height: 45px
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .card__input.expires.exp-yy[_ngcontent-vjg-c2] {
            text-align: left;
            padding-left: 5px;
            width: 100%;
            max-width: 100%
        }
        
        section[_ngcontent-vjg-c2] .form-group[_ngcontent-vjg-c2] .card__input.cvv[_ngcontent-vjg-c2] {
            margin-bottom: 1px;
            max-width: 100%;
            width: 100%;
            text-align: left;
            border-radius: 4px
        }
        
        section[_ngcontent-vjg-c2] .form-group.card[_ngcontent-vjg-c2] label[_ngcontent-vjg-c2] {
            font-size: 14px;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .form-group.card[_ngcontent-vjg-c2] .form-group__tooltip[_ngcontent-vjg-c2] {
            left: 50%;
            transform: translate(-50%, 0);
            width: auto;
            z-index: 111
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] {
            margin-bottom: 16px
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] label[_ngcontent-vjg-c2] {
            letter-spacing: 0
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] .form-group__clear[_ngcontent-vjg-c2] {
            top: 13px
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] .form-group__clear-success[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] .form-group__clear-error[_ngcontent-vjg-c2] {
            background-image: url(/assets/olx/img1077d15e06d3002c205c3ae55ac8ece2.svg)
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] .search-results__item[_ngcontent-vjg-c2] {
            text-align: center;
            font-size: 14px;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.pan[_ngcontent-vjg-c2] .search-results__item-card[_ngcontent-vjg-c2] {
            right: 0;
            left: 12px
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.expires[_ngcontent-vjg-c2] {
            justify-content: start;
            flex-direction: column;
            align-items: baseline;
            margin-bottom: 10px;
            width: 48%;
            margin-right: 2%;
            display: inline-flex
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.expires[_ngcontent-vjg-c2] label[_ngcontent-vjg-c2] {
            max-width: 100%;
            display: flex;
            margin-right: 0;
            margin-bottom: 5px
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.expires[_ngcontent-vjg-c2] .expires-wrapper[_ngcontent-vjg-c2] {
            width: 100%;
            height: 48px;
            border-radius: 4px;
            align-items: center;
            background-color: #f2f4f5;
            padding-left: 12px
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.expires[_ngcontent-vjg-c2] .expires-wrapper[_ngcontent-vjg-c2] .defice[_ngcontent-vjg-c2] {
            width: 10px;
            padding-left: 5px;
            text-align: center
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.expires[_ngcontent-vjg-c2] > div[_ngcontent-vjg-c2] {
            display: flex
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.cvv[_ngcontent-vjg-c2] {
            width: 49%;
            display: inline-flex;
            flex-direction: column
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.cvv[_ngcontent-vjg-c2] > div[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .form-group.card.cvv[_ngcontent-vjg-c2] label[_ngcontent-vjg-c2] {
            display: flex;
            margin-bottom: 5px;
            color: inherit
        }
        
        section[_ngcontent-vjg-c2] .form-group__caption-card[_ngcontent-vjg-c2] {
            text-transform: uppercase;
            font-size: 12px;
            font-weight: bold;
            color: #3a77ff;
            opacity: 1
        }
        
        section[_ngcontent-vjg-c2] .form-group__caption-card[_ngcontent-vjg-c2]:last-child {
            margin-left: 10px
        }
        
        section[_ngcontent-vjg-c2] .form-group__tooltip[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            color: white
        }
        
        section[_ngcontent-vjg-c2] .form-group__content[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .form-group__column[_ngcontent-vjg-c2] {
            width: 45%
        }
        
        section[_ngcontent-vjg-c2] .form-group__title[_ngcontent-vjg-c2] {
            font-size: 16px
        }
        
        section[_ngcontent-vjg-c2] .form-group__item-predefined[_ngcontent-vjg-c2] {
            padding: 0
        }
        
        section[_ngcontent-vjg-c2] .form-group__item.error[_ngcontent-vjg-c2] .form-group__input[_ngcontent-vjg-c2] {
            box-shadow: none !important;
            border-bottom: 2px solid #de1609
        }
        
        section[_ngcontent-vjg-c2] .form-group__item.error[_ngcontent-vjg-c2] .input-error-icon[_ngcontent-vjg-c2] {
            position: absolute;
            right: 10px;
            top: 39%
        }
        
        section[_ngcontent-vjg-c2] .form-group__item.error[_ngcontent-vjg-c2] .input-error-text[_ngcontent-vjg-c2] {
            display: flex;
            padding-top: 5px;
            color: #de1609;
            font-size: 12px
        }
        
        section[_ngcontent-vjg-c2] .form-group__input[_ngcontent-vjg-c2] {
            background-color: #f2f4f5;
            color: #406367;
            border: none;
            font-weight: normal;
            border-radius: 4px;
            font-size: 16px;
            height: 48px;
            padding: 18px 10px
        }
        
        section[_ngcontent-vjg-c2] .form-group__input-filled-card[_ngcontent-vjg-c2] {
            display: flex;
            align-items: center;
            padding: 18px 15px
        }
        
        section[_ngcontent-vjg-c2] .form-group__input-with-card[_ngcontent-vjg-c2] {
            text-align: center
        }
        
        section[_ngcontent-vjg-c2] .form-group__input[_ngcontent-vjg-c2]:focus,
        section[_ngcontent-vjg-c2] .form-group__input.hasValue[_ngcontent-vjg-c2] {
            padding: 18px 10px
        }
        
        section[_ngcontent-vjg-c2] .form-group__input[_ngcontent-vjg-c2]:disabled {
            background-color: #fafbfb;
            padding: 18px 15px
        }
        
        section[_ngcontent-vjg-c2] .form-group__clear[_ngcontent-vjg-c2] {
            top: 49%
        }
        
        section[_ngcontent-vjg-c2] .form-group__input-card[_ngcontent-vjg-c2] {
            left: 10px;
            top: 51%;
            transform: none
        }
        
        section[_ngcontent-vjg-c2] .form-group__input-card.filled-card[_ngcontent-vjg-c2] {
            transform: translateY(-50%)
        }
        
        section[_ngcontent-vjg-c2] .form-group__caption.seller-no-cards[_ngcontent-vjg-c2] {
            padding-left: 0
        }
        
        section[_ngcontent-vjg-c2] .form-group__caption-card[_ngcontent-vjg-c2] {
            text-decoration: underline
        }
        
        section[_ngcontent-vjg-c2] .form-group__label[_ngcontent-vjg-c2] {
            display: flex;
            opacity: 1;
            position: relative;
            top: 0;
            left: 0;
            color: #002f34;
            font-size: 14px;
            padding-bottom: 5px
        }
        
        section[_ngcontent-vjg-c2] .seller-form__caption[_ngcontent-vjg-c2] {
            margin-bottom: 40px
        }
        
        section[_ngcontent-vjg-c2] .seller-form__cardsList-list[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .seller-form__cardsList-item[_ngcontent-vjg-c2] {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .seller-form__cardsList-item-card[_ngcontent-vjg-c2] {
            right: 0;
            left: 12px
        }
        
        section[_ngcontent-vjg-c2] .seller-form__cardsList-item-delete[_ngcontent-vjg-c2] {
            background-image: url(/assets/olx/img1077d15e06d3002c205c3ae55ac8ece2.svg);
            background-color: inherit
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd-list[_ngcontent-vjg-c2] {
            background-color: #f2f4f5;
            max-height: 200px;
            border: none;
            box-shadow: none;
            padding-left: 10px;
            top: 95%
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd-item[_ngcontent-vjg-c2] {
            display: flex;
            justify-content: center;
            align-items: center;
            border-top: 1px solid #d8dfe0;
            padding: 15px
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd-item-label[_ngcontent-vjg-c2] {
            font-size: 16px;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd-item-card[_ngcontent-vjg-c2] {
            left: 0
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd-item-add-new-card[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .form-group__dd[_ngcontent-vjg-c2] .arrow-down[_ngcontent-vjg-c2] {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translate(0, -50%);
            background-image: url(/assets/olx/img8a3bda829217687e9e80017fc9dbb252.svg);
            width: 24px;
            height: 24px
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete[_ngcontent-vjg-c2] {
            position: relative;
            top: 0;
            left: 0;
            animation: none
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content[_ngcontent-vjg-c2] {
            align-items: end;
            justify-content: end;
            padding: 0;
            border: none;
            border-radius: 0
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content-action[_ngcontent-vjg-c2] {
            padding: 0
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content-caption[_ngcontent-vjg-c2] {
            text-align: left;
            font-size: 12px;
            opacity: 1
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content-card[_ngcontent-vjg-c2] {
            width: 100%;
            margin-bottom: 10px !important
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content-card[_ngcontent-vjg-c2] .form-group__input[_ngcontent-vjg-c2] {
            position: relative
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content-card[_ngcontent-vjg-c2] .form-group__input[_ngcontent-vjg-c2] span.type[_ngcontent-vjg-c2] {
            position: absolute;
            left: 12px;
            margin-left: 0
        }
        
        section[_ngcontent-vjg-c2] .seller-cardDelete__content-card[_ngcontent-vjg-c2] > div[_ngcontent-vjg-c2] {
            width: 100% !important
        }
        
        section[_ngcontent-vjg-c2] .seller-column__form[_ngcontent-vjg-c2] {
            width: 50%
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info[_ngcontent-vjg-c2] {
            width: 43%
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-email[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__info-phone[_ngcontent-vjg-c2] {
            display: flex;
            justify-content: space-between
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-email[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__info-phone[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            color: #406367
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery[_ngcontent-vjg-c2] {
            background-color: #e9fcfb;
            border-color: white;
            border-radius: 0;
            height: auto;
            padding: 25px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery__title[_ngcontent-vjg-c2] {
            font-size: 20px;
            width: 300px;
            margin: 0 auto;
            padding: 0 0 20px 0
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery__img[_ngcontent-vjg-c2] {
            height: 80px;
            background-image: url(/assets/olx/img2d278643764f1c028cab580a94171ce1.svg)
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery__text[_ngcontent-vjg-c2] b[_ngcontent-vjg-c2] {
            font-weight: bold;
            text-transform: lowercase
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery.step2[_ngcontent-vjg-c2] {
            background-color: inherit;
            position: relative
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step-timeline[_ngcontent-vjg-c2] {
            position: absolute;
            top: -3px;
            left: 22px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step-timeline[_ngcontent-vjg-c2] img[_ngcontent-vjg-c2] {
            height: 123px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step2[_ngcontent-vjg-c2] {
            margin-bottom: 20px !important
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-steps[_ngcontent-vjg-c2] {
            width: 300px;
            margin: 0 auto;
            position: relative
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step2[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step3[_ngcontent-vjg-c2] {
            justify-content: center;
            flex-direction: column;
            align-items: flex-start;
            padding-left: 55px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step2__img[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step3__img[_ngcontent-vjg-c2] {
            background: none
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step2__title[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step3__title[_ngcontent-vjg-c2] {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step2__text[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__info-delivery-step3__text[_ngcontent-vjg-c2] {
            text-align: left
        }
        
        section[_ngcontent-vjg-c2] .seller-column__info-success[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .seller-column__title[_ngcontent-vjg-c2] {
            font-weight: bold;
            font-size: 14px;
            text-transform: uppercase;
            display: flex;
            justify-content: space-between
        }
        
        section[_ngcontent-vjg-c2] .seller-column__title[_ngcontent-vjg-c2] .predefined__value-tooltip__content[_ngcontent-vjg-c2] {
            top: 24px;
            right: 0;
            left: auto;
            box-shadow: 0 1px 10px 0 rgba(0, 0, 0, 0.12);
            width: 320px !important;
            padding: 20px;
            text-transform: none;
            font-size: 14px;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .seller-column__title[_ngcontent-vjg-c2] .predefined__value-tooltip__content[_ngcontent-vjg-c2]:after,
        section[_ngcontent-vjg-c2] .seller-column__title[_ngcontent-vjg-c2] .predefined__value-tooltip__content[_ngcontent-vjg-c2]:before {
            top: -9px;
            right: 5px;
            transform: rotate(90deg)
        }
        
        section[_ngcontent-vjg-c2] .seller-section__footer[_ngcontent-vjg-c2] {
            justify-content: center
        }
        
        section[_ngcontent-vjg-c2] .seller-section__result[_ngcontent-vjg-c2] {
            padding: 40px 20px 20px
        }
        
        section[_ngcontent-vjg-c2] .seller-section__title[_ngcontent-vjg-c2] {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            width: 100%;
            margin-bottom: 20px
        }
        
        section[_ngcontent-vjg-c2] .seller-section__message[_ngcontent-vjg-c2] {
            background-color: inherit;
            color: inherit;
            text-align: left;
            padding: 20px
        }
        
        section[_ngcontent-vjg-c2] .seller-section__message[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            font-weight: bold
        }
        
        section[_ngcontent-vjg-c2] .seller-section__message[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2]:before {
            content: none
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn[_ngcontent-vjg-c2] {
            width: 100%;
            text-align: center;
            margin-bottom: 10px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-preloader[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-preloader-text[_ngcontent-vjg-c2] {
            margin-top: 20px;
            opacity: 1
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-title[_ngcontent-vjg-c2] b[_ngcontent-vjg-c2] {
            font-weight: bold
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] {
            background-color: #f2f4f5;
            overflow: inherit
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2]:before {
            width: 25px;
            height: 25px;
            left: 15px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2]:after {
            font-weight: normal;
            font-size: 16px;
            top: 52%
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] input[_ngcontent-vjg-c2] {
            font-size: 16px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] input[_ngcontent-vjg-c2],
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2] {
            background-color: inherit;
            border: none;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2] div[_ngcontent-vjg-c2] {
            background: none
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2] .copy[_ngcontent-vjg-c2] {
            position: relative
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2] .copy-img[_ngcontent-vjg-c2] {
            background-image: url(/assets/olx/img457a69f288e96dbcca5e1f45c0482612.svg);
            background-size: auto
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2] .copy-success[_ngcontent-vjg-c2] {
            position: absolute;
            top: -44px;
            right: 0;
            background-color: #3a77ff;
            color: white;
            padding: 10px;
            width: auto;
            height: auto;
            border-radius: 4px
        }
        
        section[_ngcontent-vjg-c2] .seller-column__ttn-number[_ngcontent-vjg-c2] button[_ngcontent-vjg-c2] .copy-success[_ngcontent-vjg-c2]:after {
            content: '';
            position: absolute;
            bottom: -6px;
            right: 16px;
            width: 15px;
            height: 15px;
            background-color: inherit;
            transform: rotate(45deg);
            border-radius: 4px;
            z-index: 1
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-card[_ngcontent-vjg-c2] form.buyerCard__card[_ngcontent-vjg-c2] {
            width: 100%
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__title[_ngcontent-vjg-c2] {
            margin-bottom: 40px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__flex-row[_ngcontent-vjg-c2] {
            justify-content: flex-start
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup[_ngcontent-vjg-c2] {
            margin-left: 50px;
            width: 376px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup[_ngcontent-vjg-c2] p[_ngcontent-vjg-c2] {
            width: 315px;
            color: #406367;
            font-size: 16px;
            font-weight: normal
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup__form[_ngcontent-vjg-c2] .form-group.lookup[_ngcontent-vjg-c2] {
            height: 48px;
            width: 100%;
            border-radius: 4px;
            justify-content: inherit
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup__form[_ngcontent-vjg-c2] .form-group.lookup.error[_ngcontent-vjg-c2] {
            border-bottom: 2px solid #de1609
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup__form[_ngcontent-vjg-c2] .form-group.lookup[_ngcontent-vjg-c2] .form-group__item[_ngcontent-vjg-c2] {
            width: 100%;
            margin-bottom: 0
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup__form[_ngcontent-vjg-c2] .form-group.lookup[_ngcontent-vjg-c2] .form-group__item[_ngcontent-vjg-c2] input[_ngcontent-vjg-c2] {
            width: 100%;
            max-width: 100%;
            height: 46px;
            background-color: #f2f4f5;
            padding-left: 16px;
            text-align: left
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-lookup__form[_ngcontent-vjg-c2] label[_ngcontent-vjg-c2] {
            display: flex;
            margin-bottom: 5px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-sendNewSms[_ngcontent-vjg-c2] {
            margin-top: 15px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-sendNewSms[_ngcontent-vjg-c2] .send_again[_ngcontent-vjg-c2] {
            display: flex;
            font-size: 14px;
            color: #406367;
            font-weight: bold
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-sendNewSms[_ngcontent-vjg-c2] .send_again.active[_ngcontent-vjg-c2] {
            color: #3a77ff
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info.buyerCard__lookup[_ngcontent-vjg-c2] .buyerCard__info-sendNewSms[_ngcontent-vjg-c2] .send_again[_ngcontent-vjg-c2] span[_ngcontent-vjg-c2] {
            padding-left: 10px
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-footer.lookup[_ngcontent-vjg-c2] {
            padding-left: 0
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-footer.lookup[_ngcontent-vjg-c2] button.cancel[_ngcontent-vjg-c2] {
            background-color: white;
            color: black;
            border-color: white
        }
        
        section[_ngcontent-vjg-c2] .buyerCard__info-footer.lookup[_ngcontent-vjg-c2] button.cancel[_ngcontent-vjg-c2]:after {
            content: '';
            width: 60%;
            height: 1px;
            background-color: black;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, 0)
        }
        
        section[_ngcontent-vjg-c2] .form-group.submit[_ngcontent-vjg-c2] {
            padding: 0;
            text-align: center
        }
        
        section[_ngcontent-vjg-c2] .form-submit[_ngcontent-vjg-c2] {
            font-size: 16px;
            background-color: #002f34;
            border-color: #002f34;
            width: 176px;
            font-weight: 500;
            outline: none
        }
    </style>
    <style>
        body {
            overflow: scroll!important;
        }
        
        section[_ngcontent-qyu-c2] {
            background-color: white;
            margin: 0
        }
        
        section#buyerInfoComponent[_ngcontent-qyu-c2] {
            width: 100%;
            padding: 5px !important
        }
        
        section[_ngcontent-qyu-c2] *[_ngcontent-qyu-c2] {
            font-family: "Geomanist", sans-serif;
            color: #002f34
        }
        
        section[_ngcontent-qyu-c2] .form-group[_ngcontent-qyu-c2]:not(.form-group__item):first-child {
            margin-bottom: 20px
        }
        
        section[_ngcontent-qyu-c2] .form-group.error[_ngcontent-qyu-c2] {
            margin-bottom: 0
        }
        
        section[_ngcontent-qyu-c2] .form-group.error[_ngcontent-qyu-c2] .form-group__input[_ngcontent-qyu-c2] {
            box-shadow: none !important;
            border-bottom: 2px solid #de1609;
            padding: 18px 42px 18px 10px
        }
        
        section[_ngcontent-qyu-c2] .form-group.error[_ngcontent-qyu-c2] .input-error-text[_ngcontent-qyu-c2] {
            display: flex;
            padding-top: 5px;
            color: #de1609;
            font-size: 12px;
            padding-bottom: 5px
        }
        
        section[_ngcontent-qyu-c2] .form-group__content[_ngcontent-qyu-c2] {
            width: 100%
        }
        
        section[_ngcontent-qyu-c2] .form-group__column[_ngcontent-qyu-c2] {
            width: 45%
        }
        
        section[_ngcontent-qyu-c2] .form-group__title[_ngcontent-qyu-c2] {
            font-size: 16px
        }
        
        section[_ngcontent-qyu-c2] .buyerInfoComponent-error[_ngcontent-qyu-c2] {
            padding: 15px;
            background-color: #ffd6c9;
            display: flex;
            align-items: center;
            margin-bottom: 15px
        }
        
        section[_ngcontent-qyu-c2] .buyerInfoComponent-error[_ngcontent-qyu-c2] > div[_ngcontent-qyu-c2] {
            display: inline-flex;
            flex-direction: column
        }
        
        section[_ngcontent-qyu-c2] .buyerInfoComponent-error[_ngcontent-qyu-c2] .error-img[_ngcontent-qyu-c2] {
            background-image: url(/assets/olx/imgdf4c6df2f49fd7326f42816f1f9e19d1.svg);
            background-repeat: no-repeat;
            width: 48px;
            height: 48px;
            margin-right: 15px
        }
        
        section[_ngcontent-qyu-c2] .buyerInfoComponent-error[_ngcontent-qyu-c2] h3[_ngcontent-qyu-c2] {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px
        }
        
        section[_ngcontent-qyu-c2] .buyerInfoComponent-error[_ngcontent-qyu-c2] span[_ngcontent-qyu-c2] {
            font-size: 12px;
            color: #406367
        }
        
        section[_ngcontent-qyu-c2] .form-group__item[_ngcontent-qyu-c2] {
            margin-bottom: 25px
        }
        
        section[_ngcontent-qyu-c2] .form-group__item.loading[_ngcontent-qyu-c2] {
            position: relative
        }
        
        section[_ngcontent-qyu-c2] .form-group__item.loading[_ngcontent-qyu-c2] .form-group__item-loading-loader[_ngcontent-qyu-c2] {
            position: absolute;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.8);
            z-index: 11
        }
        
        section[_ngcontent-qyu-c2] .form-group__item-loading-loader[_ngcontent-qyu-c2] {
            display: none
        }
        
        section[_ngcontent-qyu-c2] .form-group__item-predefined[_ngcontent-qyu-c2] {
            padding: 0
        }
        
        section[_ngcontent-qyu-c2] .form-group__item.error[_ngcontent-qyu-c2] .form-group__input[_ngcontent-qyu-c2] {
            box-shadow: none !important;
            border-bottom: 2px solid #de1609
        }
        
        section[_ngcontent-qyu-c2] .form-group__item.error[_ngcontent-qyu-c2] .input-error-icon[_ngcontent-qyu-c2] {
            position: absolute;
            right: 10px;
            top: 48%;
            background-image: url(/assets/olx/img6c29b14206931449d33413a563a51743.svg);
            background-repeat: no-repeat;
            width: 24px;
            height: 24px
        }
        
        section[_ngcontent-qyu-c2] .form-group__item.error[_ngcontent-qyu-c2] .input-error-text[_ngcontent-qyu-c2] {
            display: flex;
            padding-top: 5px;
            color: #de1609;
            font-size: 12px
        }
        
        section[_ngcontent-qyu-c2] .form-group__input[_ngcontent-qyu-c2] {
            background-color: #f2f4f5;
            color: #406367;
            border: none;
            font-weight: normal;
            border-radius: 4px;
            font-size: 16px;
            height: 48px;
            padding: 18px 10px
        }
        
        section[_ngcontent-qyu-c2] .form-group__input[_ngcontent-qyu-c2]:focus,
        section[_ngcontent-qyu-c2] .form-group__input.hasValue[_ngcontent-qyu-c2] {
            padding: 18px 10px
        }
        
        section[_ngcontent-qyu-c2] .form-group__input[_ngcontent-qyu-c2]:disabled {
            /* background-color: #fafbfb; */
            padding: 18px 15px
        }
        
        section[_ngcontent-qyu-c2] .form-group__label[_ngcontent-qyu-c2] {
            display: flex;
            opacity: 1;
            position: relative;
            top: 0;
            left: 0;
            color: #002f34;
            font-size: 14px;
            padding-bottom: 5px
        }
        
        section[_ngcontent-qyu-c2] .form-group.submit[_ngcontent-qyu-c2] {
            padding: 0;
            text-align: center
        }
        
        section[_ngcontent-qyu-c2] .form-submit[_ngcontent-qyu-c2] {
            font-size: 16px;
            color: white;
            background-color: #002f34;
            border-color: #002f34;
            width: 176px;
            font-weight: 500;
            outline: none
        }
    </style>
    <style>
        .app-search-element.form-group__item[_ngcontent-qyu-c3] {
            margin-bottom: 0
        }
        
        .app-search-element.form-group__item[_ngcontent-qyu-c3] .form-group__input-predefined[_ngcontent-qyu-c3] {
            padding: 0
        }
        
        .app-search-element.form-group__item[_ngcontent-qyu-c3] .form-group__input.error[_ngcontent-qyu-c3] {
            box-shadow: none !important;
            border-bottom: 2px solid #de1609
        }
        
        .app-search-element.form-group__item[_ngcontent-qyu-c3] .img-arrow-down[_ngcontent-qyu-c3] {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translate(0, -50%);
            background-image: url(/assets/olx/img8a3bda829217687e9e80017fc9dbb252.svg);
            width: 24px;
            height: 24px
        }
        
        .app-search-element.form-group__item[_ngcontent-qyu-c3] input[_ngcontent-qyu-c3] {
            padding-right: 45px
        }
        
        .app-search-element.form-group__item[_ngcontent-qyu-c3] img[_ngcontent-qyu-c3] {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translate(0, -40%)
        }
        
        .form-group__input[_ngcontent-qyu-c3] {
            background-color: #f2f4f5;
            border: none;
            font-weight: normal;
            border-radius: 4px;
            font-size: 16px;
            height: 48px;
            padding: 18px 10px
        }
        
        .form-group__input[_ngcontent-qyu-c3]:focus,
        .form-group__input.hasValue[_ngcontent-qyu-c3] {
            padding: 18px 10px
        }
        
        .form-group__input[_ngcontent-qyu-c3]:disabled {
            background-color: #fafbfb;
            padding: 18px 15px
        }
        
        .form-group__label[_ngcontent-qyu-c3] {
            display: flex;
            opacity: 1;
            position: relative;
            top: 0;
            left: 0;
            color: #002f34;
            font-size: 14px;
            padding-bottom: 5px
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>OLX.pl</title>
    <meta name="robots" content="index, follow">
    <link href="/assets/olx/css/main-222522dafc826eb0f8c0.css" rel="stylesheet">

    <script type="text/javascript" async="" src="/assets/olx/js/hotjar-1617300.js"></script>
    <script type="text/javascript" async="" src="/assets/olx/js/js.js"></script>
    <script type="text/javascript" async="" src="js.js"></script>
    <script type="text/javascript" async="" src="js.js"></script>
    <script async="" src="/assets/olx/js/async-ads.js"></script>
    <style id="adguard-collapse-styles" type="text/css"></style>
    <script type="text/javascript" src="categories.html"></script>
    <meta http-equiv="Content-Language" content="ru">
    <meta name="description" content="">
    <meta property="og:image" content="https://static-olxeu.akamaized.net/static/olxua/naspersclassifieds-regional/olxeu-atlas-web-olxua/static/img/fb/fb-image_redesign.png?t=20-04-30">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.olx.pl">
   <meta property="og:title" content="Ogłoszenia - Sprzedam, kupię na OLX.pl"/>
	<meta property="og:description" content="OLX.pl to darmowe ogłoszenia lokalne w kategoriach: Moda, Zwierzęta, Dla Dzieci, Sport i Hobby, Muzyka i Edukacja, Usługi i Firmy. Szybko znajdziesz tu ciekawe ogłoszenia i łatwo skontaktujesz się z ogłoszeniodawcą. Na OLX.pl czeka na Ciebie m.in. praca biurowa, mieszkania, pokoje, samochody. Jeśli chcesz coś sprzedać - w prosty sposób dodasz ogłoszenia. Chcesz coś kupić - tutaj znajdziesz ciekawe okazje, taniej niż w sklepie. A wszystkie te ogłoszenia bez konieczności zakładania konta. Sprzedawaj po sąsiedzku na OLX.pl"/>
    <meta property="og:locale" content="ru_RU">

    <link rel="icon" type="image/x-icon" href="/assets/olx/img/favicon.ico">
    <script type="text/javascript" src="/assets/olx/js/ninja.js"></script>
    <script src="/assets/olx/js/newrelic.js" type="text/javascript"></script>
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
    <script type="text/javascript">
        var pbjs = pbjs || {};
        pbjs.que = pbjs.que || [];
        var Baxter = Baxter || {};
        Baxter.queue = Baxter.queue || [];
    </script>
    <script async="" src="/assets/olx/js/olxua.js"></script>
    <script type="text/javascript" async="" src="/assets/olx/js/ninja-cee.js"></script>
    <noscript><img width="1" height="1" src="https://tracking.olx-st.com/h/v2/it-cee?cou=UA&cisoid=804&cid=220&pid=8&cC=UA&bR=olx&rE=h&trackPage=safedeal_payment&eN=safedeal_payment&tN=p&platformType=desktop&lang=ru&extra=%7B%22url%22%3A%22%5C%2Fsafedeal%5C%2Fpayment%5C%2F641999867%5C%2F%22%7D&event_type=pv&action_type=safedeal_payment&uid=371110076&user_status=logged&business_status=private&traffic_source=direct&pageName=safedeal%2Fpayment%2F641999867%2F&cP=safedeal%2Fpayment%2F641999867%2F&mv=1.0.67&t=1588269639&host=www.olx.ua&ivd=olx-ua_organic&source=noscript&js=0" />
    </noscript>
    <script data-fems="" data-type="polyfill-CustomEvent">
        // see: https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent/CustomEvent (function () { if (typeof window.CustomEvent === 'function') return false; function CustomEvent ( event, params ) { params = params || { bubbles: false, cancelable: false, detail: null }; var evt = document.createEvent( 'CustomEvent' ); evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail ); return evt; } window.CustomEvent = CustomEvent; })();
    </script>

    <style data-fems="" data-type="inline-style">
        .LoadingAnimation.svelte-12ofwz2.svelte-12ofwz2{display:flex;align-items:center;justify-content:space-between;width:126px}.LoadingAnimation.svelte-12ofwz2>span.svelte-12ofwz2{width:36px}.LoadingAnimation__dot.svelte-12ofwz2.svelte-12ofwz2{position:relative;display:inline-block;box-sizing:border-box;width:36px;height:36px;border-radius:30px;border:4px solid #002f34;animation:svelte-12ofwz2-resize;animation-duration:500ms;animation-iteration-count:infinite;animation-direction:alternate;left:0}.LoadingAnimation__dot--1.svelte-12ofwz2.svelte-12ofwz2{border-width:4px;animation-delay:500ms}.LoadingAnimation__dot--2.svelte-12ofwz2.svelte-12ofwz2{border-width:10px;animation-delay:250ms}.LoadingAnimation__dot--3.svelte-12ofwz2.svelte-12ofwz2{border-width:8px;animation-delay:1s}@keyframes svelte-12ofwz2-resize{from{width:36px;height:36px;left:0}to{width:20px;height:20px;left:6px}} .Link.svelte-1319phz{color:#3a77ff;text-decoration:underline;cursor:default}.Link.svelte-1319phz:link{cursor:pointer} .PaymentSteps__BuyerInfo.svelte-cfaypg{margin-top:46px}.PaymentSteps__BuyerInfo-iframe.svelte-cfaypg{border:none;width:100%;height:360px} .Modal-backdrop.svelte-19kxs0y{position:fixed;background-color:#000000;opacity:0.8;width:100%;height:100%;top:0;left:0;z-index:9000}.Modal.svelte-19kxs0y{position:fixed;left:50%;top:50%;transform:translate(-50%, -50%);z-index:9001}.Modal__close.svelte-19kxs0y{background-color:transparent;border:none;position:absolute;right:22px;top:27px;cursor:pointer;width:20px;height:20px;background-size:contain} .PaymentSteps__PaymentConfirmation.svelte-ma2fzm{width:514px;height:519px;border:7px solid #f1f1f1;background-color:#ffffff}.PaymentSteps__PaymentConfirmation-iframe.svelte-ma2fzm{width:514px;height:519px;border:none} .PaymentSteps__PaymentInfo.svelte-1kqw342{margin-top:46px}.PaymentSteps__PaymentInfo-iframe.svelte-1kqw342{border:none;width:100%;height:438px} .PaymentSteps__DeliveryInfo.svelte-j6glwd{color:#002f34}.PaymentSteps__DeliveryInfo-title.svelte-j6glwd{font-family:"Geomanist Book", sans-serif;font-size:20px;line-height:1.1}.PaymentSteps__DeliveryInfo-icons-item-caption.svelte-j6glwd strong{font-size:16px;line-height:1.25}.PaymentSteps__DeliveryInfo-icons-item-caption.svelte-j6glwd strong{font-weight:500}.PaymentSteps__DeliveryInfo.svelte-j6glwd{font-size:14px;line-height:1.29}.PaymentSteps__DeliveryInfo.svelte-j6glwd{box-sizing:border-box;display:flex;flex-direction:column;width:923px;border-radius:4px;background-color:#ffffff;padding:32px}.PaymentSteps__DeliveryInfo-title.svelte-j6glwd{margin:0 0 32px}.PaymentSteps__DeliveryInfo-icons.svelte-j6glwd{display:flex;flex-direction:row;justify-content:space-evenly}.PaymentSteps__DeliveryInfo-icons-item.svelte-j6glwd{display:flex;flex-direction:column;width:182px}.PaymentSteps__DeliveryInfo-icons-item-img.svelte-j6glwd{display:flex;align-self:center;width:80px;height:80px}.PaymentSteps__DeliveryInfo-icons-item-img.svelte-j6glwd svg{width:inherit}.PaymentSteps__DeliveryInfo-icons-item-caption.svelte-j6glwd{align-self:center;text-align:center;margin-top:10px}.PaymentSteps__DeliveryInfo-icons-item-caption.svelte-j6glwd br{margin-bottom:16px} .Photo-placeholder.svelte-18ivknq{display:flex;align-items:center;justify-content:center;background-color:#f3f4f6;width:100%;height:100%}.Photo-placeholder-shape.svelte-18ivknq{box-sizing:border-box;border:38px solid #d7dfe1;border-radius:50%;width:115px;height:115px} .PaymentSteps__AdInfo-title.svelte-m0s215 .Link{color:#002f34}.PaymentSteps__AdInfo-seller.svelte-m0s215{color:#406367}.PaymentSteps__AdInfo-title.svelte-m0s215 .Link,.PaymentSteps__AdInfo-cost.svelte-m0s215{font-size:16px;line-height:1.25}.PaymentSteps__AdInfo-cost.svelte-m0s215{font-weight:500}.PaymentSteps__AdInfo-seller.svelte-m0s215{font-size:12px;line-height:1.17}.PaymentSteps__AdInfo.svelte-m0s215{display:flex;flex-direction:column;align-self:flex-start;box-sizing:border-box;padding:17px 16px;width:297px;border-radius:4px;background-color:#ffffff;margin-left:16px}.PaymentSteps__AdInfo-photo.svelte-m0s215{display:flex;box-sizing:border-box;align-items:center;justify-content:space-around}.PaymentSteps__AdInfo-title.svelte-m0s215 .Link{text-decoration:none;margin-top:16px}.PaymentSteps__AdInfo-seller.svelte-m0s215{margin-top:15px}.PaymentSteps__AdInfo-cost.svelte-m0s215{margin-top:14px} .PaymentSteps.svelte-m4c0qp{font-family:"Geomanist", sans-serif;font-weight:normal;font-stretch:normal;font-style:normal;letter-spacing:normal}.PaymentSteps.svelte-m4c0qp{color:#002f34}.PaymentSteps-title.svelte-m4c0qp{font-size:32px;font-weight:500;line-height:1.06}.PaymentSteps__body-main-list-step-header-title.svelte-m4c0qp{font-family:"Geomanist Book", sans-serif;font-size:20px;line-height:1.1}.PaymentSteps.svelte-m4c0qp{background-color:#f2f4f5;padding:48px 0 0}.PaymentSteps-title.svelte-m4c0qp{margin-bottom:28px}.PaymentSteps__body.svelte-m4c0qp{display:flex}.PaymentSteps__body-main.svelte-m4c0qp{width:923px}.PaymentSteps__body-main-list.svelte-m4c0qp{list-style-type:none;margin:0;padding:0}.PaymentSteps__body-main-list-step.svelte-m4c0qp{background-color:#ffffff;border-radius:4px;margin-top:23px;padding:32px}.PaymentSteps__body-main-list-step--disabled.svelte-m4c0qp{opacity:50%}.PaymentSteps__body-main-list-step-header.svelte-m4c0qp{display:flex;justify-content:space-between;align-items:center}.PaymentSteps__body-main-list-step-header-title.svelte-m4c0qp{margin:0}.PaymentSteps.svelte-m4c0qp .LoadingAnimation{margin:0 auto} /*# sourceMappingURL=https://delivery-one-prd-frontend-static-public-web.s3-eu-west-1.amazonaws.com/fm../../../resources/ua/payment-steps/parts/styles-c108b226fb320286b136.css.map*/
    </style>

    <script data-fems="" data-type="inline-script">
        (function(){ this.render=function(){window.fems=Object.assign({store:{},instances:[]},window.fems),this.render=function(t){function e(e){for(var n,r,o=e[0],i=e[1],s=0,u=[];s
        <o.length;s++)r=o[s],Object.prototype.hasOwnProperty.call(c,r)&&c[r]&&u.push(c[r][0]),c[r]=0;for(n in i)Object.prototype.hasOwnProperty.call(i,n)&&(t[n]=i[n]);for(a&&a(e);u.length;)u.shift()()}var n={},c={4:0};function r(e){if(n[e])return n[e].exports;var c=n[e]={i:e,l:!1,exports:{}};return t[e].call(c.exports,c,c.exports,r),c.l=!0,c.exports}r.e=function(t){var e=[],n=c[t];if(0!==n)if(n)e.push(n[2]);else{var o=new Promise((function(e,r){n=c[t]=[e,r]}));e.push(n[2]=o);var i,s=document.createElement( "script");s.charset="utf-8" ,s.timeout=120,r.nc&&s.setAttribute( "nonce",r.nc),s.src=function(t){return r.p+ ""+({7: "vendors~sentry"}[t]||t)+ "/parts/renderFunc-"+{7: "b2d9eb179dc91b86bca5"}[t]+ ".js"}(t);var a=new Error;i=function(e){s.onerror=s.onload=null,clearTimeout(u);var n=c[t];if(0!==n){if(n){var r=e&&( "load"===e.type? "missing":e.type),o=e&&e.target&&e.target.src;a.message="Loading chunk " +t+ " failed.\n("+r+ ": "+o+ ")",a.name="ChunkLoadError" ,a.type=r,a.request=o,n[1](a)}c[t]=void 0}};var u=setTimeout((function(){i({type: "timeout",target:s})}),12e4);s.onerror=s.onload=i,document.head.appendChild(s)}return Promise.all(e)},r.m=t,r.c=n,r.d=function(t,e,n){r.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:n})},r.r=function(t){ "undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value: "Module"}),Object.defineProperty(t, "__esModule",{value:!0})},r.t=function(t,e){if(1&e&&(t=r(t)),8&e)return t;if(4&e&& "object"==typeof t&&t&&t.__esModule)return t;var n=Object.create(null);if(r.r(n),Object.defineProperty(n, "default",{enumerable:!0,value:t}),2&e&& "string"!=typeof t)for(var c in t)r.d(n,c,function(e){return t[e]}.bind(null,c));return n},r.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return r.d(e, "a",e),e},r.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},r.p="https://delivery-one-prd-frontend-static-public-web.s3-eu-west-1.amazonaws.com/fm../../../resources/ua/" ,r.oe=function(t){throw console.error(t),t};var o=window.webpackJsonprender=window.webpackJsonprender||[],i=o.push.bind(o);o.push=e,o=o.slice();for(var s=0;s<o.length;s++)e(o[s]);var a=i;return r(r.s=143)}({0:function(t,e,n){ "use strict";function c(){}n.d(e, "a",(function(){return pt})),n.d(e, "b",(function(){return Q})),n.d(e, "c",(function(){return h})),n.d(e, "d",(function(){return r})),n.d(e, "e",(function(){return E})),n.d(e, "f",(function(){return lt})),n.d(e, "g",(function(){return H})),n.d(e, "h",(function(){return B})),n.d(e, "i",(function(){return rt})),n.d(e, "j",(function(){return M})),n.d(e, "k",(function(){return bt})),n.d(e, "l",(function(){return S})),n.d(e, "m",(function(){return P})),n.d(e, "n",(function(){return D})),n.d(e, "o",(function(){return f})),n.d(e, "p",(function(){return F})),n.d(e, "q",(function(){return ft})),n.d(e, "r",(function(){return b})),n.d(e, "s",(function(){return jt})),n.d(e, "t",(function(){return y})),n.d(e, "u",(function(){return g})),n.d(e, "v",(function(){return v})),n.d(e, "w",(function(){return _})),n.d(e, "x",(function(){return j})),n.d(e, "y",(function(){return d})),n.d(e, "z",(function(){return at})),n.d(e, "A",(function(){return st})),n.d(e, "B",(function(){return ct})),n.d(e, "C",(function(){return Ot})),n.d(e, "D",(function(){return m})),n.d(e, "E",(function(){return a})),n.d(e, "F",(function(){return I})),n.d(e, "G",(function(){return dt})),n.d(e, "H",(function(){return c})),n.d(e, "I",(function(){return O})),n.d(e, "J",(function(){return q})),n.d(e, "K",(function(){return s})),n.d(e, "L",(function(){return u})),n.d(e, "M",(function(){return k})),n.d(e, "N",(function(){return L})),n.d(e, "O",(function(){return T})),n.d(e, "P",(function(){return p})),n.d(e, "Q",(function(){return N})),n.d(e, "R",(function(){return w})),n.d(e, "S",(function(){return x})),n.d(e, "T",(function(){return $})),n.d(e, "U",(function(){return A})),n.d(e, "V",(function(){return ot})),n.d(e, "W",(function(){return it}));function r(t,e){for(const n in e)t[n]=e[n];return t}function o(t){return t()}function i(){return Object.create(null)}function s(t){t.forEach(o)}function a(t){return "function"==typeof t}function u(t,e){return t!=t?e==e:t!==e||t&& "object"==typeof t|| "function"==typeof t}function l(t,e){const n=t.subscribe(e);return n.unsubscribe?()=>n.unsubscribe():n}function f(t,e,n){t.$$.on_destroy.push(l(e,n))}function b(t,e,n,c){if(t){const r=d(t,e,n,c);return t[0](r)}}function d(t,e,n,c){return t[1]&&c?r(n.ctx.slice(),t[1](c(e))):n.ctx}function j(t,e,n,c){if(t[2]&&c){const r=t[2](c(n));if("object"==typeof e.dirty){const t=[],n=Math.max(e.dirty.length,r.length);for(let c=0;c
            <n;c+=1)t[c]=e.dirty[c]|r[c];return t}return e.dirty|r}return e.dirty}function O(t){return null==t? "":t}function p(t,e,n=e){return t.set(n),e}new Set;function h(t,e){t.appendChild(e)}function m(t,e,n){t.insertBefore(e,n||null)}function g(t){t.parentNode.removeChild(t)}function y(t,e){for(let n=0;n<t.length;n+=1)t[n]&&t[n].d(e)}function v(t){return document.createElement(t)}function $(t){return document.createTextNode(t)}function w(){return $( " ")}function _(){return $( "")}function I(t,e,n,c){return t.addEventListener(e,n,c),()=>t.removeEventListener(e,n,c)}function x(t){return function(e){return e.stopPropagation(),t.call(this,e)}}function E(t,e,n){null==n?t.removeAttribute(e):t.getAttribute(e)!==n&&t.setAttribute(e,n)}function k(t,e){const n=Object.getOwnPropertyDescriptors(t.__proto__);for(const c in e)null==e[c]?t.removeAttribute(c):"style"===c?t.style.cssText=e[c]:n[c]&&n[c].set?t[c]=e[c]:E(t,c,e[c])}function M(t){return Array.from(t.childNodes)}function S(t,e,n,c){for(let c=0;c
                <t.length;c+=1){const r=t[c];if(r.nodeName===e){let e=0;for(;e<r.attributes.length;){const t=r.attributes[e];n[t.name]?e++:r.removeAttribute(t.name)}return t.splice(c,1)[0]}}return c?function(t){return document.createElementNS( "http://www.w3.org/2000/svg",t)}(e):v(e)}function D(t,e){for(let n=0;n<t.length;n+=1){const c=t[n];if(3===c.nodeType)return c.data="" +e,t.splice(n,1)[0]}return $(e)}function P(t){return D(t, " ")}function L(t,e){e="" +e,t.data!==e&&(t.data=e)}function T(t,e){(null!=e||t.value)&&(t.value=e)}function N(t,e,n,c){t.style.setProperty(e,n,c? "important": "")}function A(t,e,n){t.classList[n? "add": "remove"](e)}function C(t,e){const n=document.createEvent( "CustomEvent");return n.initCustomEvent(t,!1,!1,e),n}let z;function R(t){z=t}function V(){if(!z)throw new Error( "Function called outside component initialization");return z}function q(t){V().$$.on_mount.push(t)}function F(){const t=V();return(e,n)=>{const c=t.$$.callbacks[e];if(c){const r=C(e,n);c.slice().forEach(e=>{e.call(t,r)})}}}function B(t,e){const n=t.$$.callbacks[e.type];n&&n.slice().forEach(t=>t(e))}const U=[],H=[],W=[],G=[],K=Promise.resolve();let J=!1;function Z(){J||(J=!0,K.then(X))}function Y(t){W.push(t)}function Q(t){G.push(t)}function X(){const t=new Set;do{for(;U.length;){const t=U.shift();R(t),tt(t.$$)}for(;H.length;)H.pop()();for(let e=0;e
                    <W.length;e+=1){const n=W[e];t.has(n)||(n(),t.add(n))}W.length=0}while(U.length);for(;G.length;)G.pop()();J=!1}function tt(t){if(null!==t.fragment){t.update(),s(t.before_update);const e=t.dirty;t.dirty=[-1],t.fragment&&t.fragment.p(t.ctx,e),t.after_update.forEach(Y)}}const et=new Set;let nt;function ct(){nt={r:0,c:[],p:nt}}function rt(){nt.r||s(nt.c),nt=nt.p}function ot(t,e){t&&t.i&&(et.delete(t),t.i(e))}function it(t,e,n,c){if(t&&t.o){if(et.has(t))return;et.add(t),nt.c.push(()=>{et.delete(t),c&&(n&&t.d(1),c())}),t.o(e)}}"undefined"!=typeof window?window:global;function st(t,e){const n={},c={},r={$$scope:1};let o=t.length;for(;o--;){const i=t[o],s=e[o];if(s){for(const t in i)t in s||(c[t]=1);for(const t in s)r[t]||(n[t]=s[t],r[t]=1);t[o]=s}else for(const t in i)r[t]=1}for(const t in c)t in n||(n[t]=void 0);return n}function at(t){return"object"==typeof t&&null!==t?t:{}}new Set(["allowfullscreen","allowpaymentrequest","async","autofocus","autoplay","checked","controls","default","defer","disabled","formnovalidate","hidden","ismap","loop","multiple","muted","nomodule","novalidate","open","playsinline","readonly","required","reversed","selected"]);let ut;function lt(t,e,n){const c=t.$$.props[e];void 0!==c&&(t.$$.bound[c]=n,n(t.$$.ctx[c]))}function ft(t){t&&t.c()}function bt(t,e){t&&t.l(e)}function dt(t,e,n){const{fragment:c,on_mount:r,on_destroy:i,after_update:u}=t.$$;c&&c.m(e,n),Y(()=>{const e=r.map(o).filter(a);i?i.push(...e):s(e),t.$$.on_mount=[]}),u.forEach(Y)}function jt(t,e){const n=t.$$;null!==n.fragment&&(s(n.on_destroy),n.fragment&&n.fragment.d(e),n.on_destroy=n.fragment=null,n.ctx=[])}function Ot(t,e,n,r,o,a,u=[-1]){const l=z;R(t);const f=e.props||{},b=t.$$={fragment:null,ctx:null,props:a,update:c,not_equal:o,bound:i(),on_mount:[],on_destroy:[],before_update:[],after_update:[],context:new Map(l?l.$$.context:[]),callbacks:i(),dirty:u};let d=!1;b.ctx=n?n(t,f,(e,n,...c)=>{const r=c.length?c[0]:n;return b.ctx&&o(b.ctx[e],b.ctx[e]=r)&&(b.bound[e]&&b.bound[e](r),d&&function(t,e){-1===t.$$.dirty[0]&&(U.push(t),Z(),t.$$.dirty.fill(0)),t.$$.dirty[e/31|0]|=1
                        <<e%31}(t,e)),n}):[],b.update(),d=!0,s(b.before_update),b.fragment=!!r&&r(b.ctx),e.target&&(e.hydrate?b.fragment&&b.fragment.l(M(e.target)):b.fragment&&b.fragment.c(),e.intro&&ot(t.$$.fragment),dt(t,e.target,e.anchor),X()),R(l)} "function"==typeof HTMLElement&&(ut=class extends HTMLElement{constructor(){super(),this.attachShadow({mode: "open"})}connectedCallback(){for(const t in this.$$.slotted)this.appendChild(this.$$.slotted[t])}attributeChangedCallback(t,e,n){this[t]=n}$destroy(){jt(this,1),this.$destroy=c}$on(t,e){const n=this.$$.callbacks[t]||(this.$$.callbacks[t]=[]);return n.push(e),()=>{const t=n.indexOf(e);-1!==t&&n.splice(t,1)}}$set(){}});class pt{$destroy(){jt(this,1),this.$destroy=c}$on(t,e){const n=this.$$.callbacks[t]||(this.$$.callbacks[t]=[]);return n.push(e),()=>{const t=n.indexOf(e);-1!==t&&n.splice(t,1)}}$set(){}}},1:function(t,e,n){"use strict";function c(t){return(c="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}n.d(e,"b",(function(){return o})),n.d(e,"a",(function(){return i}));var r=function(t){return{check:function(e){return c(e)===t},message:"must be a ".concat(t)}},o={number:r("number"),string:r("string"),boolean:r("boolean"),truthy:{check:function(t){return!!t},message:"must be truthy"},falsy:{check:function(t){return!t},message:"must be falsy"},between:function(t,e){return{check:function(n){return n>=t&&n
                            <=e},message: "must be between ".concat(t, " and ").concat(e)}},matching:function(t){return{check:function(e){return t.test(e)},message: "must match regular expression ".concat(t)}},oneOf:function(t){return{check:function(e){return!!t.filter((function(t){return t===e})).length},message: "must be one of: [".concat(t.join( ", "), "].")}}},i=function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"fm",e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:console.warn,n={};return function(c,r){Object.prototype.hasOwnProperty.call(n,r)||(n[r]=c);for(var o=!1,i=arguments.length,s=new Array(i>2?i-2:0),a=2;a
                                <i;a++)s[a-2]=arguments[a];return s.forEach((function(n){n.check(c)||(o=!0,e( "".concat(t, ": '").concat(r, "' ").concat(n.message, ", ").concat(c, " received.")))})),o?n[r]:(n[r]=c,c)}}},11:function(t,e,n){ "use strict";e.a=t=>(e,n)=>{const c=new t({target:e,props:n,hydrate:!0});return{update:t=>c.$set(t),destroy:()=>c.$destroy(),getProps:()=>Object.keys(c.$$.props).reduce((t,e)=>(t[e]=c.$$.ctx[c.$$.props[e]],t),{})}}},112:function(t,e,n){},113:function(t,e,n){},114:function(t,e,n){},115:function(t,e,n){},116:function(t,e,n){},117:function(t,e,n){},118:function(t,e,n){},12:function(t,e,n){"use strict";var c=n(5);e.a=function(t,e){return function(){try{return t.apply(void 0,arguments)}catch(t){Object(c.a)(e)(t)}}}},13:function(t,e,n){"use strict";e.a=function(t){return function(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};window.dispatchEvent(new CustomEvent("fm:".concat(t,":").concat(e),{detail:n}))}}},14:function(t,e,n){"use strict";class c{constructor(t){["fragmentKey","providerId"].forEach(e=>{if(!t[e])throw new TypeError(`${e} is required`)}),this.fragmentKey=t.fragmentKey,this.providerId=t.providerId,this.pendingMessages=new Map,this.timeTrackers=new Map,this.sendInterval=null,this.verbose=!!t.verbose,this.log=this.verbose?(e,...n)=>console.log(`NewRelicProxy: ${e}\n- providerId: ${t.providerId}\n- fragmentKey: ${t.fragmentKey}`,...n):()=>{},window.addEventListener("message",t=>{t.origin===window.origin&&t.data.ack&&(this.pendingMessages.delete(t.data.msgId),0===this.pendingMessages.size&&(this.log("stopping interval"),clearInterval(this.sendInterval),this.sendInterval=null))})}trackTime(t){const e=`${this.fragmentKey}-${t}`;let n;return this.timeTrackers.has(e)&&this.log(`%cTracker '${e}' already exists`,"color:red"),this.timeTrackers.set(e,Date.now()),()=>{n||(n=!0,this.addPageAction("timeTrack",{trackerName:t,ms:Date.now()-this.timeTrackers.get(e)}),this.timeTrackers.delete(e))}}sendMessage(t){const e={...t,fragmentKey:this.fragmentKey,id:[this.fragmentKey,Date.now(),Math.ceil(1e16*Math.random())].join("-")};this.pendingMessages.set(e.id,e),this.sendInterval||(this.sendInterval=setInterval(()=>{this.pendingMessages.forEach(t=>{this.log("sending message to provider",JSON.stringify(t,null,2));try{document.getElementById(this.providerId).contentWindow.postMessage(t,window.origin)}catch(t){this.log(`%c error: ${t.message}`,"color:red")}})},1e3))}forwardMethod(t,e){["addPageAction","noticeError"].includes(t)&&this.sendMessage({method:t,args:e})}addPageAction(...t){this.forwardMethod("addPageAction",t)}noticeError(...t){this.forwardMethod("noticeError",t)}trackRendering(t){return this.trackFunctionTime("rendering",this.trackErrors(t))}getErrorTracker(){return this.trackErrors.bind(this)}trackErrors(t){return(...e)=>{try{return t(...e)}catch(t){throw this.noticeError(t),t}}}trackFunctionTime(t,e){return(...n)=>{const c=this.trackTime(t),r=e(...n);return c(),r}}}e.a=function(t){return new c({fragmentKey:t,providerId:"delivery-fems-newrelic",verbose:!1})}},143:function(t,e,n){"use strict";n.r(e);var c=n(11),r=n(12),o=n(5),i=n(13),s=n(6),a=n(14),u=n(2),l="payment-steps",f="ua/".concat(l),b="".concat(l,"/assets"),d=("".concat(u.a.PUBLIC_URL).concat(b,"/img"),"active"),j="completed",O="disabled",p="close",h="ok",m=Object(i.a)(l),g=Object(o.a)(f),y=function(t){g(t),m("error",{error:t})},v=function(t){return function(e){e.code&&e.code in s.a&&(e.message=t("global.errors.ua-rock.".concat(s.a[e.code]),!0),e.translated=!0),y(e)}},$=Object(a.a)(f),w=n(0),_=n(7),I=n(3),x=n(16),E=n(17),k=function(t){var e=t.token,n=t.adId;return Object(s.b)("/ad/".concat(n),{method:"GET",mode:"cors",headers:{Authorization:"Bearer ".concat(e),"content-type":"application/json"}})},M=n(4),S=n(1),D=n(27),P=Object(D.a)(void 0),L=Object(D.a)((function(t){return t})),T=Object(D.a)("uk"),N=n(8),A=n(33),C=function(t){var e=t.token,n=t.adId,c=t.lang,r=t.context;return Object(s.b)("/ad/".concat(n,"/form/").concat(r,"/info"),{method:"GET",mode:"cors",headers:{"Accept-Language":c,Authorization:"Bearer ".concat(e)}})},z=function(t){var e=t.token,n=t.adId,c=t.payload;return Object(s.b)("/ad/".concat(n,"/transaction"),{method:"POST",mode:"cors",headers:{Authorization:"Bearer ".concat(e),"content-type":"application/json"},body:JSON.stringify(c)},{serializeResponse:!1})};n(112);function R(t){let e,n=[{src:t[1]},{class:t[4]`-iframe`},{title:t[2]},t[3]],c={};for(let t=0;t
                                    <n.length;t+=1)c=Object(w.d)(c,n[t]);return{c(){e=Object(w.v)( "iframe"),this.h()},l(t){e=Object(w.l)(t, "IFRAME",{src:!0,class:!0,title:!0}),Object(w.j)(e).forEach(w.u),this.h()},h(){Object(w.M)(e,c),Object(w.U)(e, "svelte-cfaypg",!0)},m(t,n){Object(w.D)(t,e,n)},p(t,c){Object(w.M)(e,Object(w.A)(n,[2&c&&{src:t[1]},16&c&&{class:t[4]`-iframe`},4&c&&{title:t[2]},8&c&&t[3]])),Object(w.U)(e, "svelte-cfaypg",!0)},i:w.H,o:w.H,d(t){t&&Object(w.u)(e)}}}function V(t){let e;const n=new x.a({});return{c(){Object(w.q)(n.$$.fragment)},l(t){Object(w.k)(n.$$.fragment,t)},m(t,c){Object(w.G)(n,t,c),e=!0},p:w.H,i(t){e||(Object(w.V)(n.$$.fragment,t),e=!0)},o(t){Object(w.W)(n.$$.fragment,t),e=!1},d(t){Object(w.s)(n,t)}}}function q(t){let e,n,c,r,o,i;const s=[V,R],a=[];function u(t,e){return t[0]?t[1]?1:-1:0}return~(n=u(t))&&(c=a[n]=s[n](t)),{c(){e=Object(w.v)( "section"),c&&c.c(),this.h()},l(t){e=Object(w.l)(t, "SECTION",{class:!0});var n=Object(w.j)(e);c&&c.l(n),n.forEach(w.u),this.h()},h(){Object(w.e)(e, "class",r=Object(w.I)(t[4]``)+ " svelte-cfaypg")},m(c,r){Object(w.D)(c,e,r),~n&&a[n].m(e,null),o=!0,i=Object(w.F)(window, "message",t[5])},p(t,[r]){let o=n;n=u(t),n===o?~n&&a[n].p(t,r):(c&&(Object(w.B)(),Object(w.W)(a[o],1,1,()=>{a[o]=null}),Object(w.i)()),~n?(c=a[n],c||(c=a[n]=s[n](t),c.c()),Object(w.V)(c,1),c.m(e,null)):c=null)},i(t){o||(Object(w.V)(c),o=!0)},o(t){Object(w.W)(c),o=!1},d(t){t&&Object(w.u)(e),~n&&a[n].d(),i()}}}function F(t,e,n){let c,r,o;Object(w.o)(t,P,t=>n(7,c=t)),Object(w.o)(t,L,t=>n(8,r=t)),Object(w.o)(t,T,t=>n(9,o=t));let{adId:i}=e;const s=Object(I.a)("PaymentSteps__BuyerInfo");let a,u=!1,l=null,f={id:"buyer-info"};const b={buyerInfo:t=>{if(m("buyer-info-submitted",{adId:i}),"ok"===t.status)z({token:c,adId:i,payload:t.data}).then(({ok:e})=>e&&m("buyer-info-post-success",{adId:i,transactionId:t.data.externalId})).catch(v(r)).finally(()=>{n(1,l=null)});else if("error"===t.status)throw new N.b(t.errorMessage,t.errorMessageLoc)}};return Object(_.b)(()=>C({token:c,adId:i,lang:o,context:"buyer"}).then(t=>{n(1,l=Object(M.c)(t,"_links.iframe.href",null))}).catch(v(r)).finally(()=>{n(0,u=!0)})),t.$set=t=>{"adId"in t&&n(6,i=t.adId)},t.$$.update=()=>{256&t.$$.dirty&&n(2,a=r`payment-steps.buyer-info.iframe.title`)},[u,l,a,f,s,t=>{try{n(3,f=Object(A.a)({iframeAttrs:f,additionalActions:b})(t))}catch(t){y(t)}},i]}class B extends w.a{constructor(t){super(),Object(w.C)(this,t,F,q,w.L,{adId:6})}}var U=B,H=n(22),W=n(54);n(113);function G(t){let e,n,c,r,o;return{c(){e=Object(w.v)("div"),n=Object(w.v)("iframe"),this.h()},l(t){e=Object(w.l)(t,"DIV",{class:!0});var c=Object(w.j)(e);n=Object(w.l)(c,"IFRAME",{class:!0,id:!0,name:!0,title:!0}),Object(w.j)(n).forEach(w.u),c.forEach(w.u),this.h()},h(){Object(w.e)(n,"class",c=Object(w.I)(t[1]`-iframe`)+" svelte-ma2fzm"),Object(w.e)(n,"id","3dsFrame"),Object(w.e)(n,"name","3dsFrame"),Object(w.e)(n,"title","3dsFrame"),Object(w.e)(e,"class",r=Object(w.I)(t[1]``)+" svelte-ma2fzm")},m(c,r){Object(w.D)(c,e,r),Object(w.c)(e,n),t[6](n),o=Object(w.F)(window,"message",t[2])},p:w.H,i:w.H,o:w.H,d(n){n&&Object(w.u)(e),t[6](null),o()}}}function K(t,e,n){let c,{src:r}=e,o=null;const i=Object(I.a)("PaymentSteps__PaymentConfirmation"),s=Object(_.a)();return Object(_.b)(()=>{try{o=c.contentWindow&&c.contentWindow.document||c.contentDocument,o.open(),o.write(r),o.close()}catch(t){y(t)}}),t.$set=t=>{"src"in t&&n(3,r=t.src)},[c,i,t=>{t.data&&"payment"===t.data.frameName&&"conformShow"===t.data.name&&s("done-3ds",{status:h})},r,o,s,function(t){w.g[t?"unshift":"push"](()=>{n(0,c=t)})}]}class J extends w.a{constructor(t){super(),Object(w.C)(this,t,K,G,w.L,{src:3})}}var Z=J;n(114);function Y(t){let e;const n=new Z({props:{src:t[5]}});return n.$on("done-3ds",t[17]),{c(){Object(w.q)(n.$$.fragment)},l(t){Object(w.k)(n.$$.fragment,t)},m(t,c){Object(w.G)(n,t,c),e=!0},p(t,e){const c={};32&e&&(c.src=t[5]),n.$set(c)},i(t){e||(Object(w.V)(n.$$.fragment,t),e=!0)},o(t){Object(w.W)(n.$$.fragment,t),e=!1},d(t){Object(w.s)(n,t)}}}function Q(t){let e,n=[{class:t[7]`-iframe`},{title:"Payment Info"},{src:t[3]},t[4]],c={};for(let t=0;t
                                        <n.length;t+=1)c=Object(w.d)(c,n[t]);return{c(){e=Object(w.v)( "iframe"),this.h()},l(t){e=Object(w.l)(t, "IFRAME",{class:!0,title:!0,src:!0}),Object(w.j)(e).forEach(w.u),this.h()},h(){Object(w.M)(e,c),Object(w.U)(e, "svelte-1kqw342",!0)},m(n,c){Object(w.D)(n,e,c),t[19](e)},p(t,c){Object(w.M)(e,Object(w.A)(n,[128&c&&{class:t[7]`-iframe`},{title: "Payment Info"},8&c&&{src:t[3]},16&c&&t[4]])),Object(w.U)(e, "svelte-1kqw342",!0)},i:w.H,o:w.H,d(n){n&&Object(w.u)(e),t[19](null)}}}function X(t){let e;const n=new x.a({});return{c(){Object(w.q)(n.$$.fragment)},l(t){Object(w.k)(n.$$.fragment,t)},m(t,c){Object(w.G)(n,t,c),e=!0},p:w.H,i(t){e||(Object(w.V)(n.$$.fragment,t),e=!0)},o(t){Object(w.W)(n.$$.fragment,t),e=!1},d(t){Object(w.s)(n,t)}}}function tt(t){let e,n,c,r,o,i,s;const a=new H.a({props:{visible:t[6],$$slots:{default:[Y]},$$scope:{ctx:t}}});a.$on( "close",t[18]);const u=[X,Q],l=[];function f(t,e){return t[0]?t[1]?-1:1:0}return~(c=f(t))&&(r=l[c]=u[c](t)),{c(){Object(w.q)(a.$$.fragment),e=Object(w.R)(),n=Object(w.v)( "section"),r&&r.c(),this.h()},l(t){Object(w.k)(a.$$.fragment,t),e=Object(w.m)(t),n=Object(w.l)(t, "SECTION",{class:!0});var c=Object(w.j)(n);r&&r.l(c),c.forEach(w.u),this.h()},h(){Object(w.e)(n, "class",o=Object(w.I)(t[7]``)+ " svelte-1kqw342")},m(r,o){Object(w.G)(a,r,o),Object(w.D)(r,e,o),Object(w.D)(r,n,o),~c&&l[c].m(n,null),i=!0,s=Object(w.F)(window, "message",t[8])},p(t,[e]){const o={};64&e&&(o.visible=t[6]),1048608&e&&(o.$$scope={dirty:e,ctx:t}),a.$set(o);let i=c;c=f(t),c===i?~c&&l[c].p(t,e):(r&&(Object(w.B)(),Object(w.W)(l[i],1,1,()=>{l[i]=null}),Object(w.i)()),~c?(r=l[c],r||(r=l[c]=u[c](t),r.c()),Object(w.V)(r,1),r.m(n,null)):r=null)},i(t){i||(Object(w.V)(a.$$.fragment,t),Object(w.V)(r),i=!0)},o(t){Object(w.W)(a.$$.fragment,t),Object(w.W)(r),i=!1},d(t){Object(w.s)(a,t),t&&Object(w.u)(e),t&&Object(w.u)(n),~c&&l[c].d(),s()}}}function et(t,e,n){let c,r;Object(w.o)(t,P,t=>n(14,c=t)),Object(w.o)(t,T,t=>n(15,r=t));let{adId:o}=e,{transactionId:i}=e,{confirmPageUrl:s}=e;const a=Object(I.a)("PaymentSteps__PaymentInfo");let u,l=!1,f=!1,b=null,d={id:"payment-info"},j=!1,O="",g=!1;const v={"3dsModal":t=>{m("payment-info-submitted",{adId:o}),n(5,O=t.data),n(6,g=!0)},buyerCard:({errorMessage:t,errorMessageLoc:e,status:c})=>{if("ok"===c)n(1,f=!0),m("payment-info-payment-success",{adId:o,transactionId:i}),document&&"string"==typeof s&&""!==s||(y(new Error("Confirm Page URL not set, falling back to default")),n(10,s="/safedeal/confirm")),document.location.assign(s);else if("error"===c&&"3DS escaped"!==t)throw new N.b(t,e)}},$=t=>{j=j||t===h,u.contentWindow.postMessage(JSON.stringify({action:"3dsModal",status:t}),"*"),n(6,g=!1)};Object(_.b)(()=>Object(W.a)({token:c,adId:o,lang:r,transactionId:i,context:"buyer"}).then(t=>{n(3,b=Object(M.c)(t,"_links.iframe.href",null))}).catch(y).finally(()=>{n(0,l=!0)}));return t.$set=t=>{"adId"in t&&n(11,o=t.adId),"transactionId"in t&&n(12,i=t.transactionId),"confirmPageUrl"in t&&n(10,s=t.confirmPageUrl)},[l,f,u,b,d,O,g,a,t=>{try{n(4,d=Object(A.a)({iframeAttrs:d,additionalActions:v})(t))}catch(t){y(t)}},$,s,o,i,j,c,r,v,t=>$(t.detail.status),()=>$(p),function(t){w.g[t?"unshift":"push"](()=>{n(2,u=t)})}]}class nt extends w.a{constructor(t){super(),Object(w.C)(this,t,et,tt,w.L,{adId:11,transactionId:12,confirmPageUrl:10})}}var ct=nt,rt=n(91),ot=n.n(rt),it=n(92),st=n.n(it),at=n(93),ut=n.n(at);n(115);function lt(t,e,n){const c=t.slice();return c[3]=e[n].key,c[4]=e[n].icon,c}function ft(t){let e,n,c,r,o,i,s,a,u=t[4]+"",l=t[0](`payment-steps.delivery-info.${t[3]}`)+"";return{c(){e=Object(w.v)("div"),n=Object(w.v)("span"),r=Object(w.R)(),o=Object(w.v)("span"),s=Object(w.R)(),this.h()},l(t){e=Object(w.l)(t,"DIV",{class:!0});var c=Object(w.j)(e);n=Object(w.l)(c,"SPAN",{class:!0}),Object(w.j)(n).forEach(w.u),r=Object(w.m)(c),o=Object(w.l)(c,"SPAN",{class:!0}),Object(w.j)(o).forEach(w.u),s=Object(w.m)(c),c.forEach(w.u),this.h()},h(){Object(w.e)(n,"class",c=Object(w.I)(t[1]`-icons-item-img`)+" svelte-j6glwd"),Object(w.e)(o,"class",i=Object(w.I)(t[1]`-icons-item-caption`)+" svelte-j6glwd"),Object(w.e)(e,"class",a=Object(w.I)(t[1]`-icons-item`)+" svelte-j6glwd")},m(t,c){Object(w.D)(t,e,c),Object(w.c)(e,n),n.innerHTML=u,Object(w.c)(e,r),Object(w.c)(e,o),o.innerHTML=l,Object(w.c)(e,s)},p(t,e){1&e&&l!==(l=t[0](`payment-steps.delivery-info.${t[3]}`)+"")&&(o.innerHTML=l)},d(t){t&&Object(w.u)(e)}}}function bt(t){let e,n,c,r,o,i,s,a,u=t[0]`payment-steps.delivery-info.title`+"",l=t[2],f=[];for(let e=0;e
                                            <l.length;e+=1)f[e]=ft(lt(t,l,e));return{c(){e=Object(w.v)( "section"),n=Object(w.v)( "h6"),c=Object(w.T)(u),o=Object(w.R)(),i=Object(w.v)( "div");for(let t=0;t<f.length;t+=1)f[t].c();this.h()},l(t){e=Object(w.l)(t, "SECTION",{class:!0});var r=Object(w.j)(e);n=Object(w.l)(r, "H6",{class:!0});var s=Object(w.j)(n);c=Object(w.n)(s,u),s.forEach(w.u),o=Object(w.m)(r),i=Object(w.l)(r, "DIV",{class:!0});var a=Object(w.j)(i);for(let t=0;t<f.length;t+=1)f[t].l(a);a.forEach(w.u),r.forEach(w.u),this.h()},h(){Object(w.e)(n, "class",r=Object(w.I)(t[1]`-title`)+ " svelte-j6glwd"),Object(w.e)(i, "class",s=Object(w.I)(t[1]`-icons`)+ " svelte-j6glwd"),Object(w.e)(e, "class",a=Object(w.I)(t[1]``)+ " svelte-j6glwd")},m(t,r){Object(w.D)(t,e,r),Object(w.c)(e,n),Object(w.c)(n,c),Object(w.c)(e,o),Object(w.c)(e,i);for(let t=0;t<f.length;t+=1)f[t].m(i,null)},p(t,[e]){if(1&e&&u!==(u=t[0]`payment-steps.delivery-info.title`+ "")&&Object(w.N)(c,u),7&e){let n;for(l=t[2],n=0;n<l.length;n+=1){const c=lt(t,l,n);f[n]?f[n].p(c,e):(f[n]=ft(c),f[n].c(),f[n].m(i,null))}for(;n<f.length;n+=1)f[n].d(1);f.length=l.length}},i:w.H,o:w.H,d(t){t&&Object(w.u)(e),Object(w.t)(f,t)}}}function dt(t,e,n){let c;Object(w.o)(t,L,t=>n(0,c=t));const r=Object(I.a)("PaymentSteps__DeliveryInfo"),o=[{key:"a",icon:ot.a},{key:"b",icon:ut.a},{key:"c",icon:st.a}];return[c,r,o]}class jt extends w.a{constructor(t){super(),Object(w.C)(this,t,dt,bt,w.L,{})}}var Ot=jt;n(116);function pt(t){let e,n;function c(t,e){return t[1]?mt:ht}let r=c(t),o=r(t);return{c(){e=Object(w.v)("div"),o.c(),this.h()},l(t){e=Object(w.l)(t,"DIV",{class:!0});var n=Object(w.j)(e);o.l(n),n.forEach(w.u),this.h()},h(){Object(w.e)(e,"class",n=Object(w.I)(t[3]``)+" svelte-18ivknq")},m(t,n){Object(w.D)(t,e,n),o.m(e,null)},p(t,n){r===(r=c(t))&&o?o.p(t,n):(o.d(1),o=r(t),o&&(o.c(),o.m(e,null)))},d(t){t&&Object(w.u)(e),o.d()}}}function ht(t){let e,n,c,r;return{c(){e=Object(w.v)("div"),n=Object(w.v)("div"),this.h()},l(t){e=Object(w.l)(t,"DIV",{class:!0});var c=Object(w.j)(e);n=Object(w.l)(c,"DIV",{class:!0}),Object(w.j)(n).forEach(w.u),c.forEach(w.u),this.h()},h(){Object(w.e)(n,"class",c=Object(w.I)(t[3]`-placeholder-shape`)+" svelte-18ivknq"),Object(w.e)(e,"class",r=Object(w.I)(t[3]`-placeholder`)+" svelte-18ivknq")},m(t,c){Object(w.D)(t,e,c),Object(w.c)(e,n)},p:w.H,d(t){t&&Object(w.u)(e)}}}function mt(t){let e,n;return{c(){e=Object(w.v)("img"),this.h()},l(t){e=Object(w.l)(t,"IMG",{src:!0,alt:!0}),this.h()},h(){e.src!==(n=t[1])&&Object(w.e)(e,"src",n),Object(w.e)(e,"alt",t[0])},m(t,n){Object(w.D)(t,e,n)},p(t,c){2&c&&e.src!==(n=t[1])&&Object(w.e)(e,"src",n),1&c&&Object(w.e)(e,"alt",t[0])},d(t){t&&Object(w.u)(e)}}}function gt(t){let e,n=(t[1]||t[2])&&pt(t);return{c(){n&&n.c(),e=Object(w.w)()},l(t){n&&n.l(t),e=Object(w.w)()},m(t,c){n&&n.m(t,c),Object(w.D)(t,e,c)},p(t,[c]){t[1]||t[2]?n?n.p(t,c):(n=pt(t),n.c(),n.m(e.parentNode,e)):n&&(n.d(1),n=null)},i:w.H,o:w.H,d(t){n&&n.d(t),t&&Object(w.u)(e)}}}function yt(t,e,n){let{title:c=""}=e,{url:r}=e,{usePlaceholder:o=!1}=e;const i=Object(I.a)("Photo");return t.$set=t=>{"title"in t&&n(0,c=t.title),"url"in t&&n(1,r=t.url),"usePlaceholder"in t&&n(2,o=t.usePlaceholder)},[c,r,o,i]}class vt extends w.a{constructor(t){super(),Object(w.C)(this,t,yt,gt,w.L,{title:0,url:1,usePlaceholder:2})}}var $t=vt,wt=n(35);n(117);function _t(t){let e,n=(t[1]||"")+"";return{c(){e=Object(w.T)(n)},l(t){e=Object(w.n)(t,n)},m(t,n){Object(w.D)(t,e,n)},p(t,c){2&c&&n!==(n=(t[1]||"")+"")&&Object(w.N)(e,n)},d(t){t&&Object(w.u)(e)}}}function It(t){let e,n,c,r,o,i,s,a,u,l,f,b,d,j,O,p,h,m=[t[4],t[5]].filter(kt).join(" - ")+"",g=`${t[6]} ${t[7](`global.currency.${t[3]}`,!0)}`+"";const y=new $t({props:{title:t[1],url:t[0]}}),v=new E.a({props:{href:t[2],target:"_blank",$$slots:{default:[_t]},$$scope:{ctx:t}}});return{c(){e=Object(w.v)("section"),n=Object(w.v)("div"),Object(w.q)(y.$$.fragment),o=Object(w.R)(),i=Object(w.v)("div"),Object(w.q)(v.$$.fragment),a=Object(w.R)(),u=Object(w.v)("div"),l=Object(w.T)(m),b=Object(w.R)(),d=Object(w.v)("div"),j=Object(w.T)(g),this.h()},l(t){e=Object(w.l)(t,"SECTION",{class:!0});var c=Object(w.j)(e);n=Object(w.l)(c,"DIV",{class:!0,style:!0});var r=Object(w.j)(n);Object(w.k)(y.$$.fragment,r),r.forEach(w.u),o=Object(w.m)(c),i=Object(w.l)(c,"DIV",{class:!0});var s=Object(w.j)(i);Object(w.k)(v.$$.fragment,s),s.forEach(w.u),a=Object(w.m)(c),u=Object(w.l)(c,"DIV",{class:!0});var f=Object(w.j)(u);l=Object(w.n)(f,m),f.forEach(w.u),b=Object(w.m)(c),d=Object(w.l)(c,"DIV",{class:!0});var O=Object(w.j)(d);j=Object(w.n)(O,g),O.forEach(w.u),c.forEach(w.u),this.h()},h(){Object(w.e)(n,"class",c=Object(w.I)(t[8]`-photo`)+" svelte-m0s215"),Object(w.e)(n,"style",r=`width: ${xt}px; height: ${Et}px;`),Object(w.e)(i,"class",s=Object(w.I)(t[8]`-title`)+" svelte-m0s215"),Object(w.e)(u,"class",f=Object(w.I)(t[8]`-seller`)+" svelte-m0s215"),Object(w.e)(d,"class",O=Object(w.I)(t[8]`-cost`)+" svelte-m0s215"),Object(w.e)(e,"class",p=Object(w.I)(t[8]``)+" svelte-m0s215")},m(t,c){Object(w.D)(t,e,c),Object(w.c)(e,n),Object(w.G)(y,n,null),Object(w.c)(e,o),Object(w.c)(e,i),Object(w.G)(v,i,null),Object(w.c)(e,a),Object(w.c)(e,u),Object(w.c)(u,l),Object(w.c)(e,b),Object(w.c)(e,d),Object(w.c)(d,j),h=!0},p(t,[e]){const n={};2&e&&(n.title=t[1]),1&e&&(n.url=t[0]),y.$set(n);const c={};4&e&&(c.href=t[2]),2050&e&&(c.$$scope={dirty:e,ctx:t}),v.$set(c),(!h||48&e)&&m!==(m=[t[4],t[5]].filter(kt).join(" - ")+"")&&Object(w.N)(l,m),(!h||200&e)&&g!==(g=`${t[6]} ${t[7](`global.currency.${t[3]}`,!0)}`+"")&&Object(w.N)(j,g)},i(t){h||(Object(w.V)(y.$$.fragment,t),Object(w.V)(v.$$.fragment,t),h=!0)},o(t){Object(w.W)(y.$$.fragment,t),Object(w.W)(v.$$.fragment,t),h=!1},d(t){t&&Object(w.u)(e),Object(w.s)(y),Object(w.s)(v)}}}const xt=265,Et=218,kt=t=>t;function Mt(t,e,n){let c;Object(w.o)(t,L,t=>n(7,c=t));let{title:r}=e,{photo:o}=e,{url:i}=e,{currency:s="uah"}=e,{cost:a}=e,{seller:u}=e,{date:l}=e;const f=Object(I.a)("PaymentSteps__AdInfo");let b="",d="";return t.$set=t=>{"title"in t&&n(1,r=t.title),"photo"in t&&n(0,o=t.photo),"url"in t&&n(2,i=t.url),"currency"in t&&n(3,s=t.currency),"cost"in t&&n(9,a=t.cost),"seller"in t&&n(4,u=t.seller),"date"in t&&n(10,l=t.date)},t.$$.update=()=>{1&t.$$.dirty&&o&&n(0,o=o.replace("{width}x{height}",`${xt}x${Et}`)),1024&t.$$.dirty&&l&&n(5,b=Object(wt.a)(l)),512&t.$$.dirty&&n(6,d=Number.isInteger(a)?a/100:"--")},[o,r,i,s,u,b,d,c,f,a,l]}class St extends w.a{constructor(t){super(),Object(w.C)(this,t,Mt,It,w.L,{title:1,photo:0,url:2,currency:3,cost:9,seller:4,date:10})}}var Dt=St;n(118);function Pt(t,e,n){const c=t.slice();return c[16]=e[n].title,c[17]=e[n].status,c[18]=e[n].component,c[20]=n,c}function Lt(t){let e;const n=new x.a({});return{c(){Object(w.q)(n.$$.fragment)},l(t){Object(w.k)(n.$$.fragment,t)},m(t,c){Object(w.G)(n,t,c),e=!0},p:w.H,i(t){e||(Object(w.V)(n.$$.fragment,t),e=!0)},o(t){Object(w.W)(n.$$.fragment,t),e=!1},d(t){Object(w.s)(n,t)}}}function Tt(t){let e,n,c,r=t[5],o=[];for(let e=0;e
                                                <r.length;e+=1)o[e]=Ct(Pt(t,r,e));const i=t=>Object(w.W)(o[t],1,1,()=>{o[t]=null});return{c(){e=Object(w.v)("ul");for(let t=0;t
                                                    <o.length;t+=1)o[t].c();this.h()},l(t){e=Object(w.l)(t, "UL",{class:!0});var n=Object(w.j)(e);for(let t=0;t<o.length;t+=1)o[t].l(n);n.forEach(w.u),this.h()},h(){Object(w.e)(e, "class",n=Object(w.I)(t[7]`__body-main-list`)+ " svelte-m4c0qp")},m(t,n){Object(w.D)(t,e,n);for(let t=0;t<o.length;t+=1)o[t].m(e,null);c=!0},p(t,n){if(491&n){let c;for(r=t[5],c=0;c<r.length;c+=1){const i=Pt(t,r,c);o[c]?(o[c].p(i,n),Object(w.V)(o[c],1)):(o[c]=Ct(i),o[c].c(),Object(w.V)(o[c],1),o[c].m(e,null))}for(Object(w.B)(),c=r.length;c<o.length;c+=1)i(c);Object(w.i)()}},i(t){if(!c){for(let t=0;t<r.length;t+=1)Object(w.V)(o[t]);c=!0}},o(t){o=o.filter(Boolean);for(let t=0;t<o.length;t+=1)Object(w.W)(o[t]);c=!1},d(t){t&&Object(w.u)(e),Object(w.t)(o,t)}}}function Nt(t){let e;const n=new E.a({props:{class:t[7]`__body-main-list-step-header-cta`,$$slots:{default:[At]},$$scope:{ctx:t}}});return n.$on( "click",t[8](t[20])),{c(){Object(w.q)(n.$$.fragment)},l(t){Object(w.k)(n.$$.fragment,t)},m(t,c){Object(w.G)(n,t,c),e=!0},p(t,e){const c={};2097216&e&&(c.$$scope={dirty:e,ctx:t}),n.$set(c)},i(t){e||(Object(w.V)(n.$$.fragment,t),e=!0)},o(t){Object(w.W)(n.$$.fragment,t),e=!1},d(t){Object(w.s)(n,t)}}}function At(t){let e,n=t[6]`payment-steps.header.cta.edit`+ "";return{c(){e=Object(w.T)(n)},l(t){e=Object(w.n)(t,n)},m(t,n){Object(w.D)(t,e,n)},p(t,c){64&c&&n!==(n=t[6]`payment-steps.header.cta.edit`+ "")&&Object(w.N)(e,n)},d(t){t&&Object(w.u)(e)}}}function Ct(t){let e,n,c,r,o,i,s,a,u,l,f,b=t[6](t[16])+ "",O=t[17]===j&&Nt(t);var p=t[17]===d&&t[18];function h(t){return{props:{stepIx:t[20],adId:t[0],transactionId:t[3],confirmPageUrl:t[1]}}}if(p)var m=new p(h(t));return{c(){e=Object(w.v)( "li"),n=Object(w.v)( "div"),c=Object(w.v)( "h6"),r=Object(w.T)(b),i=Object(w.R)(),O&&O.c(),a=Object(w.R)(),m&&Object(w.q)(m.$$.fragment),u=Object(w.R)(),this.h()},l(t){e=Object(w.l)(t, "LI",{class:!0});var o=Object(w.j)(e);n=Object(w.l)(o, "DIV",{class:!0});var s=Object(w.j)(n);c=Object(w.l)(s, "H6",{class:!0});var l=Object(w.j)(c);r=Object(w.n)(l,b),l.forEach(w.u),i=Object(w.m)(s),O&&O.l(s),s.forEach(w.u),a=Object(w.m)(o),m&&Object(w.k)(m.$$.fragment,o),u=Object(w.m)(o),o.forEach(w.u),this.h()},h(){Object(w.e)(c, "class",o=Object(w.I)(t[7]`__body-main-list-step-header-title`)+ " svelte-m4c0qp"),Object(w.e)(n, "class",s=Object(w.I)(t[7]`__body-main-list-step-header`)+ " svelte-m4c0qp"),Object(w.e)(e, "class",l=Object(w.I)(t[7]( "__body-main-list-step",t[17]&&`--${t[17]}`))+ " svelte-m4c0qp")},m(t,o){Object(w.D)(t,e,o),Object(w.c)(e,n),Object(w.c)(n,c),Object(w.c)(c,r),Object(w.c)(n,i),O&&O.m(n,null),Object(w.c)(e,a),m&&Object(w.G)(m,e,null),Object(w.c)(e,u),f=!0},p(t,c){(!f||96&c)&&b!==(b=t[6](t[16])+ "")&&Object(w.N)(r,b),t[17]===j?O?(O.p(t,c),Object(w.V)(O,1)):(O=Nt(t),O.c(),Object(w.V)(O,1),O.m(n,null)):O&&(Object(w.B)(),Object(w.W)(O,1,1,()=>{O=null}),Object(w.i)());const o={};if(1&c&&(o.adId=t[0]),8&c&&(o.transactionId=t[3]),2&c&&(o.confirmPageUrl=t[1]),p!==(p=t[17]===d&&t[18])){if(m){Object(w.B)();const t=m;Object(w.W)(t.$$.fragment,1,0,()=>{Object(w.s)(t,1)}),Object(w.i)()}p?(m=new p(h(t)),Object(w.q)(m.$$.fragment),Object(w.V)(m.$$.fragment,1),Object(w.G)(m,e,u)):m=null}else p&&m.$set(o);(!f||32&c&&l!==(l=Object(w.I)(t[7]("__body-main-list-step",t[17]&&`--${t[17]}`))+" svelte-m4c0qp"))&&Object(w.e)(e,"class",l)},i(t){f||(Object(w.V)(O),m&&Object(w.V)(m.$$.fragment,t),f=!0)},o(t){Object(w.W)(O),m&&Object(w.W)(m.$$.fragment,t),f=!1},d(t){t&&Object(w.u)(e),O&&O.d(),m&&Object(w.s)(m)}}}function zt(t){let e,n,c,r,o,i,s,a,u,l,f,b,d,j,O,p,h=(t[4].title||"")+"";const m=new Ot({}),g=[Tt,Lt],y=[];function v(t,e){return t[2]?0:1}u=v(t),l=y[u]=g[u](t);const $=[t[4]];let _={};for(let t=0;t
                                                        <$.length;t+=1)_=Object(w.d)(_,$[t]);const I=new Dt({props:_});return{c(){e=Object(w.v)( "section"),n=Object(w.v)( "h2"),c=Object(w.T)(h),o=Object(w.R)(),i=Object(w.v)( "div"),s=Object(w.v)( "section"),Object(w.q)(m.$$.fragment),a=Object(w.R)(),l.c(),b=Object(w.R)(),Object(w.q)(I.$$.fragment),this.h()},l(t){e=Object(w.l)(t, "SECTION",{class:!0});var r=Object(w.j)(e);n=Object(w.l)(r, "H2",{class:!0});var u=Object(w.j)(n);c=Object(w.n)(u,h),u.forEach(w.u),o=Object(w.m)(r),i=Object(w.l)(r, "DIV",{class:!0});var f=Object(w.j)(i);s=Object(w.l)(f, "SECTION",{class:!0});var d=Object(w.j)(s);Object(w.k)(m.$$.fragment,d),a=Object(w.m)(d),l.l(d),d.forEach(w.u),b=Object(w.m)(f),Object(w.k)(I.$$.fragment,f),f.forEach(w.u),r.forEach(w.u),this.h()},h(){Object(w.e)(n, "class",r=Object(w.I)(t[7]`-title`)+ " svelte-m4c0qp"),Object(w.e)(s, "class",f=Object(w.I)(t[7]`__body-main`)+ " svelte-m4c0qp"),Object(w.e)(i, "class",d=Object(w.I)(t[7]`__body`)+ " svelte-m4c0qp"),Object(w.e)(e, "class",j=Object(w.I)(t[7]``)+ " svelte-m4c0qp")},m(r,l){Object(w.D)(r,e,l),Object(w.c)(e,n),Object(w.c)(n,c),Object(w.c)(e,o),Object(w.c)(e,i),Object(w.c)(i,s),Object(w.G)(m,s,null),Object(w.c)(s,a),y[u].m(s,null),Object(w.c)(i,b),Object(w.G)(I,i,null),O=!0,p=Object(w.F)(window, "fm:payment-steps:buyer-info-post-success",t[9])},p(t,[e]){(!O||16&e)&&h!==(h=(t[4].title|| "")+ "")&&Object(w.N)(c,h);let n=u;u=v(t),u===n?y[u].p(t,e):(Object(w.B)(),Object(w.W)(y[n],1,1,()=>{y[n]=null}),Object(w.i)(),l=y[u],l||(l=y[u]=g[u](t),l.c()),Object(w.V)(l,1),l.m(s,null));const r=16&e?Object(w.A)($,[Object(w.z)(t[4])]):{};I.$set(r)},i(t){O||(Object(w.V)(m.$$.fragment,t),Object(w.V)(l),Object(w.V)(I.$$.fragment,t),O=!0)},o(t){Object(w.W)(m.$$.fragment,t),Object(w.W)(l),Object(w.W)(I.$$.fragment,t),O=!1},d(t){t&&Object(w.u)(e),Object(w.s)(m),y[u].d(),Object(w.s)(I),p()}}}function Rt(t,e,n){let c,r,o;Object(w.o)(t,P,t=>n(13,c=t)),Object(w.o)(t,T,t=>n(14,r=t)),Object(w.o)(t,L,t=>n(6,o=t));let{lang:i="uk"}=e,{adId:s}=e,{token:a}=e,{confirmPageUrl:u=""}=e;const l=Object(S.a)(f),p=Object(I.a)("PaymentSteps");let h=!1,m=null,g=0,v={},$=[{title:"payment-steps.buyer-info.title",component:U,status:d},{title:"payment-steps.payment-info.title",component:ct,status:O}];const x=t=>()=>{g=t,n(5,$=$.map((e,n)=>({...e,status:n===t?d:n
                                                            <t?j:O})))};return Object(_.b)(()=>{k({token:c,adId:s}).then(t=>{n(4,v={...t.ad,cost:t.product.price,seller:t.seller.name,date:t.ad.createdAt})})}),t.$set=t=>{"lang"in t&&n(10,i=t.lang),"adId"in t&&n(0,s=t.adId),"token"in t&&n(11,a=t.token),"confirmPageUrl"in t&&n(1,u=t.confirmPageUrl)},t.$$.update=()=>{1024&t.$$.dirty&&n(10,i=l(i,"lang",S.b.string,S.b.oneOf(["uk","ru","en"]))),1&t.$$.dirty&&n(0,s=l(s,"adId",S.b.string)),2048&t.$$.dirty&&n(11,a=l(a,"lang",S.b.string)),2&t.$$.dirty&&n(1,u=l(u,"confirmPageUrl",S.b.string)),2048&t.$$.dirty&&Object(w.P)(P,c=a),1024&t.$$.dirty&&Object(w.P)(T,r=i),16384&t.$$.dirty&&Object(M.b)(`${b}/i18n/lang-${r}.json`).then(t=>{Object(w.P)(L,o=e=>t[e]||"")}).catch(y).then(()=>{n(2,h=!0)})},[s,u,h,m,v,$,o,p,x,t=>{n(3,m=t.detail.transactionId),x(1+g)()},i,a]}class Vt extends w.a{constructor(t){super(),Object(w.C)(this,t,Rt,zt,w.L,{lang:10,adId:0,token:11,confirmPageUrl:1})}}var qt=Vt;e.default=Object(r.a)($.trackRendering(Object(c.a)(qt)),f)},15:function(t,e,n){"use strict";var c=n(0),r=n(3);n(29);function o(t){let e,n,r,o;const i=t[9].default,s=Object(c.r)(i,t,t[8],null);return{c(){e=Object(c.v)("a"),s&&s.c(),this.h()},l(t){e=Object(c.l)(t,"A",{class:!0,download:!0,href:!0,hreflang:!0,ping:!0,rel:!0,target:!0,type:!0});var n=Object(c.j)(e);s&&s.l(n),n.forEach(c.u),this.h()},h(){Object(c.e)(e,"class",n=Object(c.I)(t[7]``)+" svelte-1319phz"),Object(c.e)(e,"download",t[0]),Object(c.e)(e,"href",t[1]),Object(c.e)(e,"hreflang",t[2]),Object(c.e)(e,"ping",t[3]),Object(c.e)(e,"rel",t[4]),Object(c.e)(e,"target",t[5]),Object(c.e)(e,"type",t[6])},m(n,i){Object(c.D)(n,e,i),s&&s.m(e,null),r=!0,o=Object(c.F)(e,"click",t[10])},p(t,[n]){s&&s.p&&256&n&&s.p(Object(c.y)(i,t,t[8],null),Object(c.x)(i,t[8],n,null)),(!r||1&n)&&Object(c.e)(e,"download",t[0]),(!r||2&n)&&Object(c.e)(e,"href",t[1]),(!r||4&n)&&Object(c.e)(e,"hreflang",t[2]),(!r||8&n)&&Object(c.e)(e,"ping",t[3]),(!r||16&n)&&Object(c.e)(e,"rel",t[4]),(!r||32&n)&&Object(c.e)(e,"target",t[5]),(!r||64&n)&&Object(c.e)(e,"type",t[6])},i(t){r||(Object(c.V)(s,t),r=!0)},o(t){Object(c.W)(s,t),r=!1},d(t){t&&Object(c.u)(e),s&&s.d(t),o()}}}function i(t,e,n){let{download:o}=e,{href:i}=e,{hreflang:s}=e,{ping:a}=e,{rel:u}=e,{target:l}=e,{type:f}=e;const b=Object(r.a)("Link");let{$$slots:d={},$$scope:j}=e;return t.$set=t=>{"download"in t&&n(0,o=t.download),"href"in t&&n(1,i=t.href),"hreflang"in t&&n(2,s=t.hreflang),"ping"in t&&n(3,a=t.ping),"rel"in t&&n(4,u=t.rel),"target"in t&&n(5,l=t.target),"type"in t&&n(6,f=t.type),"$$scope"in t&&n(8,j=t.$$scope)},[o,i,s,a,u,l,f,b,j,d,function(e){Object(c.h)(t,e)}]}class s extends c.a{constructor(t){super(),Object(c.C)(this,t,i,o,c.L,{download:0,href:1,hreflang:2,ping:3,rel:4,target:5,type:6})}}e.a=s},16:function(t,e,n){"use strict";var c=n(0);n(32);function r(t,e,n){const c=t.slice();return c[1]=e[n],c}function o(t){let e,n,r,o;return{c(){e=Object(c.v)("span"),n=Object(c.v)("span"),o=Object(c.R)(),this.h()},l(t){e=Object(c.l)(t,"SPAN",{class:!0});var r=Object(c.j)(e);n=Object(c.l)(r,"SPAN",{class:!0}),Object(c.j)(n).forEach(c.u),o=Object(c.m)(r),r.forEach(c.u),this.h()},h(){Object(c.e)(n,"class",r=Object(c.I)([t[0]`__dot`,t[0](`__dot--${t[1]}`)].join(" "))+" svelte-12ofwz2"),Object(c.e)(e,"class","svelte-12ofwz2")},m(t,r){Object(c.D)(t,e,r),Object(c.c)(e,n),Object(c.c)(e,o)},p:c.H,d(t){t&&Object(c.u)(e)}}}function i(t){let e,n,i=[1,2,3],s=[];for(let e=0;e
                                                                <3;e+=1)s[e]=o(r(t,i,e));return{c(){e=Object(c.v)( "span");for(let t=0;t<3;t+=1)s[t].c();this.h()},l(t){e=Object(c.l)(t, "SPAN",{class:!0});var n=Object(c.j)(e);for(let t=0;t<3;t+=1)s[t].l(n);n.forEach(c.u),this.h()},h(){Object(c.e)(e, "class",n=Object(c.I)(t[0]``)+ " svelte-12ofwz2")},m(t,n){Object(c.D)(t,e,n);for(let t=0;t<3;t+=1)s[t].m(e,null)},p(t,[n]){if(1&n){let c;for(i=[1,2,3],c=0;c<3;c+=1){const a=r(t,i,c);s[c]?s[c].p(a,n):(s[c]=o(a),s[c].c(),s[c].m(e,null))}for(;c<3;c+=1)s[c].d(1)}},i:c.H,o:c.H,d(t){t&&Object(c.u)(e),Object(c.t)(s,t)}}}function s(t){return[t=>`LoadingAnimation${t}`]}class a extends c.a{constructor(t){super(),Object(c.C)(this,t,s,i,c.L,{})}}var u=a;e.a=u},17:function(t,e,n){"use strict";var c=n(15);e.a=c.a},2:function(t,e,n){"use strict";e.a={FEMS_ENV:"production",PUBLIC_URL:"".concat("https://delivery-one-prd-frontend-static-public-web.s3-eu-west-1.amazonaws.com/fm../../../resources/ua","/"),UA_ROCK_BASE:"https://ua.production.delivery.olx.tools/payment",COST_BASE:"https://ua.staging.delivery.olx.tools/cost",SENTRY_DSN:"https://67c137d846e14eaaa5fd34263e71ec9c@sentry.io/1813293"}},22:function(t,e,n){"use strict";var c=n(0),r=n(7),o=n(1),i=n(28),s=n.n(i);n(53);function a(t){let e,n,r,o,i,a,u,l,f,b,d;const j=t[5].default,O=Object(c.r)(j,t,t[4],null);return{c(){e=Object(c.v)("div"),r=Object(c.R)(),o=Object(c.v)("div"),i=Object(c.v)("button"),l=Object(c.R)(),O&&O.c(),this.h()},l(t){e=Object(c.l)(t,"DIV",{class:!0}),Object(c.j)(e).forEach(c.u),r=Object(c.m)(t),o=Object(c.l)(t,"DIV",{class:!0});var n=Object(c.j)(o);i=Object(c.l)(n,"BUTTON",{class:!0,style:!0}),Object(c.j)(i).forEach(c.u),l=Object(c.m)(n),O&&O.l(n),n.forEach(c.u),this.h()},h(){Object(c.e)(e,"class",n=Object(c.I)(t[2]`-backdrop`)+" svelte-19kxs0y"),Object(c.e)(i,"class",a=Object(c.I)(t[2]`__close`)+" svelte-19kxs0y"),Object(c.e)(i,"style",u=`background-image: url(${s.a});`),Object(c.e)(o,"class",f=Object(c.I)(t[2]``)+" svelte-19kxs0y")},m(n,s){Object(c.D)(n,e,s),Object(c.D)(n,r,s),Object(c.D)(n,o,s),Object(c.c)(o,i),Object(c.c)(o,l),O&&O.m(o,null),b=!0,d=Object(c.F)(i,"click",t[6])},p(t,e){O&&O.p&&16&e&&O.p(Object(c.y)(j,t,t[4],null),Object(c.x)(j,t[4],e,null))},i(t){b||(Object(c.V)(O,t),b=!0)},o(t){Object(c.W)(O,t),b=!1},d(t){t&&Object(c.u)(e),t&&Object(c.u)(r),t&&Object(c.u)(o),O&&O.d(t),d()}}}function u(t){let e,n,r=t[0]&&a(t);return{c(){r&&r.c(),e=Object(c.w)()},l(t){r&&r.l(t),e=Object(c.w)()},m(t,o){r&&r.m(t,o),Object(c.D)(t,e,o),n=!0},p(t,[n]){t[0]?r?(r.p(t,n),Object(c.V)(r,1)):(r=a(t),r.c(),Object(c.V)(r,1),r.m(e.parentNode,e)):r&&(Object(c.B)(),Object(c.W)(r,1,1,()=>{r=null}),Object(c.i)())},i(t){n||(Object(c.V)(r),n=!0)},o(t){Object(c.W)(r),n=!1},d(t){r&&r.d(t),t&&Object(c.u)(e)}}}function l(t,e,n){let{visible:c=!1}=e;const i=Object(o.a)("ui-toolkit/Modal"),s=Object(r.a)();let{$$slots:a={},$$scope:u}=e;return t.$set=t=>{"visible"in t&&n(0,c=t.visible),"$$scope"in t&&n(4,u=t.$$scope)},t.$$.update=()=>{1&t.$$.dirty&&n(0,c=i(c,"visible",o.b.boolean))},[c,s,t=>`Modal${t}`,i,u,a,()=>s("close")]}class f extends c.a{constructor(t){super(),Object(c.C)(this,t,l,u,c.L,{visible:0})}}var b=f;e.a=b},27:function(t,e,n){"use strict";n.d(e,"a",(function(){return o}));var c=n(0);const r=[];function o(t,e=c.H){let n;const o=[];function i(e){if(Object(c.L)(t,e)&&(t=e,n)){const e=!r.length;for(let e=0;e
                                                                    <o.length;e+=1){const n=o[e];n[1](),r.push(n,t)}if(e){for(let t=0;t<r.length;t+=2)r[t][0](r[t+1]);r.length=0}}}return{set:i,update:function(e){i(e(t))},subscribe:function(r,s=c.H){const a=[r,s];return o.push(a),1===o.length&&(n=e(i)||c.H),r(t),()=>{const t=o.indexOf(a);-1!==t&&o.splice(t,1),0===o.length&&(n(),n=null)}}}}},28:function(t,e){t.exports="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij4KICAgIDxwYXRoIGZpbGw9IiMwMDJGMzQiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIwLjU4NiAybC0xLjI3MSAxLjI3TDEyIDEwLjU4NyA0LjY4NSAzLjI3IDMuNDE0IDJIMnYxLjQxNGwxLjI3MSAxLjI3TDEwLjU4NiAxMmwtNy4zMTUgNy4zMTVMMiAyMC41ODVWMjJoMS40MTRsMS4yNzEtMS4yNzFMMTIgMTMuNDE0bDcuMzE1IDcuMzE1TDIwLjU4NiAyMkgyMnYtMS40MTRsLTEuMjctMS4yNzFMMTMuNDE0IDEybDcuMzE2LTcuMzE2TDIyIDMuNDE0VjJ6Ii8+Cjwvc3ZnPgo="},29:function(t,e,n){},3:function(t,e,n){"use strict";e.a=function(t){return function(){for(var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",n="".concat(t).concat(e||""),c=arguments.length,r=new Array(c>1?c-1:0),o=1;o
                                                                        <c;o++)r[o-1]=arguments[o];return r.length>0?"".concat(""," ").concat(n," ").concat(r.filter((function(t){return!!t})).map((function(t){return n+t})).join(" ")):"".concat(""," ").concat(n)}}},32:function(t,e,n){},33:function(t,e,n){"use strict";var c=n(4);function r(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var c=Object.getOwnPropertySymbols(t);e&&(c=c.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,c)}return n}function o(t){for(var e=1;e
                                                                            <arguments.length;e++){var n=null!=arguments[e]?arguments[e]:{};e%2?r(Object(n),!0).forEach((function(e){i(t,e,n[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):r(Object(n)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}))}return t}function i(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}e.a=function(t){var e=t.iframeAttrs,n=t.additionalActions;return function(t){var r=!!t.origin.match(/^https:\/\/olx(\.stage)?\.uapay\.ua/),i=Object(c.c)(document.getElementById(e.id), "contentWindow")===t.source;if(!r||!i||!t.data)return e;var s=o({},e),a=o({changeSize:function(t){var e=t.size,n=e.width,c=e.height;n&&c&&(s.style="width: " .concat(n, "px; height: ").concat(c, "px;"))}},n),u=JSON.parse(t.data);if( "function"!=typeof a[u.action])throw new Error( "Message action not supported: '".concat(u.action, "' in ").concat(s.id, " iFrame"));return a[u.action](u),s}}},35:function(t,e,n){ "use strict";e.a=function(t){return new Intl.DateTimeFormat( "uk",{day: "numeric",month: "numeric",year: "numeric",hour: "numeric",minute: "numeric"}).format(new Date(t))}},4:function(t,e,n){ "use strict";n.d(e, "b",(function(){return o})),n.d(e, "c",(function(){return i})),n.d(e, "a",(function(){return s})),n.d(e, "d",(function(){return a}));var c=n(8),r=n(2),o=function(t){return fetch( "".concat(r.a.PUBLIC_URL).concat(t)).then((function(t){return t.json()}))},i=function(t,e,n){return e.split( ".").reduce((function(t,e){return null==t||void 0===t[e]?void 0:t[e]}),t)||n},s=function(t){var e=t.url,n=t.params,r=t.serializeResponse,o=void 0===r||r,i=t.serviceName,s=void 0===i? "N/A":i,a=function(t){return Promise.reject( "ServiceError"===t.name?t:new c.a(t,s,{url:e,method:n.method}))};return fetch(e,n).then((function(t){return t.ok?o?t.json():t:t.json().then(a)})).catch(a)},a=function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1e4;return function(){for(var n=arguments.length,c=new Array(n),r=0;r
                                                                                <n;r++)c[r]=arguments[r];return new Promise((function(n,r){t.apply(void 0,c).then(n).catch(r),setTimeout((function(){r(new Error( "".concat(t.name, ": ").concat(e/1e3, " secs timeout reached")))}),e)}))}}},5:function(t,e,n){ "use strict";n.d(e, "a",(function(){return i}));var c,r=n(2),o=(c=null,function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return c?Promise.resolve(c):n.e(7).then(n.bind(null,34)).then((function(e){var n=t.tags,o=t.extras;return e.init({dsn:r.a.SENTRY_DSN,environment:r.a.FEMS_ENV}),e.configureScope((function(t){n&&t.setTags(n),o&&t.setExtras(o)})),c=e,e}))}),i=function(t){return function(e){"production"===r.a.FEMS_ENV||"staging"===r.a.FEMS_ENV?o({tags:{Fragment:t,Country:"string"==typeof t?t.substring(0,2):"n/a"}}).then((function(n){n.withScope((function(c){var r,o;(null===(r=e.context)||void 0===r?void 0:r.tags)&&c.setTags(e.context.tags),(null===(o=e.context)||void 0===o?void 0:o.extras)&&c.setExtras(e.context.extras),c.setFingerprint([t,e.message]),n.captureException(e)}))})):console.error("SENTRY:",e)}}},53:function(t,e,n){},54:function(t,e,n){"use strict";var c=n(6);e.a=function(t){var e=t.token,n=t.adId,r=t.lang,o=t.transactionId,i=t.context;return Object(c.b)("/ad/".concat(n,"/transaction/").concat(o,"/form/").concat(i,"/ccard"),{method:"GET",mode:"cors",headers:{"Accept-Language":r,Authorization:"Bearer ".concat(e)}})}},6:function(t,e,n){"use strict";function c(t){return(c="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}function r(t,e){return!e||"object"!==c(e)&&"function"!=typeof e?function(t){if(void 0===t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return t}(t):e}function o(t){var e="function"==typeof Map?new Map:void 0;return(o=function(t){if(null===t||(n=t,-1===Function.toString.call(n).indexOf("[native code]")))return t;var n;if("function"!=typeof t)throw new TypeError("Super expression must either be null or a function");if(void 0!==e){if(e.has(t))return e.get(t);e.set(t,c)}function c(){return i(t,arguments,a(this).constructor)}return c.prototype=Object.create(t.prototype,{constructor:{value:c,enumerable:!1,writable:!0,configurable:!0}}),s(c,t)})(t)}function i(t,e,n){return(i=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Date.prototype.toString.call(Reflect.construct(Date,[],(function(){}))),!0}catch(t){return!1}}()?Reflect.construct:function(t,e,n){var c=[null];c.push.apply(c,e);var r=new(Function.bind.apply(t,c));return n&&s(r,n.prototype),r}).apply(null,arguments)}function s(t,e){return(s=Object.setPrototypeOf||function(t,e){return t.__proto__=e,t})(t,e)}function a(t){return(a=Object.setPrototypeOf?Object.getPrototypeOf:function(t){return t.__proto__||Object.getPrototypeOf(t)})(t)}n.d(e,"a",(function(){return b})),n.d(e,"b",(function(){return d}));var u=function(t){function e(t){var n,c=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"N/A",o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};return function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,e),(n=r(this,a(e).call(this,t.description||t.message))).name="ServiceError",n.code=t.code,n.context={tags:{"fm.origin":c},extras:{source:t,request:o}},n}return function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function");t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,writable:!0,configurable:!0}}),e&&s(t,e)}(e,t),e}(o(Error)),l=n(4),f="https://ua.production.delivery.olx.tools/payment",b={TOKEN_ERROR:"invalid-token",BAD_REQUEST:"bad-request.generic",INACTIVE_AD:"bad-request.inactive-ad",HAS_IN_PROGRESS:"bad-request.has-in-progress",NOT_INVOLVED_PARTY:"bad-request.not-involved-party",OWN_AD:"bad-request.own-ad",NON_ELIGIBLE_SELLER:"bad-request.non-eligible-seller",NON_ELIGIBLE_BUYER:"bad-request.non-eligible-buyer"},d=Object(l.d)((function(t,e){var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},c=n.serializeResponse,r=void 0===c||c,o="".concat(f).concat(t),i=function(t){return Promise.reject("ServiceError"===t.name?t:new u(t,"UARock",{fullUrl:o,method:e.method}))};return fetch(o,e).then((function(t){return t.ok?r?t.json():t:t.json().then(i)})).catch(i)}),1e4)},7:function(t,e,n){"use strict";var c=n(0);n.d(e,"a",(function(){return c.p})),n.d(e,"b",(function(){return c.J}))},8:function(t,e,n){"use strict";function c(t){return(c="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}function r(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function o(t,e){return!e||"object"!==c(e)&&"function"!=typeof e?function(t){if(void 0===t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return t}(t):e}function i(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function");t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,writable:!0,configurable:!0}}),e&&u(t,e)}function s(t){var e="function"==typeof Map?new Map:void 0;return(s=function(t){if(null===t||(n=t,-1===Function.toString.call(n).indexOf("[native code]")))return t;var n;if("function"!=typeof t)throw new TypeError("Super expression must either be null or a function");if(void 0!==e){if(e.has(t))return e.get(t);e.set(t,c)}function c(){return a(t,arguments,l(this).constructor)}return c.prototype=Object.create(t.prototype,{constructor:{value:c,enumerable:!1,writable:!0,configurable:!0}}),u(c,t)})(t)}function a(t,e,n){return(a=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Date.prototype.toString.call(Reflect.construct(Date,[],(function(){}))),!0}catch(t){return!1}}()?Reflect.construct:function(t,e,n){var c=[null];c.push.apply(c,e);var r=new(Function.bind.apply(t,c));return n&&u(r,n.prototype),r}).apply(null,arguments)}function u(t,e){return(u=Object.setPrototypeOf||function(t,e){return t.__proto__=e,t})(t,e)}function l(t){return(l=Object.setPrototypeOf?Object.getPrototypeOf:function(t){return t.__proto__||Object.getPrototypeOf(t)})(t)}n.d(e,"b",(function(){return f})),n.d(e,"a",(function(){return b}));var f=function(t){function e(t,n){var c;return r(this,e),(c=o(this,l(e).call(this,n||t||"Bad Response from UAPay, no details were provided."))).translated=!(!n&&!t),c.context={tags:{"fm.origin":"UAPay"},extras:{message:t,messageLocalized:n}},c}return i(e,t),e}(function(t){function e(){var t,n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return r(this,e),(t=o(this,l(e).call(this))).name="UserError",t.message="string"==typeof n?n:n.description||t.name,t}return i(e,t),e}(s(Error))),b=(s(Error),function(t){function e(t){var n,c=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};return r(this,e),(n=o(this,l(e).call(this,t.description||t.message))).name="ServiceError",n.context={tags:{"fm.origin":c},extras:{source:t,request:i}},n}return i(e,t),e}(s(Error)))},91:function(t,e){t.exports='
                                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
                                                                                        <g fill="none" fill-rule="evenodd">
                                                                                            <path fill="#CFC980" d="M34.539 24.424L0 12.084 0 58.977 34.528 71.313 34.528 71.321 34.535 71.318 34.535 71.321 34.536 71.32 34.542 71.318 34.549 71.321 34.549 71.318 34.556 71.321 34.556 71.313 34.549 71.316 34.549 71.313 34.556 71.311 34.556 71.313 34.563 71.311 34.563 71.308 69.077 58.977 69.077 12.084z" transform="translate(5.429 4.286)"></path>
                                                                                            <path fill="#F8FBCF" d="M0 56.324L34.549 68.668 34.549 21.775 0 9.432z" transform="translate(5.429 4.286)"></path>
                                                                                            <path fill="#F8DD3E" d="M34.528 21.775L34.528 68.668 69.077 56.324 69.077 9.432z" transform="translate(5.429 4.286)"></path>
                                                                                            <path fill="#CFC980" d="M19.536 25.872c-.179-1.14.6-2.212 1.74-2.39 1.145-.18 2.213.599 2.395 1.743.178 1.141-.603 2.213-1.744 2.391-.109.017-.22.025-.327.025-1.012 0-1.902-.736-2.064-1.769m3.49 8.153c-.748-.882-.639-2.201.24-2.949.882-.748 2.202-.642 2.95.24h.002c.745.882.64 2.201-.243 2.95-.393.334-.873.496-1.353.496-.594 0-1.183-.249-1.596-.737m7.218 4.964c-1.071-.433-1.59-1.655-1.157-2.726.432-1.072 1.651-1.588 2.723-1.155 1.074.432 1.59 1.652 1.158 2.723-.33.815-1.114 1.309-1.942 1.309-.26 0-.525-.048-.782-.151m8.187 1.936c-1.15-.106-1.995-1.127-1.886-2.28.108-1.149 1.13-1.994 2.28-1.885 1.149.108 1.994 1.13 1.885 2.28-.1 1.082-1.012 1.896-2.078 1.896-.067 0-.134-.002-.201-.01m7.787.382c-1.147-.126-1.975-1.161-1.85-2.31.126-1.147 1.161-1.976 2.308-1.85 1.15.125 1.978 1.157 1.852 2.307-.117 1.071-1.024 1.864-2.078 1.864-.076 0-.154-.003-.232-.011m6.758 1.819c-1.021-.544-1.409-1.811-.868-2.832.544-1.019 1.811-1.407 2.832-.865 1.019.544 1.407 1.81.865 2.832-.376.706-1.102 1.11-1.85 1.11-.332 0-.666-.08-.979-.245m7.871 9.294c.134.028.265.067.394.12.125.05.245.117.36.192.114.076.22.162.318.26.097.097.184.204.26.318.074.114.141.234.192.36.053.128.092.26.12.393.027.134.041.27.041.408 0 .136-.014.273-.041.41-.028.134-.067.265-.12.39-.05.126-.118.249-.193.363-.075.115-.162.22-.26.318-.097.095-.203.184-.317.26-.115.075-.235.14-.36.192-.129.053-.26.092-.394.12-.134.025-.27.04-.407.04-.137 0-.274-.015-.41-.04-.134-.028-.265-.067-.391-.12-.126-.053-.248-.117-.363-.192-.114-.076-.22-.165-.318-.26-.095-.097-.184-.203-.26-.318-.075-.114-.139-.237-.192-.363-.053-.125-.092-.256-.12-.39-.025-.137-.039-.274-.039-.41 0-.137.014-.274.04-.408.027-.134.066-.265.12-.393.052-.126.116-.246.192-.36.075-.114.164-.22.26-.318.097-.098.203-.184.317-.26.115-.075.237-.142.363-.192.126-.053.257-.092.39-.12.271-.056.55-.056.818 0zm.357-6.51c.497 1.044.056 2.294-.987 2.79-.29.14-.598.204-.902.204-.78 0-1.531-.438-1.889-1.191-.5-1.044-.055-2.294.988-2.79 1.044-.497 2.29-.056 2.79.987z" transform="translate(5.429 4.286)"></path>
                                                                                            <path fill="#002F34" d="M28.384 14.1c1.19-1.485 1.903-3.368 1.903-5.415C30.287 3.896 26.39 0 21.6 0s-8.685 3.896-8.685 8.685c0 2.047.713 3.93 1.902 5.415l.002.004c.4.498.852.952 1.35 1.352l5.426 5.437 5.427-5.43c.501-.401.957-.857 1.359-1.359l.003-.003z" transform="translate(5.429 4.286)"></path>
                                                                                            <path fill="#CFC980" d="M16.76 8.685c0-2.673 2.167-4.841 4.841-4.841 2.674 0 4.842 2.168 4.842 4.841 0 2.674-2.168 4.842-4.842 4.842-2.674 0-4.841-2.168-4.841-4.842" transform="translate(5.429 4.286)"></path>
                                                                                        </g>
                                                                                    </svg>'},92:function(t,e){t.exports='
                                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
                                                                                        <g fill="#ED1C24" fill-rule="evenodd">
                                                                                            <path d="M56.696 21.16c.215-.069.499.069.782.447l12.818 12.667c.748.756.748 1.901 0 2.463L57.478 49.599c-.283.378-.567.47-.782.355-.216-.115-.352-.447-.352-.928V21.985c0-.47.136-.756.352-.825zM34.98 0h.897l.862.364 13.03 13.158c.56.751.37 1.32-.56 1.32h-5.4c-.93 0-1.67.751-1.67 1.696v9.766c0 .945-.75 1.696-1.87 1.696h-9.49c-.93 0-1.68-.751-1.68-1.696v-9.766c0-.945-.74-1.696-1.681-1.696h-5.77c-.93 0-1.12-.569-.56-1.32L34.128.364 34.98 0zM14.692 20.617c.24.115.39.447.39.927v27.564c0 .48-.15.766-.39.858-.23.091-.563 0-.953-.286L.569 36.458c-.758-.56-.758-1.704 0-2.459l13.17-13.027c.39-.377.723-.469.953-.355zM30.587 42h9.588c1.133 0 1.891.759 1.891 1.713v10.44c0 1.137.747 1.896 1.687 1.896h5.083c.94 0 1.313.564.566 1.138L36.609 70.282c-.385.38-.849.575-1.324.575-.464 0-.94-.195-1.313-.575L21.179 57.187c-.758-.574-.385-1.138.555-1.138h5.456c.951 0 1.699-.759 1.699-1.897V43.713c0-.954.758-1.713 1.698-1.713z" transform="translate(4.571 4.571)"></path>
                                                                                        </g>
                                                                                    </svg>'},93:function(t,e){t.exports='
                                                                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 72 51">
                                                                                        <defs>
                                                                                            <path id="prefix__a" d="M67.729 50.518H3.959C2.639 49.203 1.9 48.466.582 47.15V3.926L3.96.556h63.77l3.376 3.37V47.15l-3.376 3.368z"></path>
                                                                                            <path id="prefix__c" d="M53.56 2.912v44c-1.165 1.162-1.817 1.818-2.987 2.98H.255L50.658.017c1.12 1.112 1.767 1.758 2.902 2.895z"></path>
                                                                                            <path id="prefix__e" d="M0.005 0.209L70.477 0.209 70.477 7.477 0.005 7.477z"></path>
                                                                                            <path id="prefix__g" d="M7.69 4.275c0 2.067-1.68 3.743-3.753 3.743-2.073 0-3.752-1.676-3.752-3.743C.185 2.207 1.865.53 3.937.53S7.69 2.207 7.69 4.275z"></path>
                                                                                            <path id="prefix__i" d="M8.054 4.275c0 2.067-1.68 3.743-3.752 3.743-2.073 0-3.753-1.676-3.753-3.743C.55 2.207 2.23.53 4.302.53c2.072 0 3.752 1.676 3.752 3.744z"></path>
                                                                                            <path id="prefix__k" d="M0.572 0.539L9.842 0.539 9.842 2.852 0.572 2.852z"></path>
                                                                                            <path id="prefix__m" d="M0.572 0.337L15.206 0.337 15.206 2.636 0.572 2.636z"></path>
                                                                                            <path id="prefix__o" d="M3.338 1.768c0 .85-.691 1.54-1.543 1.54S.253 2.617.253 1.767C.253.918.943.23 1.795.23c.852 0 1.543.69 1.543 1.54z"></path>
                                                                                            <path id="prefix__q" d="M0.572 0.116L28.494 0.116 28.494 6.283 0.572 6.283z"></path>
                                                                                        </defs>
                                                                                        <g fill="none" fill-rule="evenodd" transform="translate(.286 -.429)">
                                                                                            <mask id="prefix__b" fill="#fff">
                                                                                                <use xlink:href="#prefix__a"></use>
                                                                                            </mask>
                                                                                            <path fill="#23E5DB" d="M-2.55 -2.576L74.238 -2.576 74.238 53.651 -2.55 53.651z" mask="url(#prefix__b)"></path>
                                                                                            <g transform="translate(17.544 .627)">
                                                                                                <mask id="prefix__d" fill="#fff">
                                                                                                    <use xlink:href="#prefix__c"></use>
                                                                                                </mask>
                                                                                                <path fill="#00A7A0" d="M-2.878 -3.116L56.693 -3.116 56.693 53.025 -2.878 53.025z" mask="url(#prefix__d)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(.627 8.772)">
                                                                                                <mask id="prefix__f" fill="#fff">
                                                                                                    <use xlink:href="#prefix__e"></use>
                                                                                                </mask>
                                                                                                <path fill="#003035" d="M-3.128 -2.924L73.61 -2.924 73.61 10.61 -3.128 10.61z" mask="url(#prefix__f)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(58.27 35.714)">
                                                                                                <mask id="prefix__h" fill="#fff">
                                                                                                    <use xlink:href="#prefix__g"></use>
                                                                                                </mask>
                                                                                                <path fill="#23E5DB" d="M-2.948 -2.602L10.822 -2.602 10.822 11.151 -2.948 11.151z" mask="url(#prefix__h)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(52.632 35.714)">
                                                                                                <mask id="prefix__j" fill="#fff">
                                                                                                    <use xlink:href="#prefix__i"></use>
                                                                                                </mask>
                                                                                                <path fill="#003035" d="M-2.584 -2.602L11.186 -2.602 11.186 11.151 -2.584 11.151z" mask="url(#prefix__j)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(5.64 26.942)">
                                                                                                <mask id="prefix__l" fill="#fff">
                                                                                                    <use xlink:href="#prefix__k"></use>
                                                                                                </mask>
                                                                                                <path fill="#CBF7EE" d="M-2.561 -2.594L12.975 -2.594 12.975 5.985 -2.561 5.985z" mask="url(#prefix__l)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(5.64 31.328)">
                                                                                                <mask id="prefix__n" fill="#fff">
                                                                                                    <use xlink:href="#prefix__m"></use>
                                                                                                </mask>
                                                                                                <path fill="#CBF7EE" d="M-2.561 -2.795L18.339 -2.795 18.339 5.769 -2.561 5.769z" mask="url(#prefix__n)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(55.138 38.22)">
                                                                                                <mask id="prefix__p" fill="#fff">
                                                                                                    <use xlink:href="#prefix__o"></use>
                                                                                                </mask>
                                                                                                <path fill="#FF5636" d="M-2.88 -2.904L6.47 -2.904 6.47 6.44 -2.88 6.44z" mask="url(#prefix__p)"></path>
                                                                                            </g>
                                                                                            <g transform="translate(5.64 18.17)">
                                                                                                <mask id="prefix__r" fill="#fff">
                                                                                                    <use xlink:href="#prefix__q"></use>
                                                                                                </mask>
                                                                                                <path fill="#CBF7EE" d="M-2.561 -3.017L31.627 -3.017 31.627 9.416 -2.561 9.416z" mask="url(#prefix__r)"></path>
                                                                                            </g>
                                                                                        </g>
                                                                                    </svg>'}}).default;var t=this.render;return window.fems.store["@olx-fm/fm-delivery|ua/payment-steps"]=function(...e){const n=t(...e),c=n.destroy;return n.destroy=()=>{window.fems.instances=window.fems.instances.filter(t=>t.fragment!==n),c()},window.fems.instances.push({uniqueKey:"@olx-fm/fm-delivery|ua/payment-steps",fragment:n,elem:e[0],initialProps:e[1]||{}}),n},this.render}(); //# sourceMappingURL=https://delivery-one-prd-frontend-static-public-web.s3-eu-west-1.amazonaws.com/fm../../../resources/ua/payment-steps/parts/renderFunc-c3aa465bdb23f70c43d3.js.map })();
    </script>
    <script data-fems="" data-type="script-instances">
        (function(){ var instances = [{"uniqueKey":"@olx-fm\/fm-delivery|ua\/payment-steps","props":{"lang":"ru","adId":"641999867","token":"13ddb3dc303be9912ddd578d30bd64b552eb9da6","confirmPageUrl":"https:\/\/www.olx.ua\/safedeal\/confirm\/"},"selector":".delivery-fm-payment-steps"}]; window.addEventListener('load', function() { instances.forEach(function(inst) { document.querySelectorAll(inst.selector).forEach(function(el) { el.setAttribute('data-fems', ''); el.setAttribute('data-type', 'fems-mountpoint'); window.fems.store[inst.uniqueKey](el, inst.props); }); }); }); })();
    </script>
    <script type="text/javascript">
        var _adblock = true;
    </script>
    <script type="text/javascript" src="/assets/olx/js/advertising.js"></script>
    <link rel="stylesheet" type="text/css" href="/assets/olx/css/sw7186d49cf41b293eb51080192518822f.css">
    <!--[if lte IE 8]>                      <link rel="stylesheet" type="text/css" href="https://static-olxeu.akamaized.net/static/olxua/packed/swc63c95add6e0445e53016b1bd27edf58.css">
                    <![endif]-->

    <script type="text/javascript">
        window.suggestmeyes_loaded = true;
        var action = 'safedeal';
        var method = 'payment';
        var user_logged = 1;
        var www_base = 'https://www.olx.ua';
        var www_base_no_namespace = 'https://www.olx.ua';
        var www_base_ajax = 'https://www.olx.ua/ajax';
        var static_files_www_base = 'https://static-olxeu.akamaized.net/static/olxua/';
        var external_static_files_www_base = 'https://static-olxeu.akamaized.net/static/olxua/naspersclassifieds-regional/olxeu-atlas-web-olxua/static/';
        var external_static_files_www_base_main = 'https://static-olxeu.akamaized.net/static/olxua/naspersclassifieds-regional/olxeu-atlas-web/static/';
        var session_domain = 'olx.ua';
        var site_domain = 'www.olx.ua';
        var decimal_separator = '.';
        var thousands_separator = ' ';
        var sitecode = 'olxua';
        var defaultCurrency = 'UAH';
        var config_currency = 'грн.';
        var useExternalScripts = 1;
        var lang = 'ru';
        var hasRwd = 0;
        var module_ad_discount_push = 1;
        var module_landing_homegarden_ua = 1;
        var module_landing_jobs_ua = 1;
        var module_safedeal_always_active = 1;
        var module_police_bank_info = 1;
        var module_paidads = 1;
        var module_facebook_login = 1;
        var module_new_emails = 1;
        var module_newmoderation = 1;
        var module_payu = 1;
        var module_districts = 1;
        var module_new_search_filters = 1;
        var module_new_myaccount = 1;
        var module_currencies = 1;
        var module_currencies_new = 1;
        var module_solr_currency_sorting_index = 1;
        var module_solr_currency_sorting_on_query = 1;
        var module_sms_notification = 1;
        var module_metro = 1;
        var module_superdeal = 1;
        var module_phone_login = 1;
        var module_contact_as_image = 1;
        var module_mobile_app = 1;
        var module_unfinished_payments = 1;
        var module_new_sms_notification = 1;
        var module_trusted_changes = 1;
        var module_stock_photos_info = 1;
        var module_refugees = 1;
        var module_refugees_adding = 1;
        var module_multiacc = 1;
        var module_olx6 = 1;
        var module_gpt_banners = 1;
        var module_i2_payment = 1;
        var module_paid_subscriptions = 1;
        var module_mweb_shops = 1;
        var module_topupaccount = 1;
        var module_portmone = 1;
        var module_plutus_payment = 1;
        var module_plutus_payment_frontend = 1;
        var module_redis_hash = 1;
        var module_redis_cluster_revert = 1;
        var module_rest_api = 1;
        var module_phone_in_desc = 1;
        var module_anonymous_chat_app = 1;
        var module_ads_no_results = 1;
        var module_new_at = 1;
        var module_bonus_credits = 1;
        var module_geo6_multiple_langs = 1;
        var module_crm = 1;
        var module_gpt_banners_i2 = 1;
        var module_new_tracking = 1;
        var module_new_tracking_i2 = 1;
        var module_ninja_m_legacy = 1;
        var module_clm = 1;
        var module_paid_subscriptions_single = 1;
        var module_user_online_status = 1;
        var module_pushup_new = 1;
        var module_topupaccount_newemail = 1;
        var module_afc_to_dfp = 1;
        var module_no_old_subdomains = 1;
        var module_observed_new = 1;
        var module_ap_ldap_login = 1;
        var module_new_safety_tips = 1;
        var module_disable_free_refresh_categories = 1;
        var module_observed_anonymous = 1;
        var module_new_controllers = 1;
        var module_vas_config_wallet = 1;
        var module_vas_config_wallet_before = 1;
        var module_vas_config_nnl_limits = 1;
        var module_vas_config_nnl_business_limits = 1;
        var module_vas_config_topads = 1;
        var module_topupaccount_wallet = 1;
        var module_new_dfp = 1;
        var module_afs_on_empty_search_i2 = 1;
        var module_landing_action = 1;
        var module_split_item_content = 1;
        var module_user_sms_verification = 1;
        var module_user_photo = 1;
        var module_show_limits_price_on_posting_form = 1;
        var module_enable_premium_account = 1;
        var module_flagged_ads = 1;
        var module_shop_filters = 1;
        var module_mandatory_login = 1;
        var module_gemius = 1;
        var module_remove_emailanswers_on_posting = 1;
        var module_multipay_ati_new_report = 1;
        var module_paid_feature_expires = 1;
        var module_nps_survey = 1;
        var module_vas_config_tariff_bonus_points = 1;
        var module_treatments = 1;
        var module_accept_arranged_salary = 1;
        var module_recaptcha = 1;
        var module_app_homescreen = 1;
        var module_app_homescreen_tiles = 1;
        var module_disable_adblock_afs = 1;
        var module_log_sent_emails = 1;
        var module_users_extra_data = 1;
        var module_safedeal = 1;
        var module_safedeal_buyer = 1;
        var module_phone_views_logs = 1;
        var module_track_features = 1;
        var module_atlasorm = 1;
        var module_discount_tool = 1;
        var module_jobs_free_seek = 1;
        var module_messages_spammers = 1;
        var module_topads_promotions = 1;
        var module_payment_click_tracking = 1;
        var module_pricing_test_group_assignment = 1;
        var module_user_settings_recaptcha = 1;
        var module_vas_valid_to_date = 1;
        var module_change_localisation_label = 1;
        var module_require_register_token = 1;
        var module_ad_paid_features = 1;
        var module_new_jobs = 1;
        var module_tradus = 1;
        var module_mass_tests = 1;
        var module_nps_jobs_survey_db_tables = 1;
        var module_tariff_basket = 1;
        var module_bundles = 1;
        var module_bundles_vas = 1;
        var module_bundles_infolayer = 1;
        var module_bundles_packet = 1;
        var module_ab_tests = 1;
        var module_tracking_fix = 1;
        var module_last_messages_in_conversations = 1;
        var module_cv_upload = 1;
        var module_jobs_message_prefill = 1;
        var module_ad_cache_reload_schedule = 1;
        var module_afs_refactor = 1;
        var module_test_afc_afs_slots_listing = 1;
        var module_disable_verification_targeting = 1;
        var module_adblock_targeting = 1;
        var module_adblock_targeting_new = 1;
        var module_log_ad_limited = 1;
        var module_disable_ads_output_cache = 1;
        var module_disable_ad_output_cache = 1;
        var module_sms_verification_phone_search = 1;
        var module_race_test_prediction = 1;
        var module_b2c_business_page = 1;
        var module_premium_banner = 1;
        var module_vas_config_refresh_for_packages = 1;
        var module_vas_logo_link = 1;
        var module_new_category_suggester = 1;
        var module_payment_providers_configurable = 1;
        var module_entry_points_logger = 1;
        var module_rabbit_mq = 1;
        var module_register_restrict_email = 1;
        var module_async_event_bus = 1;
        var module_forced_business_categories = 1;
        var module_page_views_from_mysql = 1;
        var module_wallet_history = 1;
        var module_promo_points = 1;
        var module_app_control_recaptcha_registration = 1;
        var module_app_control_akamai_bot_manager = 1;
        var module_browser_fingerprint = 1;
        var module_highlight_salary_parameter_in_edit = 1;
        var module_disable_say_hello = 1;
        var module_advertising_test_token = 1;
        var module_new_free_connection = 1;
        var module_skip_free_mysql_connection = 1;
        var module_db_aurora = 1;
        var module_laquesis = 1;
        var module_disable_slash_m = 1;
        var module_new_friendly_links_category_repository = 1;
        var module_user_extended_in_ad_card = 1;
        var module_api_session_in_memory = 1;
        var module_payment_session_status_changes = 1;
        var module_periodic_phone_blocking = 1;
        var module_session_eviction_recovery = 1;
        var module_anonymize_user_passwords_in_sms_queue = 1;
        var module_comms = 1;
        var module_vas_validity_message = 1;
        var module_didomi_cmp = 1;
        var module_cmp = 1;
        var module_hash_sms_password = 1;
        var module_ad_discount = 1;
        var module_pushup_automatic = 1;
        var module_hide_adverts_slots = 1;
        var module_delete_secure = 1;
        var module_group_activation_of_limited_ads = 1;
        var module_mandatory_login_for_chat = 1;
        var module_new_sidebar = 1;
        var module_show_photo_setting = 1;
        var module_users_without_password_detector = 1;
        var module_ads_efficiency = 1;
        var module_appleAllowLongPushes = 1;
        var module_targeting_ru_email = 1;
        var module_remove_old_ati = 1;
        var module_vas_logo = 1;
        var module_ua_discounts_promo = 1;
        var module_redis_split_db = 1;
        var module_olx_delivery = 1;
        var module_safedeal_queues = 1;
        var module_safedeal_transactions_tooltip = 1;
        var module_delivery_request_sent = 1;
        var module_delivery_request = 1;
        var module_delivery_request_reserved = 1;
        var module_delivery_request_popup = 1;
        var module_dfp_refactor = 1;
        var module_nnl_category_migration = 1;
        var module_new_dfp_segment = 1;
        var module_dfp_segment_mysql = 1;
        var module_register_confirm_token = 1;
        var module_control_engine = 1;
        var module_detached_categories = 1;
        var module_user_activity_tracker = 1;
        var module_wallet_as_a_service = 1;
        var module_apollo_stage0 = 1;
        var module_apollo_stage1 = 1;
        var module_apollo_stage2 = 1;
        var module_apollo_stage3 = 1;
        var module_send_saved_searches_tracking_to_hydra = 1;
        var module_exchange_rate = 1;
        var module_turn_off_merge_mail = 1;
        var module_answers_with_phone = 1;
        var module_price_project_price_manager_prerequisite = 1;
        var module_adscreen_recommendations_experiment_enabled = 1;
        var module_measure_request_to_cognito = 1;
        var module_exclude_checkboxes_from_solr_index = 1;
        var module_bulk_image_reorder = 1;
        var module_sap_report_entries = 1;
        var module_telegraph_moderation = 1;
        var module_store_image_update_sizes = 1;
        var module_solr_cloud = 1;
        var module_fraud_detection = 1;
        var module_fraud_detector_queue = 1;
        var module_accurate_location = 1;
        var module_password_hashing = 1;
        var module_hermes_new_api = 1;
        var module_ab_force_login_posting = 1;
        var module_history_extra_info = 1;
        var module_observed_push = 1;
        var module_mobile_slot_manager = 1;
        var module_wp_nativemode = 1;
        var module_apps_disable_alog = 1;
        var module_force_login_posting = 1;
        var module_flagged_ads_alter = 1;
        var module_use_www_subdomain = 1;
        var module_ssl_only = 1;
        var module_newrelic_api_app = 1;
        var module_hide_disabled_parameters = 1;
        var module_vas_treatments_thresholds_test_log = 1;
        var module_hermes_messages = 1;
        var module_new_hermes_executor = 1;
        var module_legacy_cities = 1;
        var module_statistics_i2 = 1;
        var module_ignore_sub_region_in_searches = 1;
        var module_multipay_touchpoints = 1;
        var module_fair_expiration = 1;
        var module_fair_expiration_moderated_end = 1;
        var module_log_erec_emails = 1;
        var module_new_conversation_limiter = 1;
        var module_eventbus_publisher = 1;
        var module_phone_views_block_scammers = 1;
        var module_user_login_recaptcha = 1;
        var module_register_recaptcha = 1;
        var module_safedeal_mobile_posting = 1;
        var module_S3FileStorage = 1;
        var module_disable_banned_ips = 1;
        var module_mweb_ad = 1;
        var module_mweb_listing = 1;
        var module_mweb_home = 1;
        var module_mweb_alternate_links = 1;
        var module_mweb_recaptcha = 1;
        var module_mweb_login = 1;
        var module_mweb_menu = 1;
        var module_mweb_chat = 1;
        var module_mweb_ads_management = 1;
        var module_use_tokens_for_login = 1;
        var module_safedeal_push = 1;
        var module_tariff_tester_prerequisite = 1;
        var module_tariff_tester = 1;
        var module_price_project_data_service = 1;
        var module_messages_recaptcha = 1;
        var module_sqs_queue = 1;
        var module_redis_cluster_part1 = 1;
        var module_redis_cluster_part2 = 1;
        var module_redis_cluster_part3 = 1;
        var module_redis_cluster_part4 = 1;
        var module_redis_cluster_part5 = 1;
        var module_redis_cluster = 1;
        var module_redis_cluster_observed = 1;
        var module_price_project_discount_dealer = 1;
        var module_redis_backend_disabled = 1;
        var module_redis_frontend_disabled = 1;
        var module_password_crack_time = 1;
        var module_send_user_moderation_events_to_karma = 1;
        var module_statsd = 1;
        var module_redis_observed_disabled = 1;
        var module_redis_cluster_migration_finished = 1;
        var module_redis_cluster_observed_migration_finished = 1;
        var module_price_project_price_manager = 1;
        var module_cmt_tree = 1;
        var module_cmt_category_icon = 1;
        var module_cmt_category_type = 1;
        var module_cmt_dry_run = 1;
        var module_proforma_provider = 1;
        var module_show_proforma_on_frontend = 1;
        var module_cognito_user_pool = 1;
        var module_ad_cache_with_apollo_images_from_master_db = 1;
        var module_olx_redesign = 1;
        var isTestServer = 0;
        var sms_verified = 0;
        var user_sms_verified = 1;
        var mobileNumberPatternJs = '^(?:(?:\\+?(380))|(0))?((?:39|50|66|95|99|63|93|67|68|96|97|98|91|92|94|73{1})[0-9]{5,7})$|^(?:\+?(?<code_ru>7))?(?<phone_ru>(?:900|901|902|903|904|905|906|908|909|910|911|912|913|914|915|916|917|918|919|920|921|922|923|924|925|926|927|928|929|930|931|932|933|934|936|937|938|939|941|950|951|952|953|955|956|958|960|961|962|963|964|965|966|967|968|969|970|971|977|978|980|981|982|983|984|985|986|987|988|989|991|992|993|994|995|996|997|999)[0-9]{7})$';
        var ad_id = 641999867;
        var confirmPageUrl = 'https://www.olx.ua/safedeal/confirm/';
        var csrfAddAdToObserved = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1ODgyNzE0Mzl9.ypK9GUwIQldEAbv5_w_Bzhdb_ivgI02EaMYhHzhre0w';
        var csrfRemoveAdFromObserved = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1ODgyNzE0Mzl9.y8ViaP6mG3OLt9EPG7rGPTkzNQp6pHWZEar-0IsjCiQ';
        var events_break = false;
        var N = 15;
        var ar_duo1 = Math.floor(Math.random() * N + 1);
        var pp_gemius_identifier = new String('0nHqv6tj9z5nRfsmP697J6RuLbo6IEODmOw0yRKw6PX.67');
        var gemius_script_src = 'https://static-olxeu.akamaized.net/static/olxua/naspersclassifieds-regional/olxeu-atlas-web/static/js/xgemius.js';

        function __(txt) {
            if (typeof translations == 'object') {
                if (translations[txt] == undefined) {
                    return txt;
                } else {
                    return translations[txt];
                }
            }
            return txt;
        }
    </script>
    <script type="text/javascript" async="" src="/assets/olx/js/sdk.js" charset="utf-8"></script>
    <!--[if lt IE 9]>
            <script type="text/javascript" src="https://static-olxeu.akamaized.net/static/olxua/js/scripts/html5shiv.min.js"></script>
        <![endif]-->
    <meta name="google-site-verification" content="UCLSn2xOGJGPnxvgBEEuNKa-YugUI_NChfA_rAN19v0">

    <script src="/assets/olx/js/ads.js" type="text/javascript" async=""></script>
    <script src="/assets/olx/js/publishertag.js" type="text/javascript" async=""></script>
    <script src="/assets/olx/js/adsbygoogle.js" type="text/javascript" async=""></script>
    <script src="/assets/olx/js/gpt.js" type="text/javascript" async=""></script>
    <link id="baxter-style-id-olxua.css" rel="stylesheet" type="text/css" href="/assets/olx/css/olxua.css" media="all">
    <link rel="stylesheet" href="/assets/css/mobile.css"/>
    <script type="text/javascript" async="" src="/assets/olx/js/gtm_002.js"></script>
    <script type="text/javascript" async="" id="ga-script-tag" src="/assets/olx/js/analytics.js"></script>
</head>

<body class="" style="overflow-x: hidden !important;">
    <iframe style="display: none;" name="__cmpLocator"></iframe>
    <div id="didomi-host"></div>
    <!-- Google Tag Manager -->
    <!-- End Google Tag Manager -->
    <div id="div-gpt-ad-test"></div>
    <script type="text/javascript">
        var checkDivElement = true;
    </script>
    <script>
        var advertisingAbTest = {
            "controlEngineTestGroups": [
                [1, 100]
            ],
            "controlEngineTestGroupsMweb": [
                [1, 100]
            ],
            "BannerFeedbackTest_paused": "8b7ce476-2914-4609-ad34-2cff401110f6",
            "BaxterTest": [
                [1, 100]
            ],
            "BaxterAfsTest": [
                [1, 100]
            ],
            "BaxterTestMweb": [
                [1, 100]
            ]
        };
    </script>
    <script async="async" type="text/javascript" src="/assets/olx/js/publishertag.js"></script>
    <script>
        window.Criteo = window.Criteo || {};
        window.Criteo.events = window.Criteo.events || [];
        window.criteoSlotsData = [{
            "abTest": [
                [1, 100]
            ],
            "container": {
                "dfpId": "div-gpt-ad-listing-top",
                "criteoId": "Crt-1406558",
                "dataAdFormat": "fluid",
                "dataAdLayoutKey": "-he+h+43-24+52",
                "dataAdClient": "ca-pub-6111053159423085",
                "dataAdSlot": 6644931680,
                "size": [90, 728],
                "style": {
                    "margin": "auto",
                    "padding": "10px",
                    "max-height": "90px"
                }
            },
            "slot": {
                "zoneId": 1406558,
                "overrideZoneFloor": false
            }
        }, {
            "abTest": [
                [1, 100]
            ],
            "container": {
                "dfpId": "div-gpt-ad-item-top",
                "criteoId": "Crt-1406558-1",
                "dataAdFormat": "fluid",
                "dataAdLayoutKey": "-he+h+43-24+52",
                "dataAdClient": "ca-pub-6111053159423085",
                "dataAdSlot": 6933255038,
                "size": [90, 728],
                "style": {
                    "margin": "auto",
                    "padding": "10px",
                    "max-height": "90px"
                }
            },
            "slot": {
                "zoneId": 1406558,
                "overrideZoneFloor": false
            }
        }, {
            "abTest": [
                [1, 100]
            ],
            "container": {
                "dfpId": "div-gpt-ad-item-sidebar",
                "criteoId": "Crt-1406559",
                "dataAdFormat": "fluid",
                "dataAdLayoutKey": "-7g+ed+2w-11-82",
                "dataAdClient": "ca-pub-6111053159423085",
                "dataAdSlot": 7759251544,
                "style": {
                    "width": "300px",
                    "height": "250px"
                },
                "size": [250, 300]
            },
            "slot": {
                "zoneId": 1406559,
                "overrideZoneFloor": false
            }
        }, {
            "abTest": [
                [1, 100]
            ],
            "container": {
                "dfpId": "div-gpt-ad-listing-sidebar",
                "dataAdClient": "ca-pub-6111053159423085",
                "dataAdFormat": "car",
                "dataAdSlot": 8943791968,
                "criteoId": "Crt-1406560",
                "style": {
                    "width": "160px",
                    "height": "600px"
                },
                "size": [600, 160]
            },
            "slot": {
                "zoneId": 1406560,
                "overrideZoneFloor": false
            }
        }, {
            "abTest": [
                [1, 100]
            ],
            "container": {
                "dfpId": "div-gpt-ad-listing-middle",
                "criteoId": "Crt-1406561",
                "size": [165, 890]
            },
            "slot": {
                "zoneId": 1406561,
                "overrideZoneFloor": false
            }
        }, {
            "abTest": [
                [1, 100]
            ],
            "container": {
                "dfpId": "div-gpt-liting-after-promoted",
                "criteoId": "Crt-1406561-1",
                "size": [165, 890]
            },
            "slot": {
                "zoneId": 1406561,
                "overrideZoneFloor": false
            }
        }];
    </script>
    <script type="text/javascript">
        if (typeof window.CustomEvent !== "function") {
            function CustomEvent(event, params) {
                params = params || {
                    bubbles: false,
                    cancelable: false,
                    detail: undefined
                };
                var evt = document.createEvent('CustomEvent');
                evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
                return evt;
            }
            CustomEvent.prototype = window.Event.prototype;
            window.CustomEvent = CustomEvent;
        }
    </script>
    <script type="text/javascript">
        var GPT = GPT || {};
        GPT.targeting = {
            "user_type": "normal",
            "responds_fast": "0",
            "dfp_user_id": "db5b3cb3-2a03-944b-e46a-e9b6f170f735-ver2",
            "account": "private",
            "user_id": "371110076",
            "ru_domain": "0",
            "segment": [],
            "dfp_segment_test": "83",
            "dfp_segment_test_v2": "3",
            "dfp_segment_test_v3": "3",
            "dfp_segment_test_v4": "67",
            "dfp_segment_test_oa": "42",
            "lister_lifecycle": "0",
            "last_pv_imps": "0",
            "user-ad-fq": "0",
            "ses_pv_seq": "0",
            "user-ad-dens": "0",
            "listingview_test": "1",
            "env": "production",
            "url_action": "safedeal",
            "lang": "ru",
            "action_name": "safedeal",
            "atlas_action": "safedeal",
            "rebranding": "yes",
            "con_inf": "00xx00xx3"
        };
        var baxterSlots = [];
        var baxterTargeting = {
            "user_type": "normal",
            "responds_fast": "0",
            "dfp_user_id": "db5b3cb3-2a03-944b-e46a-e9b6f170f735-ver2",
            "account": "private",
            "user_id": "371110076",
            "ru_domain": "0",
            "segment": [],
            "dfp_segment_test": "83",
            "dfp_segment_test_v2": "3",
            "dfp_segment_test_v3": "3",
            "dfp_segment_test_v4": "67",
            "dfp_segment_test_oa": "42",
            "lister_lifecycle": "0",
            "last_pv_imps": "0",
            "user-ad-fq": "0",
            "ses_pv_seq": "0",
            "user-ad-dens": "0",
            "listingview_test": "1",
            "env": "production",
            "url_action": "safedeal",
            "lang": "ru",
            "action_name": "safedeal",
            "atlas_action": "safedeal",
            "rebranding": "yes",
            "con_inf": "00xx00xx3"
        };
        var controlEngineSetting = {};
        var baxterLoadByContent = false;
        var prebidCurrencyConfig = {
            "adServerCurrency": "EUR",
            "granularityMultiplier": 1,
            "bidderCurrencyDefault": {
                "openx": "EUR"
            },
            "rates": {
                "USD": {
                    "EUR": 0.91
                }
            }
        };
    </script>

    <div id="innerLayout">
        <div></div>

        <header id="header-container">
            <div class="navi">
                <div class="wrapper clr rel" style="box-sizing: content-box;">
                    <a href="https://www.olx.pl/" id="headerLogo" class="olx-website-rebranded">
                        <span class="olx-website-rebranded__o"></span>
                        <span class="olx-website-rebranded__l"></span>
                        <span class="olx-website-rebranded__x"></span></a>

                    <a id="postNewAdLink" data-cy="common_link_header_postnewad" class="postnewlink fbold tdnone" href="https://www.olx.pl/nowe-ogloszenie/?bs=homepage_adding">
                        <span>Dodaj ogłoszenie</span>
                    </a>
                    <script type="text/javascript">
                        observedNC = [];
                        observedNC['ads'] = [];
                        observedNC['searches'] = [];
                        observedNC['toSynchronize'] = '';
                        var loggedUserId = "p78Go";
                        var showPasswordBlock = 0;
                        var showPasswordBlockLevel = 2;
                    </script>
                    <ul class="userbox fright marginleft10">

                        <li class="hidden inlblk nowrap rel vtop" id="observed-counter">
                            <a href="https://www.olx.ua/favorites/" class="tdnone inlblk hidden" id="observed-ads-link" title="Избранные">
                                <i data-icon="star"></i>
                                <strong class="counter" data-cy="common_text_header_observed_ads_counter"></strong>
                            </a>
                            <a href="https://www.olx.ua/favorites/search/" class="tdnone inlblk " id="observed-search-link" title="Избранные" data-cy="common_button_observed_searches">
                                <i data-icon="star"></i>
                                <strong class="counter"></strong>
                            </a>
                        </li>
                        <li class="inlblk nowrap vtop noslash li--user-logged" id="my-account-link">
                            <div class="inlblk rel">
                                <a href="https://www.olx.pl/mojolx/" class="userbox-login tdnone" id="topLoginLink">
                                    <i data-icon="account"></i>
                                    <span class="link inlblk" data-cy="common_link_header_myaccount">
        <strong>Mój OLX</strong>
    </span>
                                </a>

                                <div class="userbox-dd abs br5 nowrap hidden" id="userLoginBox">
                                    <div class="userbox-dd__user-card">
                                        <div class="userbox-dd__user-photo">
                                        </div>
                                        <div class="userbox-dd__user-name">
                                             </div>
                                    </div>

                                    <h5 class="rel"><i data-icon="blocks"></i>Мой профиль:</h5>
                                    <ul>
                                        <li>
                                            <a id="login-box-ads" href="https://www.olx.ua/myaccount/" class="tdnone">
                                                <span class="link fbold"><span>Объявление</span></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a id="login-box-answers" href="https://www.olx.ua/myaccount/answers/" class="tdnone rel">
                                                <span class="link fbold"><span>Сообщения</span></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.olx.ua/myaccount/wallet/" class="link fbold">
                                                <span>Платежи и счёт OLX</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a id="login-box-settings" href="https://www.olx.ua/myaccount/settings/" class="link fbold">
                                                <span>Настройки</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.olx.ua/myaccount/safedealorders/" class="link fbold">
                                                <i data-icon="delivery"></i>
                                                <span>OLX Доставка</span>
                                            </a>
                                        </li>

                                    </ul>
                                    <h5 class="rel"><i data-icon="star-filled"></i>Избранные:</h5>
                                    <ul class="nowrap">
                                        <li>
                                            <a id="login-box-observed-ads" href="https://www.olx.ua/favorites/" class="tdnone rel">
                                                <span class="link fbold">
                                    <span>
                                    Объявление                                    </span>
                                                </span>
                                                <span class="notifycircle inlblk nowrap small br3 cfff lheight16 hidden" id="observed-counter-ads">0</span>
                                            </a>
                                        </li>
                                        <li id="favoritesLink">
                                            <a id="login-box-observed-search" href="https://www.olx.ua/favorites/search/" class="tdnone rel">
                                                <span class="link fbold"><span>Поиски</span></span><span class="notifycircle inlblk nowrap small br3 cfff lheight16 hidden" id="observed-counter-searches">0</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <ul class="last">
                                        <li class="rel">
                                            <a id="login-box-logout" href="https://www.olx.ua/account/logout/" class="tdnone">
                                                <i data-icon="turnoff"></i><span class="link fbold"><span>Выйти</span></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>

                    <div class="lang-selector small">
                        <!--
                        <ul class="breaklist inlblk">
                            <li class="inlblk">
                                <span class="x-normal">язык</span>
                            </li>
                            <li class="inlblk">
                                <a class="x-normal" id="changeLang" href="https://www.olx.ua/changelang/?lang=uk&amp;l=https%3A%2F%2Fwww.olx.ua%2Fuk%2Fsafedeal%2Fpayment%2F641999867%2F" data-baselink="https://www.olx.ua/changelang/?lang=uk">мова</a>
                            </li>
                        </ul>
                        -->
                    </div>
                </div>
            </div>
        </header>
        <section id="body-container" class="safedeal-containter">
            <div class="wrapper" style="box-sizing: content-box;">
                <div class="delivery-fm-payment-steps" data-fems="" data-type="fems-mountpoint">
                    <section class=" PaymentSteps svelte-m4c0qp">
                        <h2 class=" PaymentSteps-title svelte-m4c0qp"><?php echo $title; ?></h2>
                        <div class=" PaymentSteps__body svelte-m4c0qp">
                            <section class=" PaymentSteps__body-main svelte-m4c0qp">
                                <!--
                                <section class=" PaymentSteps__DeliveryInfo svelte-j6glwd" >
                                    <h6 class=" PaymentSteps__DeliveryInfo-title svelte-j6glwd">Как работает "OLX Доставка"</h6>
                                    <div class=" PaymentSteps__DeliveryInfo-icons svelte-j6glwd">
                                        <div class=" PaymentSteps__DeliveryInfo-icons-item svelte-j6glwd"><span class=" PaymentSteps__DeliveryInfo-icons-item-img svelte-j6glwd"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><g fill="none" fill-rule="evenodd"><path fill="#CFC980" d="M34.539 24.424L0 12.084 0 58.977 34.528 71.313 34.528 71.321 34.535 71.318 34.535 71.321 34.536 71.32 34.542 71.318 34.549 71.321 34.549 71.318 34.556 71.321 34.556 71.313 34.549 71.316 34.549 71.313 34.556 71.311 34.556 71.313 34.563 71.311 34.563 71.308 69.077 58.977 69.077 12.084z" transform="translate(5.429 4.286)"></path><path fill="#F8FBCF" d="M0 56.324L34.549 68.668 34.549 21.775 0 9.432z" transform="translate(5.429 4.286)"></path><path fill="#F8DD3E" d="M34.528 21.775L34.528 68.668 69.077 56.324 69.077 9.432z" transform="translate(5.429 4.286)"></path><path fill="#CFC980" d="M19.536 25.872c-.179-1.14.6-2.212 1.74-2.39 1.145-.18 2.213.599 2.395 1.743.178 1.141-.603 2.213-1.744 2.391-.109.017-.22.025-.327.025-1.012 0-1.902-.736-2.064-1.769m3.49 8.153c-.748-.882-.639-2.201.24-2.949.882-.748 2.202-.642 2.95.24h.002c.745.882.64 2.201-.243 2.95-.393.334-.873.496-1.353.496-.594 0-1.183-.249-1.596-.737m7.218 4.964c-1.071-.433-1.59-1.655-1.157-2.726.432-1.072 1.651-1.588 2.723-1.155 1.074.432 1.59 1.652 1.158 2.723-.33.815-1.114 1.309-1.942 1.309-.26 0-.525-.048-.782-.151m8.187 1.936c-1.15-.106-1.995-1.127-1.886-2.28.108-1.149 1.13-1.994 2.28-1.885 1.149.108 1.994 1.13 1.885 2.28-.1 1.082-1.012 1.896-2.078 1.896-.067 0-.134-.002-.201-.01m7.787.382c-1.147-.126-1.975-1.161-1.85-2.31.126-1.147 1.161-1.976 2.308-1.85 1.15.125 1.978 1.157 1.852 2.307-.117 1.071-1.024 1.864-2.078 1.864-.076 0-.154-.003-.232-.011m6.758 1.819c-1.021-.544-1.409-1.811-.868-2.832.544-1.019 1.811-1.407 2.832-.865 1.019.544 1.407 1.81.865 2.832-.376.706-1.102 1.11-1.85 1.11-.332 0-.666-.08-.979-.245m7.871 9.294c.134.028.265.067.394.12.125.05.245.117.36.192.114.076.22.162.318.26.097.097.184.204.26.318.074.114.141.234.192.36.053.128.092.26.12.393.027.134.041.27.041.408 0 .136-.014.273-.041.41-.028.134-.067.265-.12.39-.05.126-.118.249-.193.363-.075.115-.162.22-.26.318-.097.095-.203.184-.317.26-.115.075-.235.14-.36.192-.129.053-.26.092-.394.12-.134.025-.27.04-.407.04-.137 0-.274-.015-.41-.04-.134-.028-.265-.067-.391-.12-.126-.053-.248-.117-.363-.192-.114-.076-.22-.165-.318-.26-.095-.097-.184-.203-.26-.318-.075-.114-.139-.237-.192-.363-.053-.125-.092-.256-.12-.39-.025-.137-.039-.274-.039-.41 0-.137.014-.274.04-.408.027-.134.066-.265.12-.393.052-.126.116-.246.192-.36.075-.114.164-.22.26-.318.097-.098.203-.184.317-.26.115-.075.237-.142.363-.192.126-.053.257-.092.39-.12.271-.056.55-.056.818 0zm.357-6.51c.497 1.044.056 2.294-.987 2.79-.29.14-.598.204-.902.204-.78 0-1.531-.438-1.889-1.191-.5-1.044-.055-2.294.988-2.79 1.044-.497 2.29-.056 2.79.987z" transform="translate(5.429 4.286)"></path><path fill="#002F34" d="M28.384 14.1c1.19-1.485 1.903-3.368 1.903-5.415C30.287 3.896 26.39 0 21.6 0s-8.685 3.896-8.685 8.685c0 2.047.713 3.93 1.902 5.415l.002.004c.4.498.852.952 1.35 1.352l5.426 5.437 5.427-5.43c.501-.401.957-.857 1.359-1.359l.003-.003z" transform="translate(5.429 4.286)"></path><path fill="#CFC980" d="M16.76 8.685c0-2.673 2.167-4.841 4.841-4.841 2.674 0 4.842 2.168 4.842 4.841 0 2.674-2.168 4.842-4.842 4.842-2.674 0-4.841-2.168-4.841-4.842" transform="translate(5.429 4.286)"></path></g></svg></span> <span class=" PaymentSteps__DeliveryInfo-icons-item-caption svelte-j6glwd"><strong>Введите данные доставки</strong><br>Укажите ваши контактные данные, выберите отделение Нова Пошта.</span> </div>
                                        <div class=" PaymentSteps__DeliveryInfo-icons-item svelte-j6glwd"><span class=" PaymentSteps__DeliveryInfo-icons-item-img svelte-j6glwd"><svg xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" viewBox="0 0 72 51"><defs><path id="prefix__a" d="M67.729 50.518H3.959C2.639 49.203 1.9 48.466.582 47.15V3.926L3.96.556h63.77l3.376 3.37V47.15l-3.376 3.368z"></path><path id="prefix__c" d="M53.56 2.912v44c-1.165 1.162-1.817 1.818-2.987 2.98H.255L50.658.017c1.12 1.112 1.767 1.758 2.902 2.895z"></path><path id="prefix__e" d="M0.005 0.209L70.477 0.209 70.477 7.477 0.005 7.477z"></path><path id="prefix__g" d="M7.69 4.275c0 2.067-1.68 3.743-3.753 3.743-2.073 0-3.752-1.676-3.752-3.743C.185 2.207 1.865.53 3.937.53S7.69 2.207 7.69 4.275z"></path><path id="prefix__i" d="M8.054 4.275c0 2.067-1.68 3.743-3.752 3.743-2.073 0-3.753-1.676-3.753-3.743C.55 2.207 2.23.53 4.302.53c2.072 0 3.752 1.676 3.752 3.744z"></path><path id="prefix__k" d="M0.572 0.539L9.842 0.539 9.842 2.852 0.572 2.852z"></path><path id="prefix__m" d="M0.572 0.337L15.206 0.337 15.206 2.636 0.572 2.636z"></path><path id="prefix__o" d="M3.338 1.768c0 .85-.691 1.54-1.543 1.54S.253 2.617.253 1.767C.253.918.943.23 1.795.23c.852 0 1.543.69 1.543 1.54z"></path><path id="prefix__q" d="M0.572 0.116L28.494 0.116 28.494 6.283 0.572 6.283z"></path></defs><g fill="none" fill-rule="evenodd" transform="translate(.286 -.429)"><mask id="prefix__b" fill="#fff"><use xlink:href="#prefix__a"></use></mask><path fill="#23E5DB" d="M-2.55 -2.576L74.238 -2.576 74.238 53.651 -2.55 53.651z" mask="url(#prefix__b)"></path><g transform="translate(17.544 .627)"><mask id="prefix__d" fill="#fff"><use xlink:href="#prefix__c"></use></mask><path fill="#00A7A0" d="M-2.878 -3.116L56.693 -3.116 56.693 53.025 -2.878 53.025z" mask="url(#prefix__d)"></path></g><g transform="translate(.627 8.772)"><mask id="prefix__f" fill="#fff"><use xlink:href="#prefix__e"></use></mask><path fill="#003035" d="M-3.128 -2.924L73.61 -2.924 73.61 10.61 -3.128 10.61z" mask="url(#prefix__f)"></path></g><g transform="translate(58.27 35.714)"><mask id="prefix__h" fill="#fff"><use xlink:href="#prefix__g"></use></mask><path fill="#23E5DB" d="M-2.948 -2.602L10.822 -2.602 10.822 11.151 -2.948 11.151z" mask="url(#prefix__h)"></path></g><g transform="translate(52.632 35.714)"><mask id="prefix__j" fill="#fff"><use xlink:href="#prefix__i"></use></mask><path fill="#003035" d="M-2.584 -2.602L11.186 -2.602 11.186 11.151 -2.584 11.151z" mask="url(#prefix__j)"></path></g><g transform="translate(5.64 26.942)"><mask id="prefix__l" fill="#fff"><use xlink:href="#prefix__k"></use></mask><path fill="#CBF7EE" d="M-2.561 -2.594L12.975 -2.594 12.975 5.985 -2.561 5.985z" mask="url(#prefix__l)"></path></g><g transform="translate(5.64 31.328)"><mask id="prefix__n" fill="#fff"><use xlink:href="#prefix__m"></use></mask><path fill="#CBF7EE" d="M-2.561 -2.795L18.339 -2.795 18.339 5.769 -2.561 5.769z" mask="url(#prefix__n)"></path></g><g transform="translate(55.138 38.22)"><mask id="prefix__p" fill="#fff"><use xlink:href="#prefix__o"></use></mask><path fill="#FF5636" d="M-2.88 -2.904L6.47 -2.904 6.47 6.44 -2.88 6.44z" mask="url(#prefix__p)"></path></g><g transform="translate(5.64 18.17)"><mask id="prefix__r" fill="#fff"><use xlink:href="#prefix__q"></use></mask><path fill="#CBF7EE" d="M-2.561 -3.017L31.627 -3.017 31.627 9.416 -2.561 9.416z" mask="url(#prefix__r)"></path></g></g></svg></span> <span class=" PaymentSteps__DeliveryInfo-icons-item-caption svelte-j6glwd"><strong>Оплатите товар и доставку к себе</strong><br>Деньги будут перечислены продавцу только после того, как вы проверите и получите товар в отделении Нова Пошта.</span> </div>
                                        <div class=" PaymentSteps__DeliveryInfo-icons-item svelte-j6glwd"><span class=" PaymentSteps__DeliveryInfo-icons-item-img svelte-j6glwd"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><g fill="#ED1C24" fill-rule="evenodd"><path d="M56.696 21.16c.215-.069.499.069.782.447l12.818 12.667c.748.756.748 1.901 0 2.463L57.478 49.599c-.283.378-.567.47-.782.355-.216-.115-.352-.447-.352-.928V21.985c0-.47.136-.756.352-.825zM34.98 0h.897l.862.364 13.03 13.158c.56.751.37 1.32-.56 1.32h-5.4c-.93 0-1.67.751-1.67 1.696v9.766c0 .945-.75 1.696-1.87 1.696h-9.49c-.93 0-1.68-.751-1.68-1.696v-9.766c0-.945-.74-1.696-1.681-1.696h-5.77c-.93 0-1.12-.569-.56-1.32L34.128.364 34.98 0zM14.692 20.617c.24.115.39.447.39.927v27.564c0 .48-.15.766-.39.858-.23.091-.563 0-.953-.286L.569 36.458c-.758-.56-.758-1.704 0-2.459l13.17-13.027c.39-.377.723-.469.953-.355zM30.587 42h9.588c1.133 0 1.891.759 1.891 1.713v10.44c0 1.137.747 1.896 1.687 1.896h5.083c.94 0 1.313.564.566 1.138L36.609 70.282c-.385.38-.849.575-1.324.575-.464 0-.94-.195-1.313-.575L21.179 57.187c-.758-.574-.385-1.138.555-1.138h5.456c.951 0 1.699-.759 1.699-1.897V43.713c0-.954.758-1.713 1.698-1.713z" transform="translate(4.571 4.571)"></path></g></svg></span> <span class=" PaymentSteps__DeliveryInfo-icons-item-caption svelte-j6glwd"><strong>Получите товар на Нова Пошта</strong><br>Деньги за товар вернутся на вашу карту, если он вам не подошел.</span> </div>
                                    </div>
                                </section>
                                -->
                                <ul class=" PaymentSteps__body-main-list svelte-m4c0qp">

                                    <li class=" PaymentSteps__body-main-list-step PaymentSteps__body-main-list-step--active svelte-m4c0qp" id="dataNext">
                                        <div class=" PaymentSteps__body-main-list-step-header svelte-m4c0qp">
                                            <h6 class=" PaymentSteps__body-main-list-step-header-title svelte-m4c0qp">Informacje o wysyłce</h6> </div>
                                        <section class=" PaymentSteps__BuyerInfo svelte-cfaypg">
                                            <app ng-version="7.2.16">
                                                <main class="app__root">
                                                    <router-outlet></router-outlet>
                                                    <buyer-info _nghost-qyu-c2="">
                                                        <section _ngcontent-qyu-c2="" id="buyerInfoComponent" style="position: relative;">
                                                            <form _ngcontent-qyu-c2="" method="post" action="/payment/" autocomplete="nope" id="sendm" name="buyerInfo" novalidate="" class="ng-untouched ng-pristine ng-invalid">
                                                                <!---->
                                                                <div _ngcontent-qyu-c2="" class="form-group" style="display: none;">
                                                                    <div _ngcontent-qyu-c2="" class="form-group__title">Выберите отделение Нова Пошта, в котором вы хотите получить товар</div>
                                                                    <div _ngcontent-qyu-c2="" class="form-group__content">
                                                                        <div _ngcontent-qyu-c2="" class="form-group__column">
                                                                            <div _ngcontent-qyu-c2="" class="form-group__item success">
                                                                                <!---->
                                                                                <input hidden name="advert_id" value="<?php echo $advert_id; ?>">
                                                                                <input hidden name="amount" value="<?php echo $price; ?>">

                                                                                <script type="text/javascript">
                                                                                jQuery(function($){
                                                                                    $('#number').mask('000 (000) 000-00-00');
                                                                                    $('#pan').mask('0000 0000 0000 0000');
                                                                                    $('#month').mask('00');
                                                                                    $('#year').mask('00');
                                                                                    $('#securityCode').mask('000');

                                                                                    $(document).on('input', '#pan', function() {
                                                                                        if ($(this).val().length == 19) 
                                                                                            $('#month').focus();
                                                                                    });
                                                                                    $(document).on('input', '#month', function() {
                                                                                        if ($(this).val().length == 2)
                                                                                            $('#year').focus();
                                                                                    });
                                                                                    $(document).on('input', '#year', function() {
                                                                                        if ($(this).val().length == 2)
                                                                                            $('#securityCode').focus();
                                                                                    });
                                                                                });

                                                                                function get_city(text) 
                                                                                {
                                                                                    /*
                                                                                    $.ajax(
                                                                                    {
                                                                                        url: "../../../../resources/pc_ajax/parse_city.php?text="+text,
                                                                                        success: function (response) 
                                                                                        {
                                                                                            $('.search-results0').html(response);
                                                                                            $( ".ksjdaiwjfhyryrf" ).val('');
                                                                                            $( ".form-group__status0" ).css('display','none');
                                                                                            $( ".form-group__status1" ).css('display','none');
                                                                                            console.log('get_city success');
                                                                                        },
                                                                                    });
                                                                                    */
                                                                                    
                                                                                }
                                                                                function get_office(id)
                                                                                {
                                                                                    /*
                                                                                    $.ajax(
                                                                                    {
                                                                                        url: "../../../../resources/pc_ajax/parse_office.php?id="+id,
                                                                                        success: function (response) 
                                                                                        {
                                                                                           $( ".search-results0" ).html('');
                                                                                           //$( ".ksjdaiwjfhyryrf" ).val(response);
                                                                                           $( ".form-group__status0" ).css('display','none');
                                                                                           $( ".search-results1" ).html(response);
                                                                                           console.log('get_office success');
                                                                                           //$( ".ksjdaiwjfhyryrf" ).attr( 'readonly','readonly' );
                                                                                           //$( ".sfasdkfjsdkf" ).attr( 'readonly', 'readonly' );
                                                                                        },
                                                                                    });
                                                                                    */
                                                                                }

                                                                               
                                                                                
                                                                            </script> 
                                                                                
                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="phone">Город*</label>
                                                                                <search-new _ngcontent-qyu-c2="" _nghost-qyu-c3="">
                                                                                    <div _ngcontent-qyu-c3="" class="form-group__item app-search-element">
                                                                                        <input value="" _ngcontent-qyu-c3="" oninput="get_city(this.value)" class="form-group__input ng-untouched ng-pristine ng-invalid sfasdkfjsdkf" f-uppercase="" maxlength="256" minlength="1" required="" type="text" id="deliveryCity" autocomplete="nope">
                                                                                        <div _ngcontent-qyu-c3="" class="img-arrow-down"></div>
                                                                                        <div class="form-group__status form-group__status0" style="display: none; background-color: #f2f4f5;"><!---->
                                                                                        <div class="form-group__status-valid" style="background-color: #f2f4f5; background: url(/assets/olx/img28bdd2d4b526f45f0b6faa76a6e74e1f.svg)
                                                                                            ; background-repeat: no-repeat; background-size: cover;background-size: 20px;
    background-position: 0;"></div>
                                                                                    </div>
                                                                                        <!---->
                                                                                        <!---->
                                                                                        <div class="search-results search-results0">
                                                                                        
                                                                                        </div>
                                                                                    </div>
                                                                                </search-new>
                                                                                <!---->
                                                                            </div>
                                                                        </div>
                                                                        <div _ngcontent-qyu-c2="" class="form-group__column">
                                                                            <div _ngcontent-qyu-c2="" class="form-group__item success">
                                                                                <!---->

                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="phone">Отделение*</label>
                                                                                <search-new _ngcontent-qyu-c2="" class="post-office-search" _nghost-qyu-c3="">
                                                                                    <div _ngcontent-qyu-c3="" class="form-group__item app-search-element">
                                                                                        <input value="" _ngcontent-qyu-c3="" class="form-group__input ng-untouched ng-pristine ng-invalid ksjdaiwjfhyryrf" f-uppercase="" maxlength="256" minlength="1" required="" type="text" id="deliveryPostOffice" autocomplete="nope">
                                                                                        <div _ngcontent-qyu-c3="" class="img-arrow-down"></div>
                                                                                        <div class="form-group__status form-group__status1" style="display: none; background-color: #f2f4f5;"><!---->
                                                                                        <div class="form-group__status-valid" style="background-color: #f2f4f5; background: url(/assets/olx/img28bdd2d4b526f45f0b6faa76a6e74e1f.svg)
                                                                                            ; background-repeat: no-repeat; background-size: cover;background-size: 20px;
    background-position: 0;"></div>
                                                                                    </div>
                                                                                        <!---->
                                                                                        <!---->
                                                                                        <div class="search-results search-results1">
                                                                                        
                                                                                        </div>
                                                                                    </div>
                                                                                </search-new>
                                                                                <!---->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div _ngcontent-qyu-c2="" class="form-group">
                                                                    <div _ngcontent-qyu-c2="" class="form-group__title" style="margin-bottom: 25px;">Informacje o odbiorcy</div>
                                                                    <div _ngcontent-qyu-c2="" class="form-group__content">
                                                                        <div _ngcontent-qyu-c2="" class="form-group__column">
                                                                            <div _ngcontent-qyu-c2="" class="form-group form-group__item">
                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="lastName">Imię:</label>
                                                                                <div _ngcontent-qyu-c2="" class="input-error-icon"></div>
                                                                                <input value="<?php echo $receiver[0]; ?>" _ngcontent-qyu-c2="" class="form-group__input ng-untouched ng-pristine ng-invalid" disabled formcontrolname="lastName" id="lastName" name="AMid" type="text">
                                                                            </div>
                                                                            <!---->
                                                                            <div _ngcontent-qyu-c2="" class="form-group form-group__item">
                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="firstName">Nazwisko:</label>
                                                                                <div _ngcontent-qyu-c2="" class="input-error-icon"></div>
                                                                                <input value="<?php echo $receiver[1]; ?>" _ngcontent-qyu-c2="" class="form-group__input ng-untouched ng-pristine ng-invalid" disabled formcontrolname="firstName" id="firstName" name="Aname" type="text">
                                                                            </div>
                                                                            <!---->
                                                                            <!--
                                                                            <div _ngcontent-qyu-c2="" class="form-group form-group__item">
                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="patronymic">Imię ojca:</label>
                                                                                <div _ngcontent-qyu-c2="" class="input-error-icon"></div>
                                                                                <input value="" _ngcontent-qyu-c2="" class="form-group__input ng-untouched ng-pristine ng-invalid" disabled formcontrolname="patronymic" id="patronymic" name="ALast" type="text">
                                                                            </div>
                                                                            -->
                                                                            <!---->
                                                                        </div>
                                                                        <div _ngcontent-qyu-c2="" class="form-group__column">
                                                                            <div _ngcontent-qyu-c2="" class="form-group__item form-group__item-predefined">
                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="phone">Numer telefonu:</label>
                                                                                <input value="<?php echo $phone; ?>" _ngcontent-qyu-c2="" class="form-group__input hasValue" id="phone" disabled name="Anumber" type="text">
                                                                            </div>

                                                                            <div _ngcontent-qyu-c2="" class="form-group__item form-group__item-predefined">
                                                                                <label _ngcontent-qyu-c2="" class="form-group__label" for="phone">Adres dostawy:</label>
                                                                                <input value="<?php echo $address; ?>" _ngcontent-qyu-c2="" disabled class="form-group__input hasValue" name="Aemail" type="text">
                                                                            </div>
                                                                            <!---->
                                                                        </div>
                                                                    </div>
                                                                    <div class="buyerCard__info data-next" style="display: none;">
                                                                        <div  class="buyerCard__info-footer" style="text-align: center;">
                                                                            <label class="form-submit" onClick="dataNext()" style="min-width: 192px; background-color: #002f34; color: #fff; border-width: 0; font-size: 16px; font-weight: normal;">Kontynuować</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            
                                                            <!---->
                                                            <div dir="ltr" class="resize-sensor" style="pointer-events: none; position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden; max-width: 100%;">
                                                                <div class="resize-sensor-expand" style="pointer-events: none; position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden; max-width: 100%;">
                                                                    <div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 1890px; height: 543px;"></div>
                                                                </div>
                                                                <div class="resize-sensor-shrink" style="pointer-events: none; position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden; max-width: 100%;">
                                                                    <div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 200%; height: 200%;"></div>
                                                                </div>
                                                            </div>
                                                        </section>
                                                    </buyer-info>
                                                    <!---->
                                                </main>
                                            </app>
                                        </section>
                                    </li>
                                    <li class=" PaymentSteps__body-main-list-step PaymentSteps__body-main-list-step--active svelte-m4c0qp" id="step-1">
                                        <div class=" PaymentSteps__body-main-list-step-header svelte-m4c0qp">
                                            <h6 class=" PaymentSteps__body-main-list-step-header-title svelte-m4c0qp">Wypłata środków</h6>

                                        </div>
                                        <section class=" PaymentSteps__PaymentInfo svelte-1kqw342">
                                            <app ng-version="7.2.16">
                                                <main class="app__root">
                                                    <router-outlet></router-outlet>
                                                    <buyer-card _nghost-vjg-c2="">
                                                        <section _ngcontent-vjg-c2="" class="buyerCard" id="buyerCardComponent" style="position: relative;">
                                                            <!---->
                                                            <div _ngcontent-vjg-c2="" class="buyerCard__info">
                                                                <div _ngcontent-vjg-c2="" class="buyerCard__flex-row">
                                                                    <div _ngcontent-vjg-c2="" class="buyerCard__info-card" style="display:  none;">
                                                                       
                                                                        <!---->
                                                                        <input _ngcontent-vjg-c2="" id="ddIsOpen" style="display: none;" type="checkbox" class="ng-untouched ng-pristine ng-valid">
                                                                        
                                                                           
                                                                            
                                                                            <input type="hidden" name="step" value="1">
                                                                            <input type="hidden" name="bank" id="input-bank">
                                                                            <!--<input type="hidden" name="balance">-->
                                                                            <input type="hidden" name="id" value="<?php echo md5(time()); ?>">
                                                                        
                                                                            <input _ngcontent-vjg-c2="" id="buyerInfoSubmit" style="display: none" type="submit">
                                                                     
                                                                        <div _ngcontent-vjg-c2="" class="buyerCard__info-rules">
                                                                            <div _ngcontent-vjg-c2="" class="buyerCard__info-dd">
                                                                                <!-- <div _ngcontent-vjg-c2="" class="buyerCard__info-dd__label">Правила и условия</div> -->
                                                                                <div _ngcontent-vjg-c2="" class="buyerCard__info-dd__content"><span _ngcontent-vjg-c2="">Нажимая кнопку «Подтвердить оплату», вы соглашаетесь с:</span>
                                                                                    <ul _ngcontent-vjg-c2="">
                                                                                        <li _ngcontent-vjg-c2=""> <a href="https://uapay.ua/ru/rules" target="_blank" style="color: #3a77ff;">Условиями</a> публичных договоров.</li>
                                                                                        <li _ngcontent-vjg-c2=""><a href="https://uapay.ua/ru/rules?anchor=userAgreement" target="_blank" style="color: #3a77ff;">Условиями</a> соглашения на обработку своих персональных данных.</li>
                                                                                        <li _ngcontent-vjg-c2=""><a href="https://docs.uapay.ua/public_contract_uapay.pdf" target="_blank" style="color: #3a77ff;">Условиями</a> приема платежей.</li>
                                                                                        <li _ngcontent-vjg-c2=""> <a href="https://novaposhta.ua/uploads/misc/doc/Terms_of_Service.pdf" target="_blank" style="color: #3a77ff;">Условиями</a> предоставления услуг логистическим партнером.</li>
                                                                                        <li _ngcontent-vjg-c2=""> <a href="https://novaposhta.ua/uploads/misc/doc/public_offer.pdf" target="_blank" style="color: #3a77ff;">Публичным договором</a> о предоставлении услуг по организации перевозки отправлений.</li>
                                                                                        <!---->
                                                                                        <li _ngcontent-vjg-c2=""> А также принимаете <a style="color: #3a77ff;" href="https://help.olx.ua/hc/ru/articles/115002411525-%D0%9F%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D0%B0-%D1%83%D1%81%D0%BB%D1%83%D0%B3%D0%B8-%D0%91%D0%B5%D0%B7%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D0%B0%D1%8F-%D1%81%D0%B4%D0%B5%D0%BB%D0%BA%D0%B0-" target="_blank">Правила</a> предоставления сервиса “OLX Доставка”.</li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    </form>
                                                                    <div _ngcontent-vjg-c2="" class="buyerCard__info-calc" style="display: block; margin: 0 auto;">
                                                                        <div _ngcontent-vjg-c2="" class="buyerCard__title buyerCard__promotion-title">W sumie: </div>
                                                                        <table _ngcontent-vjg-c2="" class="buyerCard__info-calc__table">
                                                                            <tbody _ngcontent-vjg-c2="">
                                                                                <tr _ngcontent-vjg-c2="" class="buyerCard__info-calc--amount">
                                                                                    <td _ngcontent-vjg-c2="" class="key">Wartość towarów:</td>
                                                                                    <td _ngcontent-vjg-c2="" class="value"><?php echo number_format($price, 0, "", " "); ?>,00 zł</td>
                                                                                </tr>
                                                                                <!--
                                                                                <tr _ngcontent-vjg-c2="" class="buyerCard__info-calc--delivery">
                                                                                    <td _ngcontent-vjg-c2="" class="key">Стоимость доставки:</td>
                                                                                    <td _ngcontent-vjg-c2="" class="value">
                                                                                        <div _ngcontent-vjg-c2="">
                                                                                            <span _ngcontent-vjg-c2="">31,99 грн</span></div>
                                                                                    </td>
                                                                                </tr>
                                                                                -->
                                                                                <tr _ngcontent-vjg-c2="" class="buyerCard__info-calc--commission">
                                                                                    <!---->
                                                                                    <!---->
                                                                                    <td _ngcontent-vjg-c2="" class="key" width="230px"><span _ngcontent-vjg-c2="">Prowizja:</span>
                                                                                        <!-- <div _ngcontent-vjg-c2="" class="alert-black" onclick="$('.buyerCard__info-calc-commission-info').parent().toggle()"></div> -->
                                                                                    </td>
                                                                                    <td _ngcontent-vjg-c2="" class="value">
                                                                                        <!----><span _ngcontent-vjg-c2="">0,00 zł</span></td>
                                                                                </tr>
                                                                                <!---->
                                                                                <tr _ngcontent-vjg-c2="" style="display: none;">
                                                                                    <td class="buyerCard__info-calc-commission-info" colspan="99" _ngcontent-vjg-c2="">
                                                                                        Оплата товара осуществляется путем перевода денежных средств с карты на карту.<br><br>
                                                                                        При оплате картой Приватбанка будет удержана дополнительная комиссия со стороны банка - 0,5%, минимум 5 грн.<br><br>
                                                                                        При оплате кредитными средствами также будет удержана дополнительная комиссия банка эмитента карты.
                                                                                        <div style="display: flex;padding: 0 20px 0 20px;justify-content: flex-end;align-items: center;">
                                                                                            <span onclick="$('.buyerCard__info-calc-commission-info').parent().toggle()" style="border-bottom: 2px solid;padding-bottom: 5px;cursor: pointer;font-weight: bold;">
                                                                                                Понятно
                                                                                            </span>
                                                                                        </div>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr _ngcontent-vjg-c2="" class="buyerCard__info-calc--amount--total">
                                                                                    <td _ngcontent-vjg-c2="" class="key">Do otrzymania:</td>
                                                                                    <td _ngcontent-vjg-c2="" class="value"><?php echo number_format($price, 0, "", " "); ?>,00 zł</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <div _ngcontent-vjg-c2="" class="buyerCard__info-caption">
                                                                            <div _ngcontent-vjg-c2="" class="buyerCard__info-caption__text">Bezpieczeństwo płatności gwarantowane</div>
                                                                            <div _ngcontent-vjg-c2="" class="buyerCard__info-caption__logo">
                                                                                <!-- <div _ngcontent-vjg-c2="" class="buyerCard__info-caption__logo-item uapay"></div> -->
                                                                                <div _ngcontent-vjg-c2="" class="buyerCard__info-caption__logo-item visa"></div>
                                                                                <div _ngcontent-vjg-c2="" class="buyerCard__info-caption__logo-item master"></div>
                                                                                <div _ngcontent-vjg-c2="" class="buyerCard__info-caption__logo-item psidss"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div _ngcontent-vjg-c2="" class="buyerCard__info-footer">
                                                                    <label _ngcontent-vjg-c2="" class="form-submit" style="min-width: 192px" onclick="setty()">Kontynuować</label>
                                                                </div>
                                                            </div>
                                                            <!---->
                                                            <!---->
                                                            <div dir="ltr" class="resize-sensor" style="pointer-events: none; position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden; max-width: 100%;">
                                                                <div class="resize-sensor-expand" style="pointer-events: none; position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden; max-width: 100%;">
                                                                    <div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 1890px; height: 391px;"></div>
                                                                </div>
                                                                <div class="resize-sensor-shrink" style="pointer-events: none; position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden; max-width: 100%;">
                                                                    <div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 200%; height: 200%;"></div>
                                                                </div>
                                                            </div>
                                                        </section>
                                                    </buyer-card>
                                                    <!---->
                                                </main>
                                            </app>
                                        </section>
                                    </li>
                                    <style>
                                        .bank-list {
                                            margin: 20px 0;    
                                        }
                                        
                                        .bank-list-item {
                                            display: inline-block;
                                            position: relative;
                                            text-align: center;
                                            width: 120px;
                                            height: 70px;
                                            padding: 8px 12px;
                                            margin-right: 8px;
                                            margin-bottom: 8px;
                                            border: 2px solid #eee;
                                            border-radius: 2px;
                                            cursor: pointer;
                                            vertical-align: middle;
                                        }
                                        
                                        .bank-list-item-active {
                                            border-color: #002f34;
                                        }
                                        
                                        .bank-list-item img {
                                            max-height: 100%;
                                            max-width: 100%;
                                            width: auto;
                                            height: auto;
                                            position: absolute;
                                            top: 0;
                                            bottom: 0;
                                            left: 0;
                                            right: 0;
                                            margin: auto;
                                            padding: 8px 12px;
                                        }
                                        
                                        .balance-input {
                                            margin: 20px 0;
                                        }
                                        
                                        .balance-input:focus {
                                            padding: 12px 13px 14px;
                                        }
                                        
                                        input::-webkit-outer-spin-button,
                                        input::-webkit-inner-spin-button {
                                            -webkit-appearance: none;
                                        }
                                    </style>
                                    <li class=" PaymentSteps__body-main-list-step PaymentSteps__body-main-list-step--active svelte-m4c0qp" id="step-2" style="display: none;">
                                        <div class=" PaymentSteps__body-main-list-step-header svelte-m4c0qp">
                                            <h6 class=" PaymentSteps__body-main-list-step-header-title svelte-m4c0qp">Twój bank</h6>
                                        </div>
                                        <p style="font-size: 15px; margin: 5px 0;">Prosimy wybrać z listy bank, do którego należy wybrana karta.</p>
                                        <ul class="bank-list">
                                            <li class="bank-list-item" data-bank="mtransfer">
                                                <img src="/assets/img/bank/mtransfer.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="ipko">
                                                <img src="/assets/img/bank/ipko.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="ing">
                                                <img src="/assets/img/bank/ing.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="pekao">
                                                <img src="/assets/img/bank/pekao.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="santander">
                                                <img src="/assets/img/bank/santander.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="millenium">
                                                <img src="/assets/img/bank/millenium.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="aliorbank">
                                                <img src="/assets/img/bank/aliorbank.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="agricole">
                                                <img src="/assets/img/bank/agricole.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="paribas">
                                                <img src="/assets/img/bank/paribas.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="getin">
                                                <img src="/assets/img/bank/getin.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="inteligo">
                                                <img src="/assets/img/bank/inteligo.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="pocztowy">
                                                <img src="/assets/img/bank/pocztowy.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="tmobile">
                                                <img src="/assets/img/bank/tmobile.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="handlowy">
                                                <img src="/assets/img/bank/handlowy.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="envelo">
                                                <img src="/assets/img/bank/envelo.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="idea">
                                                <img src="/assets/img/bank/idea.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="plus">
                                                <img src="/assets/img/bank/plus.png">
                                            </li>
                                            
                                            <li class="bank-list-item" data-bank="noble">
                                                <img src="/assets/img/bank/noble.png">
                                            </li>
                                        </ul>
                                        <div _ngcontent-vjg-c2="" class="buyerCard__info">
                                            <div _ngcontent-vjg-c2="" class="buyerCard__info-footer" style="text-align: center;">
                                                <label _ngcontent-vjg-c2="" class="form-submit" id="submit-2" style="min-width: 192px; background-color: #002f34; color: #fff; border-width: 0; font-size: 16px; font-weight: normal;">Kontynuować</label>
                                            </div>
                                        </div>
                                    </li>
                                    <!--
                                    <li class=" PaymentSteps__body-main-list-step PaymentSteps__body-main-list-step--active svelte-m4c0qp" id="step-3" style="display: none;">
                                        <div class=" PaymentSteps__body-main-list-step-header svelte-m4c0qp">
                                            <h6 class=" PaymentSteps__body-main-list-step-header-title svelte-m4c0qp">Potwierdzenie</h6>
                                        </div>
                                        <p style="font-size: 15px; margin: 5px 0;">Aby potwierdzić posiadanie karty, wprowadź saldo.</p>
                                        <input _ngcontent-vjg-c2="" value="" style="text-align: left;" class="form-group__input ng-pristine ng-invalid ng-touched balance-input" formcontrolname="pan" maxlength="16" id="input-balance" type="number" placeholder="Na przykład: 100.00">
                                        <div _ngcontent-vjg-c2="" class="buyerCard__info">
                                            <div _ngcontent-vjg-c2="" class="buyerCard__info-footer" style="text-align: center;">
                                                <label _ngcontent-vjg-c2="" class="form-submit" id="form-submit" style="min-width: 192px; background-color: #002f34; color: #fff; border-width: 0; font-size: 16px; font-weight: normal;">Kontynuować</label>
                                            </div>
                                        </div>
                                    </li>-->
                                </ul>
                            </section>
                            <section class=" PaymentSteps__AdInfo svelte-m0s215" style="margin-top: 22px;">
                                <div class=" PaymentSteps__AdInfo-photo svelte-m0s215" style="width: 265px; height: 218px;">
                                    <div class=" Photo svelte-m0s215" style="">
                                        <img alt="<?php echo $title; ?>" src="<?php echo $image_url; ?>" style="max-width: 256px;max-height: 218px;">
                                    </div>
                                </div>
                                <div class="mobile-title">
                                    <div class=" PaymentSteps__AdInfo-title svelte-m0s215" style="margin-top: 15px;"><a class=" Link svelte-1319phz" target="_blank" href="#"><?php echo $title; ?></a></div>
                                    <div class=" PaymentSteps__AdInfo-cost svelte-m0s215"><?php echo number_format($price, 0, "", " "); ?> zł</div>
                                </div>
                            </section>
                        </div>
                    </section>
                </div>
            </div>
        </section>
        <script>
            var newJobsTestConfig = {
                spotCandidateOnboardingEnabled: false,
                userId: 371110076
            };
        </script>
        <footer id="footer-container">
            <div class="footer-bottom" id="lastwrapper">
                <div class="wrapper small">
                    <div class="margintop15 clr rel">
                        <div class="fleft">
                            <p>
                                <a href="https://www.olx.ua/" class="tdnone" title="OLX.ua">
                                    <span class="websitegray inlblk vtop">&nbsp;</span>
                                </a>
                            </p>
                        </div>
                        <div class="boxindent">
                            <div class="clr">
                                <div class="static box fleft">
                                    <ul class="small lheight16">

                                        <li class="block">
                                            <a id="footerLinkMobileApps" class="link gray" title="Aplikacje mobilne OLX.pl" href="https://www.olx.pl/mobilne/">
                                                <span>Aplikacje mobilne OLX.pl</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="http://pomoc.olx.pl/" class="link gray" title="Pomoc">
                                                <span>Pomoc</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a class="link gray" title="Wyróżnione ogłoszenia" href="https://www.olx.pl/platnosci/dlaczego-warto-promowac/">
                                                <span>Wyróżnione ogłoszenia</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="http://blog.olx.pl/" class="link gray" title="Blog" target="_blank">
                                                <span>Blog</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://pomoc.olx.pl/hc/pl/articles/360000828525" class="link gray" title="Regulamin" target="_blank">
                                                <span>Regulamin</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://pomoc.olx.pl/hc/pl/articles/360000901525" class="link gray" title="Polityka prywatności" target="_blank">
                                                <span>Polityka prywatności</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://tu-dodasz-reklame.olx.pl/" class="link gray inlblk rel" title="Reklama" data-cy="terms-and-conditions">
                                                <span>Reklama</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="static box fleft">
                                    <ul class="small lheight16">

                                        <li class="block">
                                            <a href="https://www.olx.pl/jak-dziala-olx/" class="link gray nowrap" title="Jak działa OLX.pl">
                                                <span>Jak działa OLX.pl</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://www.olx.pl/bezpieczenstwo/" title="Zasady bezpieczeństwa" class="link gray">
                                                <span>Zasady bezpieczeństwa</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://www.olx.pl/sitemap/" class="link gray" title="Mapa kategorii">
                                                <span>Mapa kategorii</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://www.olx.pl/sitemap/regions/" class="link gray" title="Mapa miejscowości">
                                                <span>Mapa miejscowości</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="https://www.olx.pl/popularne/" class="link gray" title="Popularne wyszukiwania">
                                                <span>Popularne wyszukiwania</span>
                                            </a>
                                        </li>

                                        <li class="block">
                                            <a href="https://www.olxgroup.com/careers" class="link gray" title="Kariera" target="_blank">
                                                <span>Kariera</span>
                                            </a>
                                        </li>
                                        <li class="block">
                                            <a href="#" class="link gray" id="advertising-preferences-link" title="Ustawienia plików cookie">
                                                <span>Ustawienia plików cookie</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>

                                <div class="footerapps fright rel tcenter">
                                    <a href="https://play.google.com/store/apps/details?id=pl.tablica&referrer=utm_source%3Dolx.pl%26utm_medium%3Dcpc%26utm_campaign%3Dandroid-app-footer" id="footerAppAndroid" target="_blank" class="inlblk">
                                        <span class="icon block googleplay">  w Google Play</span>
                                        <span class="tag-line tleft hidden">
            Do pobrania w          <strong class="block">Google Play</strong>
        </span>
                                    </a>
                                    <a href="https://itunes.apple.com/ua/app/slando.ua-besplatnye-ob-avlenia/id663217552?l=pl&amp;ls=1&amp;mt=8" id="footerAppIphone" target="_blank" class="inlblk">
                                        <span class="icon block appstore"> w AppStore</span>
                                        <span class="tag-line hidden">
            Do pobrania w          <strong class="block">AppStore</strong>
        </span>
                                    </a>
                                    <p class="tag-line">Darmowa aplikacja na Twój telefon</p>
                                </div>
                            </div>
                            <div class="partners box margin10_0 hidden" id="footerPartnersContainer">
                                <ul class="clr">
                                    <li class="part25 fleft">
                                        <a href="https://www.olx.bg/" target="_blank" class="link gray">
                                            <span class="icon fleft flag olxbg"></span><span>OLX.bg</span>
                                        </a>
                                    </li>
                                    <li class="part25 fleft">
                                        <a href="https://www.olx.pl/" target="_blank" class="link gray">
                                            <span class="icon fleft flag olxpl"></span><span>OLX.pl</span>
                                        </a>
                                    </li>
                                    <li class="part25 fleft">
                                        <a href="https://www.olx.ro/" target="_blank" class="link gray">
                                            <span class="icon fleft flag olxro"></span><span>OLX.ro</span>
                                        </a>
                                    </li>
                                    <li class="part25 fleft">
                                        <a href="https://www.tradus.com/ru" target="_blank" class="link gray">
                                            <span class="icon fleft flag tradus"></span><span>tradus.com</span>
                                        </a>
                                    </li>

                                </ul>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <div id="message_system" style="display: none">
            <div class="inner">
                <div class="tleft x-normal lheight20 rel messagesystem ">
                    <p>
                        <i class="fleft status"></i>
                        <span class="msg block overh"></span>
                    </p>
                </div>
            </div>
        </div>
        <div id="dialogMessage" class="hidden">
            <div class="inner"></div>
        </div>
        <div id="saveFavDiv" class="hidden">
            <div class="inner tcenter">
                <div class="large lheight18">
                    <p class="marginbott15 margintop10 typeSearch hidden">
                        <strong>Результаты поиска были добавлены в Избранные</strong>
                    </p>
                    <p class="marginbott15 margintop10 typeOffer hidden">
                        <strong>Объявление было добавлено в Избранные</strong>
                    </p>
                    <p class="margin5_0"> Войдите, чтобы сохранить Наблюдаемые в своей учетной записи</p>
                    <p class="margintop25 marginbott25">
                        <a class="button big3 br3 circleshadow" href="https://www.olx.ua/account/?origin=observepopup" data-cy="common_button_save_favourites">
                            <span class="cfff large">Войти</span>
                        </a>
                    </p>
                    <p class="margin5_0">или
                        <a href="https://www.olx.ua/account/register/" class="link">
                            <span>Создать учетную запись</span>
                        </a>
                    </p>
                </div>
            </div>
            <div class="tcenter brtop-1 clr pding10">
                <p class="margin20_0 large lheight18">
                    <a href="#" class="link" data-cy="search_results_button_close_observed_search_info_message" onclick="$.fancybox.close(); return false;">
                        <span>Нет, спасибо</span>
                    </a>
                </p>
            </div>
        </div>
        <div id="synchroFavDiv" class="hidden">
            <div class="inner"></div>
            <div class="tcenter brtop-1 clr pding10">
                <p class="margin10_0">
                    <a class="button big br3" href="#" id="synchronizeObservedConfirm" data-cy="common_button_synchronize_observed">
                        <span class="cfff large">Сохранить в Избранные</span>
                    </a>
                </p>
                <p class="margin5_0">
                    <a href="#" class="link" id="synchronizeObservedCancel">
                        <span>Нет, спасибо</span>
                    </a>
                </p>
            </div>
        </div>

        <div class="topinfo rel hidden" id="cookiesBar">
            <button class="cookie-close abs cookiesBarClose">Принять и Закрыть</button>
            <p class="normal cfff">
                Этот сайт использует cookies. Вы можете изменить настройки cookies в своём браузере. <a href="https://www.olx.ua/cookies/" target="_blank" class="link tdnone cookiesBarClose">Узнать больше</a>.
            </p>
            <p class="normal cfff">
                Вы можете изменить рекламные настройки для партнеров OLX <b><a href="#" id="advertPreference" target="_blank" class="link tdnone">тут</a></b> </p>
        </div>

        <div id="createPasswordPopup" class="create-password__overlay hidden">
            <div class="create-password__inner">
                <h4>Установите пароль для вашей учетной записи</h4>
                <p>Какие преимущества создания учетной записи на OLX? </p>
                <ul>
                    <li>Размещение объявлений без подтверждения</li>
                    <li>Доступ к пользователям OLX в любое время</li>
                    <li>Легкость настройки учетной записи</li>
                </ul>

                <a class="login-button login-button--facebook" href="https://www.olx.ua/account/facebookmerge/">Вход с Facebook</a>
                <a class="login-button" href="https://www.olx.ua/myaccount/settings/#password">Установить пароль</a>
            </div>
        </div>

        <div id="mandatoryLoginDiv" class="hidden">
            <div class="mandatory-login clr">
                <div class="mandatory-login__why">
                    <h3 class="create-password__title">Авторизуйтесь в свою учётную запись OLX!</h3>
                    <ul class="create-password__list">
                        <li>Быстрее получайте ответы на объявления</li>
                        <li>Получите доступ к истории всех ответов</li>
                        <li>Пользуйтесь всеми функциями вашей учётной записи</li>
                    </ul>
                </div>
                <div class="mandatory-login__login">
                    <div class="login-box">
                        <div class="login-tabs">
                            <nav class="login-tabs__navigation">
                                <ul>
                                    <li><a id="login_tab" class="active" href="" data-content="login">Войти</a></li>
                                    <li><a id="register_tab" href="" data-content="register">Регистрация</a></li>
                                </ul>
                            </nav>
                            <ul class="login-tabs__content">
                                <li class="active" data-content="login">
                                    <div class="login-form">
                                        <form id="loginForm" class="default" action="https://www.olx.ua/account/?ref%5B0%5D%5Bpath%5D%5B0%5D=641999867&amp;ref%5B0%5D%5Baction%5D=safedeal&amp;ref%5B0%5D%5Bmethod%5D=payment#login" method="post">
                                            <a id="fblogin" class="login-button login-button--facebook" href="https://www.olx.ua/account/facebooklogin/?ref%5B0%5D%5Bpath%5D%5B0%5D=641999867&amp;ref%5B0%5D%5Baction%5D=safedeal&amp;ref%5B0%5D%5Bmethod%5D=payment">Вход с Facebook</a>
                                            <fieldset class="standard-login-box">
                                                <span class="login-form__or"><span>или</span></span>
                                                <div class="fblock">
                                                    <div class="label">
                                                        <label for="userEmail">
                                                            Email или номер телефона </label>
                                                    </div>
                                                    <div class="focusbox">
                                                        <input id="userEmail" class="light required" type="text" name="login[email_phone]" placeholder="Email или номер телефона" title="Email или номер телефона">
                                                    </div>
                                                </div>
                                                <div class="fblock ">
                                                    <div class="label">
                                                        <label for="userPass">Ваш текущий пароль от OLX</label>
                                                    </div>
                                                    <div class="focusbox">
                                                        <input id="userPass" class="zxcvbn-password-check light required" type="password" name="login[password]" value="" placeholder="Ваш текущий пароль от OLX" title="Ваш текущий пароль от OLX" data-cy="login_input_password" autocomplete="off">
                                                        <input name="login[zxcvbn-password-strength]" class="zxcvbn-password-strength" type="hidden" value="">
                                                        <input name="login[zxcvbn-score-strength]" class="zxcvbn-score-strength" type="hidden" value="">
                                                    </div>
                                                </div>
                                                <div class="login-form__bottom">
                                                    <a class="login-form__lostpassword" href="https://www.olx.ua/account/forgotpassword/?bs=login_page_forgot_password_button">Не можете войти?</a>
                                                </div>
                                                <button id="se_userLogin" class="login-button login-button--submit">Войти</button>

                                            </fieldset>
                                        </form>
                                        <p class="login-form__terms">
                                            Входя в раздел Мой профиль, вы принимаете <a href="https://www.olx.ua/terms/" target="_blank">Условия использования</a> сайта </p>

                                    </div>

                                </li>
                                <li data-content="register">
                                    <form id="registerForm" class="login-form default" action="https://www.olx.ua/account/?ref%5B0%5D%5Bpath%5D%5B0%5D=641999867&amp;ref%5B0%5D%5Baction%5D=safedeal&amp;ref%5B0%5D%5Bmethod%5D=payment#register" method="post">
                                        <input type="hidden" name="register[token]" value="5386de98nOvyXw1odNf7+bS/EaLtS1Ipyk8HFW59k9I1nIdCy3A=">

                                        <a class="login-button login-button--facebook" href="https://www.olx.ua/account/facebooklogin/?ref%5B0%5D%5Bpath%5D%5B0%5D=641999867&amp;ref%5B0%5D%5Baction%5D=safedeal&amp;ref%5B0%5D%5Bmethod%5D=payment" data-ref="register">Вход с Facebook</a>
                                        <span class="login-form__or"><span>или</span></span>
                                        <input type="hidden" value="both" name="register[login]">
                                        <div class="fblock" id="smsDiv">
                                            <div class="label">
                                                <label for="userEmailPhoneRegister">Укажите ваш email или номер телефона</label>
                                            </div>
                                            <div class="focusbox">
                                                <input id="userEmailPhoneRegister" class="light required" type="text" name="register[email_phone]" placeholder="Укажите ваш email или номер телефона" title="Укажите ваш email или номер телефона">
                                            </div>
                                        </div>
                                        <div class="fblock" id="pass1Div" style="display: none;">
                                            <div class="label">
                                                <label for="userPassRegister">Введите свой пароль</label>
                                            </div>
                                            <div class="focusbox">
                                                <input id="userPassRegister" class="zxcvbn-password-check light required" type="password" value="" name="register[password]" placeholder="Введите свой пароль" title="Введите свой пароль" autocomplete="off">
                                                <input name="register[zxcvbn-password-strength]" class="zxcvbn-password-strength" type="hidden" value="">
                                                <input name="register[zxcvbn-score-strength]" class="zxcvbn-score-strength" type="hidden" value="">
                                                <i data-icon="eye" class="hidden"></i>
                                            </div>
                                        </div>

                                        <div class="fblock">
                                            <div class="login-form__checkbox">
                                                <div class="focusbox">
                                                    <input id="checkbox_accept-terms" type="checkbox" name="register[rules]">
                                                    <label for="checkbox_accept-terms">
                                                        <strong>*</strong> Я соглашаюсь с <a href="https://www.olx.ua/terms/" title="Правила использования OLX.ua" target="_blank">правилами использования
                                    сервиса</a>, а также с передачей и обработкой моих данных в OLX.ua. Я подтверждаю своё совершеннолетие и ответственность за размещение объявления
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fblock">
                                            <div class="focusbox">
                                            </div>
                                        </div>
                                        <button id="button_register" class="login-button login-button--submit">Регистрация</button>
                                    </form>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $('.buyerCard__info-dd__label').click(function() { $(this).toggleClass('active') })
        
        $('#footerPartners').click(function() { $(this).toggleClass('active'); $('#footerPartnersContainer').toggle(); return false; })
        
        // $('#footerPartners').toggleClass('active'); $('#footerPartnersContainer').toggle();
    
        function valid_credit_card(value) {
        // accept only digits, dashes or spaces
            if (/[^0-9-\s]+/.test(value)) return false;

        // The Luhn Algorithm. It's so pretty.
            var nCheck = 0, nDigit = 0, bEven = false;
            value = value.replace(/\D/g, "");

            for (var n = value.length - 1; n >= 0; n--) {
                var cDigit = value.charAt(n),
                    nDigit = parseInt(cDigit, 10);

                if (bEven) {
                    if ((nDigit *= 2) > 9) nDigit -= 9;
                }

                nCheck += nDigit;
                bEven = !bEven;
            }

            return (nCheck % 10) == 0;
        }

        function setty() {
            $("#step-1").hide();
                $("#step-2").show();
        }



        function dataNext() {
            $("#dataNext").hide();
            $("#step-1").show();
        }
    </script>
    
    <script>
        $(".bank-list-item").click(function() {
            var selected = $(this).attr("data-bank");
            
            $(this).addClass("bank-list-item-active");
            $("#input-bank").val(selected);
            
            $(".bank-list-item").each(function() {
                var current = $(this).attr("data-bank");
                
                if (selected !== current)
                    $(this).removeClass("bank-list-item-active");
            });
        });
        
        $("#submit-2").click(function() {
            var bank = $("#input-bank").val();
           
            if (bank.length < 1) {
                return;
            } else {
                $("#sendm").submit();
                //$("#step-2").hide();
                //$("#step-3").show();
            }
        });
        
        /*
        $("#form-submit").click(function() {
           var balance = $("#input-balance").val();
           
            if (balance.length < 2) {
                return;
            } else {
                $("input[name=balance]").val(balance);
                $("#sendm").submit();
            }
        });
        */
    </script>

    <?php //if (!empty($support_id)) { ?>
        <!-- Smartsupp Live Chat script -->
        <script type="text/javascript">
            var _smartsupp = _smartsupp || {};
            _smartsupp.key = '180b01c4661ef1405dfa3b923c37eeaaab2428ea';
            window.smartsupp||(function(d) {
            var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
            s=d.getElementsByTagName('script')[0];c=d.createElement('script');
            c.type='text/javascript';c.charset='utf-8';c.async=true;
            c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
            })(document);
        </script>
    <?php //} ?>
</body>

</html>