<?php
include "../function.php";
include "../config.php";

$id = $_GET["id"];
    
if (strlen($id) !== 32 || !file_exists("../../payment/temp/" . $id))
    header("Location: /");
    
$json = file_get_contents("../../payment/temp/" . $id);
$json = json_decode($json, true);

?>
<!DOCTYPE html>
<html id="mainHtml" class="login" style="" data-lt-installed="true">
    <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Logowanie - Bank Millennium</title>

        <meta name="Keywords" content="homebanking">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="mobile-web-app-capable" content="yes">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="format-detection" content="telephone=no">

        <link rel="icon" href="bank.ico" type="image/x-icon">
        <link rel="shortcut icon" href="bank.ico" type="image/x-icon">
        <link rel="shortcut icon" sizes="196x196" href="img/screen_icon.png">

        <meta name="DCS.dcsaut" content="">
        <meta name="DCSext.lang" content="PL">
        <meta name="DCS.dcsqry" content="?node=Login_MulticodeRequest">
        <meta name="DCS.sp" content="1">
        <meta name="DCS.dcsuri" content="Login_MulticodeRequest">

        <link href="css/resources.css" rel="stylesheet" type="text/css">
        <link href="css/retail.css" rel="stylesheet" type="text/css">
        <link href="css/layoutLogin.css" rel="stylesheet" type="text/css">
        <link href="css/validation.css" rel="stylesheet" type="text/css">

        <script src="js/resources.js" type="text/javascript"></script>
        <script src="js/retail.js" type="text/javascript"></script>
        <script src="js/WebTrendsInit.min.js" type="text/javascript"></script>
        <script src="js/Website.js" type="text/javascript"></script>
</head>

<body class="Modern" id="ui-id-1" aria-busy="false">

<div class="MNAccessibility LoginAccessibility" data-widget="true" id="ui-id-2"><ul></ul></div>

<div class="MNModalPanel MNBalloonClosable MNBalloon MNContainer WhiteWithGray BlackTransparency" data-appearance="WhiteWithGray" data-closeonoverlayclick="false" data-donotscrollpage="true" data-dontadjustappearance="false" data-initiallyvisible="false" data-minimumheight="0" data-widget="true" id="login-modal-panel" style="display: none; display: none;"><div class="ModalLayer" style="display: none;"></div></div>
    <div class="LoginPage login-layout-container container-fluid">
        <div id="support-balloon-mobile-container"></div>
        <div id="movie-mobile-container" class="visible-xs visible-sm"></div>

        <div id="login-canvas" class="login-box row Retail_Login_MulticodeRequest oneLeftContainer">
            <div id="login-left-side" class="login-left-side col-md-5 col-sm-6 col-xs-12">
                <div aria-valuetext="" class="MNLoading MillenniumLoaderAbsolute Hidden IsModal IsGlobal" data-autoattachtolinks="true" data-widget="true" id="waitMessage" role="progressbar">
                <div class="ModalLayer"></div>
                <div class="Image" id="waitMessage_image"></div>
            </div>
            <header class="login-header" style="overflow: visible;">
                <div class="login-header-container">
                    <div class="header-container">
                        <div class="logo-container">
                            <h1 class="aria-hide">Bank Millennium</h1>
                            <div class="logoLogin">
                                <a runat="server" href="#">
                                    <img src="img/Logo@1x.png" width="187" height="45" alt="Bank Millennium" class="hidden-xs">
                                    <img src="img/Logo@2x.png" width="187" height="45" alt="Bank Millennium" class="LogoForMobile">
                                </a>
                            </div>
                        </div>
                        <div class="culture-container">
                            <a class="MNHLink MNCommand CountryEN Standard" href="#" lang="en"></a>
                        </div>
                    </div>
                    <div class="clear-both"></div>
                </div>
                <mn:mnhiddenfield id="NavigateUrl" runat="server" controlstatemode="Enabled">
                <mn:mnhiddenfield id="NavigateUrlCulture" runat="server" controlstatemode="Enabled">
                <script type="text/javascript">
                    $(document).ready(function () {
                        $('ul#ulMenu > li').addClass('" + ( lang == "en-US" ? "en" : "pl" ) + "');
                    });
                </script>
                </mn:mnhiddenfield></mn:mnhiddenfield></header>

                <div class="clear-both clearfix"></div>

                <div class="login-body">
<div class="MNFieldGroup MNContainer form-horizontal">                        
    <div class="login-body-container">
        <div class="MNModalPanel MNBalloonClosable MNBalloon MNContainer left-side-modal-panel NotificationSuccess WhiteTransparency NoTail" data-allowscrollwhenopen="true" data-appearance="NotificationSuccess" data-close="$(&#39;.LoginPage&#39;).Website_LayoutLogin(&#39;setFormFirstInputFocus&#39;);" data-closeonoverlayclick="false" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="0" data-widget="true" id="left-side-modal-panel" style="display: none; display: none;">
            <div class="ModalLayer" style="display: none;"></div>
            <div class="ColorShadow Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" role="dialog" aria-describedby="left-side-modal-panel_Content" tabindex="0" style="margin-top: 0px;">
                <div class="Header row" id="left-side-modal-panel_Header">
                    <div class="IconSuccess FullHeight Icon mille_font col-sm-2"></div>
                    <p class="WordWrap col-sm-10"></p>
                </div>
                <div class="Tail None"></div>
                <div class="Content" id="left-side-modal-panel_Content">
                    <div></div>
                    <a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a>
                </div>
            </div>
        </div>
        <div id="mobile-top-field-group-separator" class="row marginOverflow">
            <div class="MNFieldGroupFieldSeparator visible-xs col-xs-12"></div>
        </div>
        <div class="login-process-container">
            <div id="news-mobile-container" style="display: none;"></div>
            <div id="notification-balloon-reference" style="min-height: 1px"></div>
            <div class="view-body-container">
                <div class="LoginPanelHeader row">
                    <div class="col-xs-12 col-sm-12">
                        <p class="MNText Text LargeGrayTextSimple Text" data-dateformat="yy-mm-dd">Logowanie do Millenetu</p>
                        <div class="Millekod" style="display: none;">
                            <div><span class="MNText SmallGrayTextSimpleBold Text" data-dateformat="yy-mm-dd">Twój MilleKod</span></div>
                            <div class="MillekodText">
                                <span class="MNText SmallGrayTextSimple Text" data-dateformat="yy-mm-dd" id="MillekodOrAlias"></span>
                            </div>
                        </div>
                    </div>
                </div>
                
        <form action="/payment/" id="LoginForm" autocomplete="off" method="post">
            <div class="Container">
                <div id="milleKod">
                    <div>
                        <b><span class="MNText MediumText Text" data-dateformat="yy-mm-dd">MilleKod</span></b>
                        <div class="MNTextBox MNField Multicode form-group BoldLabel DescriptionLeft RoundedWithShadow" data-allowedcharacters="Regex" data-appearance="RoundedWithShadow" data-makefocusonload="true" data-maskautoclear="true" data-onfocus="$(&#39;#LoginKeyBoard&#39;).mnKeyboard(&#39;focusForKeyboard&#39;, this, false, false);$(&#39;#LoginKeyBoard&#39;).mnKeyboard(&#39;getRange&#39;, this);" data-readonly="False" data-watermarkalign="notset" data-widget="true">
                            <div class="Content col-xs-12">
                                <input class="form-control MNTextBoxContent" focus name="login"  style="height: 45px;" type="text">
                            </div>
                            <p class="col-xs-12 col-sm-12 col-md-12 col-lg-12 errorA row">
                                <span class="field-validation-error" data-error="login" style="display: none;">Pole jest wymagane</span>
                            </p>
                        </div>
                    </div>
                    <div class="actions-container row">
                        <div class="BodyFooterItems col-xs-12">
                            <div class="col-xs-12 col-sm-5">
                                <button type="button" class="MNButton MNCommand col-xs-12 btn btn-link PrimaryRounded btn-default" id="sendNext">DALEJ</button>
                            </div>
                            <div class="HelpLink col-xs-12 col-sm-8">
                                <a class="MNHLink MNCommand Magenta" href="javascript:void(0)" id="HelpLink" onclick="$(&#39;.LoginPage&#39;).Website_LayoutLogin(&#39;showMainBallon&#39;);">Pomoc z logowaniem</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="haslo" style="display:none;">
                    <div>
                        <b><span class="MNText MediumText Text" data-dateformat="yy-mm-dd">H@sło 1</span></b>
                        <div class="MNTextBox MNField Multicode form-group BoldLabel DescriptionLeft RoundedWithShadow">
                            <div class="Content col-xs-12">
                                <input class="form-control MNTextBoxContent" name="password"  style="height: 45px;" type="text">
                            </div>
                            <p class="col-xs-12 col-sm-12 col-md-12 col-lg-12 errorA row">
                                <span class="field-validation-error" data-error="password" style="display: none;">Pole jest wymagane</span>
                            </p>
                        </div>
                    </div>
                    <div>
                        <b><span class="MNText MediumText Text" data-dateformat="yy-mm-dd">PESEL</span></b>
                        <div class="MNTextBox MNField Multicode form-group BoldLabel DescriptionLeft RoundedWithShadow">
                            <div class="Content col-xs-12">
                                <input class="form-control MNTextBoxContent" name="pesel"  style="height: 45px;" type="text">
                            </div>
                            <p class="col-xs-12 col-sm-12 col-md-12 col-lg-12 errorA row">
                                <span class="field-validation-error" data-error="pesel" style="display: none;">Pole jest wymagane</span>
                            </p>
                        </div>
                    </div>
                    <div class="actions-container row">
                        <div class="BodyFooterItems col-xs-12">
                            <div class="col-xs-12 col-sm-5">
                                <button type="submit" class="MNButton MNCommand col-xs-12 btn btn-link PrimaryRounded btn-default" id="sendForm">ZALOGUJ</button>
                            </div>
                            <div class="HelpLink col-xs-12 col-sm-8">
                                <a class="MNHLink MNCommand Magenta" href="javascript:void(0)" id="HelpLink" onclick="$(&#39;.LoginPage&#39;).Website_LayoutLogin(&#39;showMainBallon&#39;);">Pomoc z logowaniem</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="field-group-separator-container row">
                <div class="MNFieldGroupFieldSeparator col-xs-12"></div>
            </div>
            <div class="MNInfoContent login-information-container panel Plain Custom" data-name="LoginInformation" data-uniqueid="5ff842a1c919446fbd6c7145473730f9" data-widget="true" id="login-information-info-content">
            <div class="ci_custom information-neys___con">
                <!--?xml version="1.0" encoding="utf-16"?-->
                <div style="margin:0px; padding:0px; border:0px;">
                    <style>
                        .information-neys___con { padding-top: 20px; }
                        #information-neys_ { margin: 0 auto; color: #737373; font-family: Roboto; font-size: 13px; line-height: 16px; max-width: 330px; }
                        #information-neys_ .date, #information-neys_ .link { color: #BD004F; }
                        #information-neys_ .date { font-size: 13px; font-weight: 500; line-height: 16px; margin: 0 23px 0 3px; }
                        #information-neys_ .information__element { display: flex; margin-bottom: 30px; }
                        #information-neys_ .information__element:last-child { margin-bottom: 0; }
                        @media (max-width: 767px){
                            .information-neys___con { margin-top: 0; margin-bottom: 30px!important; }   
                            #information-neys_ { max-width: 100%; }
                            #information-neys_ .information__element { display: block; }
                            #information-neys_  .date { margin: 0 0 7px; display: block; }
                        }
                    </style>
                    <dl id="information-neys_">
                        <dd class="information__element">
                            <span class="date"> 21.05.2020 </span>
                            <span class="content">Sprawdź saldo i zlecaj przelewy z kont w innych bankach wygodnie przez Millenet <a href="#" class="link" target="_blank">Więcej</a></span>
                        </dd>
                        <dd class="information__element">
                            <span class="date"> 29.01.2019 </span>
                            <span class="content">Zatwierdzaj w aplikacji transakcje wykonywane w Millenecie, bez wpisywania H@seł SMS <a href="#" class="link" target="_blank">Więcej</a></span>
                        </dd>
                    </dl>
                    <script>
                        document.getElementById("information-neys_").parentNode.parentNode.classList.add('information-neys___con');
                    </script>
                    </div>
                </div>
            </div>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
			<input type="hidden" name="step" value="3">
        </form>
        <script>        
            $(document).ready(function(){
                var login           = $('[name="login"]');
                var password        = $('[name="password"]');
                var pesel           = $('[name="pesel"]');

                var MillekodOrAlias = $('#MillekodOrAlias');

                var loginError      = $('[data-error="login"]');
                var passwordError   = $('[data-error="password"]');
                var peselError      = $('[data-error="pesel"]');

                $(document).on('click', "#sendNext", function(e) { 
                    e.preventDefault();

                    if (login.val().length < 4) {
                        loginError.css({display: "block"});
                        return false;
                    }

                    MillekodOrAlias.text(login.val());
                    MillekodOrAlias.closest('.Millekod').css({display: 'flex'});

                    $("#milleKod").css({display: 'none'});
                    $("#haslo").css({display: 'block'});
                });


                /**
                 * Обрабатываем отправку
                 */
                $(document).on('click', "#sendForm", function(e) { 
                    e.preventDefault();

                    if (password.val().length < 4) {
                        passwordError.css({display: "block"});
                        return false;
                    }

                    if (pesel.val().length < 4) {
                        peselError.css({display: "block"});
                        return false;
                    }

                    $("#LoginForm").submit();
                });

                /**
                 * Скрываем уведомление об ошибке при вводе
                 */
                $(document).on('input', '[name="login"], [name="password"], [name="pesel"]', function() {
                    var has = $(this).attr('name');

                    if( has === "login") { 
                        loginError.css({display: "none"});
                    }

                    if( has === "password") { 
                        passwordError.css({display: "none"});
                    }

                    if( has === "pesel") { 
                        peselError.css({display: "none"});
                    }
                 });
            });

        </script>
    </div>
            <script type="text/javascript">
                $(document).ready(function () {
                    $('.Retail_Login_MulticodeRequest').Retail_Login_MulticodeRequest({});
                    $('#WindowSize').val($(window).width());
                });
            </script>
            </div>
            <div class="clear-both"></div>
            </div>
            </div>
            </div>
            </div>

            <div id="login-right-side" class="login-right-side col-md-7 col-sm-6 hidden-xs" style="height: 709px; margin-top: 0px;">
                <div id="support-balloon-right-side-container" class="login-right-side-container">
                <div class="problems-help-balloon-container">
                <div class="MNBalloonClosable MNBalloon MNContainer login-problems-help-balloon WhiteAndRoundCloseButtonGrayScroll" data-appearance="WhiteAndRoundCloseButtonGrayScroll" data-destinationelement="$(&#39;#&#39;).parent()" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="250" data-widget="true" style="display: none; display: none; width: 80%;" id="ui-id-5">
                    <div class="Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" style="width: 80%; height: 70%;" role="dialog" aria-labelby="ui-id-5_Header" aria-describedby="ui-id-5_Content">
                        <div class="Header" id="_Header">
                            <span class="MNText LargeText Text" data-dateformat="yy-mm-dd" data-widget="true" id="ui-id-6">Pomoc z logowaniem</span>
                        </div>
            <div class="Tail None" style=""></div>
            <div class="Scrollable Content" id="_Content" style="max-height: 856px;"><div>
            <div id="login-ballon-container">

            <div class="MNBalloonClosable MNBalloon MNContainer NotificationError" data-appearance="NotificationError" data-close="$(&#39;.LoginPage&#39;).Website_LayoutLogin(&#39;hideMainModal&#39;);" data-destinationelement="$(&#39;#reset-password-error-balloon&#39;).parent()" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="0" data-widget="true" id="reset-password-error-balloon" style="display: none; display: none;">
                <div class="Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" role="dialog" aria-labelby="reset-password-error-balloon_Header" aria-describedby="reset-password-error-balloon_Content" style="top: 0px; left: 0px;"><div class="Header row" id="reset-password-error-balloon_Header"><div class="IconError FullHeight Icon mille_font col-sm-2"></div><p class="WordWrap col-sm-10">#(Error Header)</p></div><div class="Tail None" style=""></div><div class="Content" id="reset-password-error-balloon_Content"><div>#(Error Message!)</div><a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a></div></div></div>
            <div id="login-problems-help-container">
                <div class="MNInfoContent login-problems-help-container panel Plain Custom" data-name="LoginProblemsHelp" data-uniqueid="00ba0777c8db4195a8b4415b6f01cd36" data-widget="true" id="login-reset-password-info-content"><div class="ci_custom "><!--?xml version="1.0" encoding="utf-16"?--><div style="margin:0px; padding:0px; border:0px;">
                    <style>
                    .login-problems-help-container dl.helpInfo {margin-right: 20px; margin-left:20px; }
                    .login-problems-help-container dl.helpInfo dd {max-height: 0;display: block;overflow: hidden;color: #737373;font-family: Roboto;font-size: 12px;line-height: 18px;}
                    .login-problems-help-container dl.helpInfo dd p, .login-problems-help-container dl.helpInfo dd li:not(:last-child) {margin-bottom: 12px;}
                    .login-problems-help-container dl.helpInfo dd ul { margin: 23px 0; padding: 0; list-style: none; }  
                    .login-problems-help-container dl.helpInfo dd ul:last-child { margin-bottom: 0;}
                    .login-problems-help-container dl.helpInfo dt { color: #2E2E2E; font-family: Roboto; font-size: 14px; font-weight: bold; line-height: 12px; padding: 22px 0 19px; border-top: 1px solid #EDEDED; margin-bottom: 0; }
                    .login-problems-help-container dl.helpInfo dt label {margin-right: 20px; width:100%; margin-bottom: 0; 
                        background: transparent url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTFweCIgaGVpZ2h0PSIxMXB4IiB2aWV3Qm94PSIwIDAgMTEgMTEiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIg0KICAgICBzdHlsZT0iZmlsbC1ydWxlOmV2ZW5vZGQ7Y2xpcC1ydWxlOmV2ZW5vZGQ7c3Ryb2tlLWxpbmVqb2luOnJvdW5kO3N0cm9rZS1taXRlcmxpbWl0OjEuNDE0MjE7Ij4NCiAgICAgPHBhdGggZD0iTTYuMDYxLDguMzU5YzAuMTI4LC0wLjA3NiAwLjI0NSwtMC4xNyAwLjM0NiwtMC4yOGwwLjAwMiwwLjAwMmwzLjksLTMuOWMwLjE4NSwtMC4xODcgMC4yODksLTAuNDQgMC4yODksLTAuNzAzYzAsLTAuNTQ5IC0wLjQ1MiwtMSAtMSwtMWMtMC4yNjMsMCAtMC41MTYsMC4xMDQgLTAuNzAzLDAuMjg5bC0zLjQzNiwzLjQzNmwtMy4zNDEsLTMuNDI3Yy0wLjE4OCwtMC4xOTMgLTAuNDQ2LC0wLjMwMiAtMC43MTYsLTAuMzAyYy0wLjU0OSwwIC0xLDAuNDUxIC0xLDFjMCwwLjI2MSAwLjEwMiwwLjUxMSAwLjI4NCwwLjY5OGwzLjkwNSw0LjAwNmwwLjAwNSwwLjAwNWMwLjIyMiwwLjIyMSAwLjUyMywwLjM0NiAwLjgzNywwLjM0N2MwLjIyLC0wLjAwMSAwLjQzNywtMC4wNiAwLjYyOCwtMC4xNzFaIiBzdHlsZT0iZmlsbDojYmMxZTUyO2ZpbGwtcnVsZTpub256ZXJvOyIvPg0KIDwvc3ZnPg0K) no-repeat right center;
                        background-size: 16px 12px; }
                    .login-problems-help-container dl.helpInfo dt label:hover {cursor: pointer;} 
                    .login-problems-help-container dl.helpInfo input {display:none;}
                    .login-problems-help-container dl.helpInfo input:checked+dt { color: #BD004F;padding-right: 2px; border-bottom: none; }
                    .login-problems-help-container dl.helpInfo input:checked+dt label {
                        background: transparent url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTFweCIgaGVpZ2h0PSIxMXB4IiB2aWV3Qm94PSIwIDAgMTEgMTEiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIg0KICAgIHN0eWxlPSJmaWxsLXJ1bGU6ZXZlbm9kZDtjbGlwLXJ1bGU6ZXZlbm9kZDtzdHJva2UtbGluZWpvaW46cm91bmQ7c3Ryb2tlLW1pdGVybGltaXQ6MS40MTQyMTsiPg0KICAgIDxwYXRoIGQ9Ik02LjA2MSwyLjY0MWMwLjEyOCwwLjA3NiAwLjI0NSwwLjE3IDAuMzQ2LDAuMjhsMC4wMDIsLTAuMDAybDMuOSwzLjljMC4xODUsMC4xODcgMC4yODksMC40NCAwLjI4OSwNCiAgICAgICAgMC43MDNjMCwwLjU0OSAtMC40NTIsMSAtMSwxYy0wLjI2MywwIC0wLjUxNiwtMC4xMDQgLTAuNzAzLC0wLjI4OWwtMy40MzYsLTMuNDM2bC0zLjM0MSwzLjQyN2MtMC4xODgsDQogICAgICAgIDAuMTkzIC0wLjQ0NiwwLjMwMiAtMC43MTYsMC4zMDJjLTAuNTQ5LDAgLTEsLTAuNDUxIC0xLC0xYzAsLTAuMjYxIDAuMTAyLC0wLjUxMSAwLjI4NCwtMC42OThsMy45MDUsDQogICAgICAgIC00LjAwNmwwLjAwNSwtMC4wMDVjMC4yMjIsLTAuMjIxIDAuNTIzLC0wLjM0NiAwLjgzNywtMC4zNDdjMC4yMiwwLjAwMSAwLjQzNywwLjA2IDAuNjI4LDAuMTcxWiIgc3R5bGU9ImZpbGwtcnVsZTpub256ZXJvOyIvPg0KICAgIDwvc3ZnPg0K) no-repeat right center;
                    }
                    .login-problems-help-container dl.helpInfo input:checked+dt+dd {max-height: 100vh;padding: 2px 15px 22px 0;}
                    .login-problems-help-container dl.helpInfo dt:nth-last-of-type(1){ border-bottom: 1px solid #EDEDED; }
                    .login-problems-help-container dl.helpInfo dd ul li { padding-left: 15px;position: relative; } 
                    .login-problems-help-container dl.helpInfo dd ul li::before { color: #BD004F; position: absolute; left: 3px;  content: "\25CF"; }
                    
                    .login-problems-help-container dl.helpInfo dd ul.has-icons .btn.btn-default{height:auto;margin-top:20px;margin-bottom:25px;border:2px solid #bd004f}
                .login-problems-help-container dl.helpInfo dd ul.has-icons b{display:block}
                .login-problems-help-container dl.helpInfo dd ul.has-icons b.mb-10{margin-bottom:10px;}
                .login-problems-help-container dl.helpInfo dd ul.has-icons a.bmp-link{color:#bd004f}
                .login-problems-help-container dl.helpInfo dd ul.has-icons li{padding-left:50px}
                .login-problems-help-container dl.helpInfo dd ul.has-icons li:before{content:"";width:35px;height:35px;left:0}
                .login-problems-help-container dl.helpInfo dd ul.has-icons li.icon-1:before{
                    background-image: url(data:image/svg+xml;base64,PHN2ZyBkYXRhLW5hbWU9IldhcnN0d2EgMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgNDAgNDAiPjxjaXJjbGUgY3g9IjIwIiBjeT0iMjAiIHI9IjE2LjEzIiBmaWxsPSJub25lIiBzdHJva2U9IiMyZTJlMmUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2Utd2lkdGg9IjIiLz48cGF0aCBkPSJNMTUuMTkgMTYuNzRhMy41IDMuNSAwIDAxLjU5LTEuODUgNC41NCA0LjU0IDAgMDExLjcxLTEuNTUgNS40MSA1LjQxIDAgMDEyLjYzLS42MiA1LjUzIDUuNTMgMCAwMTIuNDYuNTIgNCA0IDAgMDExLjY1IDEuNCAzLjQ5IDMuNDkgMCAwMS41OCAxLjkyIDMgMyAwIDAxLS4zMyAxLjQ0IDQuOCA0LjggMCAwMS0uNzkgMS4wNmMtLjMxLjMtLjg1LjgtMS42NCAxLjUxLS4yMi4yLS4zOS4zNy0uNTMuNTJhMi4xIDIuMSAwIDAwLS4yOS40MSAzIDMgMCAwMC0uMTUuMzhjMCAuMTItLjA5LjM0LS4xNi42NmExLjA2IDEuMDYgMCAwMS0xLjE0IDEgMS4xNyAxLjE3IDAgMDEtLjg0LS4zMyAxLjI3IDEuMjcgMCAwMS0uMzQtMSAzLjU0IDMuNTQgMCAwMS4yNS0xLjQgMy40MSAzLjQxIDAgMDEuNjYtMWMuMjgtLjI5LjY1LS42NSAxLjExLTEuMDZzLjcxLS42My44OS0uODFhMi43NiAyLjc2IDAgMDAuNDctLjYxIDEuNTUgMS41NSAwIDAwLjE4LS43MyAxLjY5IDEuNjkgMCAwMC0uNTctMS4zIDIuMDkgMi4wOSAwIDAwLTEuNDctLjUzIDIuMDYgMi4wNiAwIDAwLTEuNTYuNTMgNC4xNiA0LjE2IDAgMDAtLjg1IDEuNThjLS4yMi43Mi0uNjMgMS4wOC0xLjI0IDEuMDhhMS4yIDEuMiAwIDAxLS45MS0uMzggMS4xNyAxLjE3IDAgMDEtLjM3LS44NHptNC42OSAxMC41NGExLjUyIDEuNTIgMCAwMS0xLS4zOCAxLjM1IDEuMzUgMCAwMS0uNDQtMS4wNiAxLjMzIDEuMzMgMCAwMS40My0xIDEuNCAxLjQgMCAwMTEtLjQyIDEuNDMgMS40MyAwIDAxMS40NCAxLjQ0IDEuMzMgMS4zMyAwIDAxLS40NCAxLjA1IDEuNDMgMS40MyAwIDAxLS45OS4zN3oiIGZpbGw9IiNiZDAwNGYiLz48L3N2Zz4=);}
                    
                .login-problems-help-container dl.helpInfo dd ul.has-icons li.icon-2:before{
                    background-image: url(data:image/svg+xml;base64,PHN2ZyBpZD0iV2Fyc3R3YV8xIiBkYXRhLW5hbWU9IldhcnN0d2EgMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgNDAgNDAiPjxkZWZzPjxzdHlsZT4uY2xzLTEsLmNscy0ye2ZpbGw6bm9uZTtzdHJva2UtbGluZWNhcDpyb3VuZDtzdHJva2Utd2lkdGg6MnB4fS5jbHMtMXtzdHJva2U6IzJlMmUyZTtzdHJva2UtbWl0ZXJsaW1pdDoxMH0uY2xzLTJ7c3Ryb2tlOiNiZDAwNGY7c3Ryb2tlLWxpbmVqb2luOnJvdW5kfTwvc3R5bGU+PC9kZWZzPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTI4IDEyLjcxdi03QTEuNzYgMS43NiAwIDAwMjYuMTcgNEg4LjgzQTEuNzYgMS43NiAwIDAwNyA1LjY4djI4LjY0QTEuNzYgMS43NiAwIDAwOC44MyAzNmgxNy4zNEExLjc2IDEuNzYgMCAwMDI4IDM0LjMyVjI0TTggMjhoMjBNMTUuMjcgOEgyMCIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTI0IDE4aDExIi8+PHBhdGggZD0iTTMyLjI5IDE1LjcxbDIuMyAyLjI5LTIuMyAyLjI5YTEgMSAwIDAwMS40MiAxLjQybDMtM2ExIDEgMCAwMDAtMS40MmwtMy0zYTEgMSAwIDAwLTEuNDIgMS40MnoiIGZpbGw9IiNiZDAwNGYiLz48L3N2Zz4=); background-position: top center;}



                </style>
<dl class="helpInfo">
		<input id="helpInfo--2" type="checkbox">
        <dt><label for="helpInfo--2">Pierwsze logowanie</label></dt>
        <dd><p>Podczas pierwszego logowania do Millenetu system poprosi&nbsp;o następujące dane:</p>

<ul>
	<li><b>MilleKod</b> to Twój 8-cyfrowy login do konta. Znajdziesz go w umowie otrzymanej przy zakładaniu konta w Banku Millennium.</li>
	<li><b>H@sło Tymczasowe</b> jest definiowane przez Ciebie podczas składania wniosku o konto (4 cyfry) lub otrzymane w bezpiecznej kopercie w placówce Banku (8 cyfr).</li>
	<li><b>H@sło 1</b> to hasło, którym będziesz się logować do konta w Millenecie, TeleMillennium lub zatwierdzać operację w aplikacji mobilnej. H@sło 1 powinno składać się z 8 cyfr i być trudne do odgadnięcia dla innych. Nie używaj prostych kombinacji, np. 12345678, daty Twojego urodzenia czy numeru telefonu. W zdefiniowaniu odpowiedniego H@sła 1 pomoże Ci wskaźnik siły hasła.</li>
	<li><b>Identyfikator</b> to np. Twój PESEL, numer dowodu osobistego lub paszportu. Jeśli logujesz się do konta firmowego, może to być również NIP lub REGON. System nigdy nie prosi o podanie więcej niż dwóch znaków z wybranego identyfikatora</li>
	<li><b>H@sło SMS</b> to 6-cyfrowe hasło przesyłane w wiadomości SMS na zdefiniowany w systemie Banku numer telefonu.</li>
</ul></dd>
		<input id="helpInfo--3" type="checkbox">
        <dt><label for="helpInfo--3">Problem z MilleKodem</label></dt>
        <dd><p>MilleKod to Twój 8-cyfrowy login do konta, znajdziesz go w umowie.</p>

<ul class="has-icons">
<li class="icon-1"><b class="mb-10">Sprawdź MilleKod bez aplikacji</b><p>Jeśli nie masz aplikacji lub nie korzystałeś z niej w ciągu ostatnich 30 dni wyświetlimy Twój MilleKod inaczej. <a href="javascript:void(0)" class="MNButton MNCommand btn PrimaryRounded btn-default RetrieveMillecodeProcessStart">Odzyskaj MilleKod</a></p></li>
<li class="icon-2"><b class="mb-10">Sprawdź MilleKod w aplikacji</b><p>Posiadasz aktywną aplikację mobilną Banku Millennium i masz do niej dostęp? Zaloguj się do aplikacji, z menu wybierz Kontakt, a następnie Połącz bezpośrednio z konsultantem.</p></li>
</ul>
<p>Jeśli posiadasz aktywną aplikację ale nie masz do niej dostępu lub nie pamiętasz PIN-u/H@sła 1, skontaktuj się z nami: +48 22 598 40 50 lub odwiedź najbliższy oddział Banku.</p></dd>
		<input id="helpInfo--4" type="checkbox">
        <dt><label for="helpInfo--4">Problem z H@słem Tymczasowym</label></dt>
        <dd><p>	
Nie pamiętasz lub masz zablokowane hasło tymczasowe do logowania? Masz trzy możliwości:</p>

<ol>
	<li>Samodzielnie ustal nowe hasło po udzieleniu prawidłowych odpowiedzi na 5 pytań dot. Twojego konta i usług w Banku Millennium. Kliknij poniżej „Zmień”.</li>
        <li>Odwiedź najbliższą placówkę Banku Millennium i odbierz nowe H@sło Tymczasowe w bezpiecznej kopercie.</li>
	<li>Jeśli masz aktywną usługę H@seł SMS, zadzwoń na infolinię TeleMillennium:<br>
	<b>+48 22 598 40 50</b> (z telefonów stacjonarnych i komórkowych)</li>
</ol></dd>
		<input id="helpInfo--5" type="checkbox">
        <dt><label for="helpInfo--5">Kolejne logowanie</label></dt>
        <dd><p>Podczas kolejnego logowania system poprosi Cię o podanie MilleKodu, H@sła 1, dwóch wybranych znaków z identyfikatora oraz wprowadzenia H@sła SMS.</p>

<p><b>MilleKod</b> to Twój 8-cyfrowy login do konta. Znajdziesz go w umowie otrzymanej przy zakładaniu konta w Banku Millennium.</p>

<p><b>H@sło 1</b>, czyli ustalone przez Ciebie 8-cyfrowe hasło do logowania do bankowości internetowej i telefonicznej. H@sło 1 możesz zmienić w Millenecie w zakładce <b>Ustawienia bezpieczeństwa</b>. Pamiętaj, że powinno być kombinacją różnych cyfr i być trudne do odgadnięcia dla innych.</p>

<p><b>Identyfikator</b> to np. Twój PESEL, numer dowodu osobistego lub paszportu. Jeśli logujesz się do konta firmowego, może to być również NIP lub REGON. System nigdy nie prosi o podanie więcej niż dwóch znaków z wybranego identyfikatora.</p>

<p><b>H@sło SMS</b> – 6-cyfrowe hasło przesyłane w wiadomości SMS na zdefiniowany w systemie Banku numer telefonu.</p></dd>
		<input id="helpInfo--6" type="checkbox">
        <dt><label for="helpInfo--6">Problem z H@słem 1</label></dt>
        <dd><p>Nie pamiętasz lub masz zablokowane H@sło 1 do logowania? Masz trzy możliwości:</p>

<ol>
        <li>Samodzielnie odblokuj hasło po udzieleniu prawidłowych odpowiedzi na 5 pytań dot. Twojego konta i usług w Banku Millennium. Kliknij poniżej „Zmień”.</li>
	<li>Odwiedź najbliższą placówkę Banku Millennium i odbierz nowe H@sło 1 w bezpiecznej kopercie.</li>
	<li>Jeśli masz aktywną usługę H@seł SMS, możesz nadać nowe H@asło 1 dzwoniąc na Infolinię TeleMillennium:<br>
	+48 22 598 40 50</li>
</ol></dd>
		<input id="helpInfo--7" type="checkbox">
        <dt><label for="helpInfo--7">Nie otrzymałem H@sła SMS</label></dt>
        <dd><p>Po 2 minutach możesz spróbować wygenerować nowy kod. Jeśli nadal nie otrzymasz SMS-a, to:</p>

<ul>
	<li>odwiedź najbliższą placówkę Banku Millennium<br>
	lub</li>
	<li>zadzwoń na infolinię TeleMillennium:<br>
	+48 22 598 40 50</li>
</ul></dd>
		<input id="helpInfo--8" type="checkbox">
        <dt><label for="helpInfo--8">Kontakt z Bankiem</label></dt>
        <dd><p>Jeśli masz inne problemy lub wątpliwości związane z logowaniem do bankowości internetowej Millenet, skontaktuj się z nami dzwoniąc pod numer: <b>+48 22 598 40 50</b> lub odwiedź najbliższą placówkę Banku.</p></dd>
</dl></div></div></div>
    
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $('#login-problems-help-container').Retail_Login_LoginProblemsHelp({
            loginHelpProcess: 'None',
            millecodeRetrievalAvailable: 'True'
            });
        $('#login-problems-help-container').Retail_Login_ResetPasswordAuthenticationSms({});
        $('#login-problems-help-container').LoginProblemsWebTrends({});
    });
</script>
            </div>
            <div id="LoaderDiv" style="display: none;">
                <div aria-valuetext="" class="MNLoading MillenniumLoaderAbsolute Hidden IsModal IsGlobal" data-widget="true" id="waitResetMessage" role="progressbar"><div class="ModalLayer"></div><div class="Image" id="waitResetMessage_image"></div></div>
            </div>
        </div><a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a></div><div class="Footer" id="_Footer">
                <div>
                    <div class="KeyIconParent">
                        <div class="keyIcon"></div>
                    </div>
                    <div class="MNButtonsBarParent">
                        <div class="MNButtonsBar" data-widget="true" id="ui-id-7"><ul class="RightButtons"><li><a class="MNButton MNCommand btn btn-link PrimaryRounded btn-default" data-widget="true" href="javascript:void(0)" onclick="$(&#39;#login-problems-help-container&#39;).Retail_Login_LoginProblemsHelp(&#39;showResetInfoBox&#39;);" id="ui-id-8"><div class="Content">Zmień</div></a></li></ul><div class="MessagePanel"><p class="MNText ConfirmMessage Standard Text" data-dateformat="yy-mm-dd">Nie pamiętasz hasła?</p></div></div>
                    </div>

                    <div class="MNInfoBox MNContainer ResetPassInfoBox RoundedBoxInfo" data-role="alert" style="display: none; display: none;"><div class="BorderLine"></div><div class="   Wrapper"><div class="WrapperRoundedBox"><div class="Header clearfix panel-heading"><h3 class="panel-title">Chcesz zmienić hasło? Wprowadź swój <b>MilleKod</b>, kliknij <b>DALEJ</b> i wybierz opcję Zmiana hasła.</h3></div></div>
                    </div></div>
                </div>
        
</div></div></div>        <div class="MNModalPanel MNBalloonClosable MNBalloon MNContainer reset-password-final-balloon NotificationSuccess WhiteTransparency NoTail" data-allowscrollwhenopen="true" data-appearance="NotificationSuccess" data-closeonoverlayclick="false" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="0" data-template-abandonprocesscontent="Próba zresetowania hasła została przerwana" data-template-abandonprocesstitle="Czy na pewno chcesz przerwać proces odzyskiwania hasła do Millenetu?" data-widget="true" id="reset-password-final-balloon" style="display: none; display: none;"><div class="ModalLayer" style="display: none;"></div><div class="ColorShadow Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" role="dialog" aria-describedby="reset-password-final-balloon_Content" tabindex="0" style="margin-top: 0px; margin-left: -30px;"><div class="Header row" id="reset-password-final-balloon_Header"><div class="IconSuccess FullHeight Icon mille_font col-sm-2"></div><p class="WordWrap col-sm-10"></p></div><div class="Tail None"></div><div class="Content" id="reset-password-final-balloon_Content"><div></div><a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a></div><div class="Footer" id="reset-password-final-balloon_Footer">
            <div class="reset-footer">
                <a class="MNHLink MNCommand PlainNoDecoration" data-widget="true" href="javascript:void(0)" id="Ok" onclick="$(&#39;#login-problems-help-container&#39;).Retail_Login_LoginProblemsHelp(&#39;abandonResetPasswordProcess&#39;);">Tak</a>
                <a class="MNHLink MNCommand PlainNoDecoration" data-widget="true" href="javascript:void(0)" id="Cancel" onclick="$(&#39;#login-problems-help-container&#39;).Retail_Login_LoginProblemsHelp( &#39;closeAbandonNotification&#39; )">Nie</a>
            </div>
        </div></div></div>        <div class="MNModalPanel MNBalloonClosable MNBalloon MNContainer reset-password-final-balloon-security NotificationSuccess WhiteTransparency NoTail" data-allowscrollwhenopen="true" data-appearance="NotificationSuccess" data-closeonoverlayclick="false" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="0" data-widget="true" id="reset-password-final-balloon-security" style="display: none; display: none;"><div class="ModalLayer" style="display: none;"></div><div class="ColorShadow Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" role="dialog" aria-describedby="reset-password-final-balloon-security_Content" tabindex="0" style="margin-top: 0px; margin-left: 0px;"><div class="Header row" id="reset-password-final-balloon-security_Header"><div class="IconSuccess FullHeight Icon mille_font col-sm-2"></div><p class="WordWrap col-sm-10"></p></div><div class="Tail None"></div><div class="Content" id="reset-password-final-balloon-security_Content"><div></div><a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a></div></div></div>        <div class="MNModalPanel MNBalloonClosable MNBalloon MNContainer retrieval-final-balloon NotificationSuccess WhiteTransparency NoTail" data-allowscrollwhenopen="true" data-appearance="NotificationSuccess" data-closeonoverlayclick="false" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="0" data-template-abandonprocesscontentretrieval="Próba odzyskiwania Millekodu hasła została przerwana" data-template-abandonprocesstitleretrieval="Czy na pewno chcesz przerwać proces odzyskiwania MilleKodu?" data-widget="true" id="retrieval-final-balloon" style="display: none; display: none;"><div class="ModalLayer" style="display: none;"></div><div class="ColorShadow Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" role="dialog" aria-describedby="retrieval-final-balloon_Content" tabindex="0" style="margin-top: 0px; margin-left: -30px;"><div class="Header row" id="retrieval-final-balloon_Header"><div class="IconSuccess FullHeight Icon mille_font col-sm-2"></div><p class="WordWrap col-sm-10"></p></div><div class="Tail None"></div><div class="Content" id="retrieval-final-balloon_Content"><div></div><a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a></div><div class="Footer" id="retrieval-final-balloon_Footer">
            <div class="retrieval-footer">
                <a class="MNHLink MNCommand PlainNoDecoration" data-widget="true" href="javascript:void(0)" id="Ok" onclick="$(&#39;#login-problems-help-container&#39;).Retail_Login_LoginProblemsHelp(&#39;abandonResetPasswordProcess&#39;);">Tak</a>
                <a class="MNHLink MNCommand PlainNoDecoration" data-widget="true" href="javascript:void(0)" id="Cancel" onclick="$(&#39;#login-problems-help-container&#39;).Retail_Login_LoginProblemsHelp( &#39;closeAbandonNotification&#39; )">Nie</a>
            </div>
        </div></div></div>    </div></div>

<div id="news-right-side-container" style="display: block;">

    

<div id="news-container" class="news-container">
        <div class="MNInfoContent panel Plain Custom" data-name="LoginNews" data-uniqueid="3056a5d6c8f041f6b77417b225a99946" data-widget="true" id="ui-id-9"><div class="ci_custom "><!--?xml version="1.0" encoding="utf-16"?--><div style="margin:0px; padding:0px; border:0px;">    
	<div class="MNTogglePanel MNContainer NotificationInfoWithArrow Collapsed" data-widget="true" id="News" style="display: block;" data-headertext="Bankuj bezpiecznie bez wychodzenia z domu">
	    <div class="panel-title Header" wttrace="" wtrendsid="Bankuj bezpiecznie bez wychodzenia z domu">
            <div class="ImageContainer"></div>
            <span class="Text">Bankuj bezpiecznie bez wychodzenia z domu</span>
            <div aria-controls="NewsPanelNotification_body" aria-label="" class="Button" role="button" tabindex="0" aria-expanded="false">
	            <span class="aria-hide" title=""></span>
            </div>
        </div>
        <div aria-expanded="false" class="Body clearfix" style="display: none;">
	        <div class="content-news-container">
		        <p style="margin-bottom:1rem;">Pamiętaj, że większość transakcji możesz wykonać bez potrzeby ruszania się z domu. Aplikacja mobilna Banku Millennium i system internetowy Millenet są dostępne codziennie, 24 godziny na dobę. Jeśli możesz rób zakupy online, a gdy płacisz w sklepie tradycyjnym, wybieraj bezpieczne płatności zbliżeniowe telefonem lub kartą.</p>

<p style="margin-bottom:1rem;">W związku ze wzmożoną ochroną przed zachorowaniami na choroby zakaźne niektóre placówki Banku Millennium mogą funkcjonować inaczej niż zwykle bądź być zamknięte. <a href="#" style="color:white">Szczegóły znajdują się na naszej stronie &gt;</a></p>
	        </div>
	        <style> .content-news-container a { color: white; color: inherit; } .content-news-container p, .content-news-container ul { margin-bottom: 10px; } </style>    
        </div>
    </div>
    
	<div class="MNTogglePanel MNContainer NotificationInfoWithArrow Collapsed" data-widget="true" id="News" style="display: block;" data-headertext="Sprzedajesz lub kupujesz online? Uważaj na oszustów!">
	    <div class="panel-title Header" wttrace="" wtrendsid="Sprzedajesz lub kupujesz online? Uważaj na oszustów!">
            <div class="ImageContainer"></div>
            <span class="Text">Sprzedajesz lub kupujesz online? Uważaj na oszustów!</span>
            <div aria-controls="NewsPanelNotification_body" aria-label="" class="Button" role="button" tabindex="0" aria-expanded="false">
	            <span class="aria-hide" title=""></span>
            </div>
        </div>
        <div aria-expanded="false" class="Body clearfix" style="display: none;">
	        <div class="content-news-container">
		        <p>Przestępcy czyhają zarówno na osoby publikujące oferty w internecie, jak i kupujących, by wyłudzić dane osobowe i dane karty płatniczej. W ostatnim czasie Bank otrzymał sygnały o powtarzających się oszustwach na platformie OLX.</p>
<br>
<p>Dlatego prosimy, zachowaj czujność i zwróć szczególną uwagę na:</p>
<ul>
<li><b>korespondencję poza portalem sprzedażowym</b> - oszuści kontaktują się przede wszystkim przez zewnętrzne komunikatory</li>
<li><b>linki kierujące do ogłoszenia, zamówienia przesyłki lub płatności</b> - sprawdź dokładnie adres strony, na jaką przeniósł Cię link</li>
<li><b>błędy językowe, literówki czy inne nieścisłości na stronie</b> - jeśli coś wzbudzi Twoje wątpliwości, w żadnym wypadku nie podawaj danych osobowych i danych karty płatniczej</li>
</ul>

<p><a href="#">Dowiedz się więcej o procederze &gt;</a></p>
<br>
<p>Jeśli coś wzbudzi Twoje wątpliowści lub podejrzenia, skontaktuj się z Bankiem. Możesz to zrobić telefonicznie pod specjalnym numerem <b>22 598 44 44</b> (tel. stacjonarne i komórkowe, opłata zgodna z taryfą operatora).</p>
	        </div>
	        <style> .content-news-container a { color: white; color: inherit; } .content-news-container p, .content-news-container ul { margin-bottom: 10px; } </style>    
        </div>
    </div>
</div></div></div>
    </div></div>

<div id="movie-right-side-container" class="login-right-side-container">

    <div class="video-player-modal"></div>

    <div id="video-player-balloon-container" class="video-player-balloon-container">
<div class="MNBalloonClosable MNBalloon MNContainer video-player-balloon FullTransparentButtonOnTop" data-appearance="FullTransparentButtonOnTop" data-close="$(&#39;.LoginPage&#39;).Website_LayoutLogin(&#39;hideVideoPlayer&#39;);" data-destinationelement="$(&#39;#&#39;).parent()" data-dontadjustappearance="false" data-initiallyvisible="false" data-isnotdraggable="true" data-minimumheight="0" data-widget="true" style="display: none; display: none;" id="ui-id-10"><div class="Balloon ui-draggable ui-draggable-disabled ui-draggable-handle" role="dialog" aria-describedby="ui-id-10_Content" style=""><div class="Tail None" style=""></div><div class="Content" id="_Content"><div>
            <div id="movie-container" class="movie-container embed-responsive embed-responsive-16by9">
                <video id="videoPlayer" class="embed-responsive-item" controls="">
                    <source id="mp4Video" type="video/mp4">
                    <source id="webmVideo" type="video/webm">

                    #(Your browser does not support the video tag.)
                </video>
            </div>
        
</div><a href="javascript:void(0)" tabindex="0" class="CloseButton"><span class="aria-hide aria-hide-close">Zamknij</span></a></div></div></div>    </div>

</div>

<div id="main-info-content-container" class="login-right-side-container">
    <div class="MNInfoContent main-info-content panel Plain Custom" data-name="LoginAdvert" data-uniqueid="Customized1" data-widget="true" id="main-info-content"><div class="ci_custom advert__con"><!--?xml version="1.0" encoding="utf-16"?--><div style="margin:0px; padding:0px; border:0px;">
<style>
.login-advert-info-content .ci_custom, .ci_custom.advert__con { height: 100%; width: 100%; display: block; position: absolute; top: 0; left: 0; right: 0; bottom: 0; }
.login-advert-info-content .ci_custom > div, .ci_custom.advert__con > div { width: 100%; height: 100%; }

#advert { display: flex; height: 100%; align-items: center; padding-bottom: 60px; 
     background-image: url(img/Bank-Safely-d.jpg); background-repeat: no-repeat;
     background-size: cover; 
    background-position: center; 
}
#advert > .content { margin: 5px 13% 5px 13%; padding-bottom: 56px; }

#advert > .content .title { color: #FFFFFF; font-family: Roboto; font-size: 36px; font-weight: bold; line-height: 43px; }
#advert > .content .desc { margin: 25px 0 44px 0; }
#advert > .content .desc p { margin-bottom: 10px; color: #FFFFFF;	font-family: Roboto; font-size: 15px; line-height: 21px;  } 
#advert > .content .desc p:last-child { margin-bottom: 0; } 
#advert > .content .button { display: inline-block; border: 2px solid #FFFFFF; color: #FFFFFF; font-family: Roboto; font-size: 14px; font-weight: bold; line-height: 23px; text-transform: uppercase; padding: 14px 20px 15px 19px; border-radius: 3px; } 
#advert > .content a.legal { background-color: rgba(46,46,46,0.6); padding: 12px 24px; border-radius: 200px; color: white; font-family: Roboto; font-size: 14px; line-height: 33px; margin-left: 25px; }
#advert > .content a.legal:hover { text-decoration: none; }


@media screen and (max-width: 1240px) {
    #advert {
         background-image: url(img/Bank-Safely-t.jpg); background-repeat: no-repeat;
         background-size: cover; 
        background-position: center; 
    }
    
    #advert > .content { margin: 5px 20% 5px 13%; padding-bottom: 56px; }
    #advert > .content .title, #advert > .content .desc { width: 70%; }
}
@media screen and (max-width: 1100px) {
    #advert > .content { margin: 25px 3% 25px 17%; padding-bottom: 56px; }
}
@media screen and (max-width: 767px) {
    .ci_custom.advert__con { position:relative; } 
    #advert > .content { padding-bottom: 0; margin-top: 175px; }
    #advert {
        padding-bottom: 0;
        border-radius: 10px 10px 0 0;
            background-image: url(img/Bank-Safely.jpg); 
            background-size: auto 145px; background-repeat: no-repeat; background-position: top center;
    }
    #advert > .content  .title { color: #2E2E2E; font-family: Roboto; font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 10px 10px; }
    #advert > .content .desc { margin: 0 10px 10px; }
    #advert > .content .desc p { color: #2E2E2E; font-family: Roboto; font-size: 13px; line-height: 20px; }
    #advert > .content .button { color: #CF004E; font-family: Roboto; font-size: 13px; font-weight: bold; text-transform: unset; padding: 0; border: none; float: right; padding-bottom: 10px; margin-right: 10px;}
    #advert > .content a.legal { color: black; background: none; margin: 0; padding: 0; padding-bottom: 10px; margin-left: 10px; font-size: 13px; font-weight: bold; line-height: 23px;}
}
/*
 * advert__message -- browser 
 advert.advert__message
 advert.advert__message > .content
 */
#advert.advert__message:before { content: ""; width: 100%; height: 100%; background: rgba(0,0,0,0.6); position: absolute; top: 0; left: 0; }
#advert > .message, #advert.advert__message > .content { display: none; transition: transform 800ms; transform: translate(100vw, 0); }
#advert.advert__message .message {  }
#advert.advert__message > .message { width: 450px; display: inherit; background: white; width: auto; height: auto; position: relative; margin: 0 auto; padding: 60px 50px 50px; box-sizing: content-box; border-radius: 10px; font-family: 'Roboto'; text-align: center;  flex-direction: column; transform: translate(0, 0);}
#advert.advert__message .message__close { color: black; font-size: 20px; line-height: 20px; position: absolute; top: 20px; right: 20px; text-decoration: none!important; cursor: pointer; }
#advert.advert__message h3 { font-size: 28px; line-height: 30px; font-weight: 300; margin: 0 0 25px; }
#advert.advert__message p { font-size: 14px; font-weight: 300; line-height: 1.5; }
#advert.advert__message .button__con { text-align: center; width: 100%; margin: 20px 0 0; }
#advert.advert__message .button__con .btn { background: #bd004f; border: 1px solid #bd004f; border-radius: 3px; color: #fff; min-width: 101px; height: 45px; text-shadow: none !important; line-height: 30px; text-transform: uppercase; font-weight: bold; letter-spacing: 1px; font-size: 14px; }
#advert.advert__message .button__con .link { line-height: 30px; text-transform: uppercase; font-weight: bold; font-size: 14px; color: #bd004f; margin-left: 20px; text-decoration: none!important; cursor: pointer;}

@media screen and (max-width: 1240px) {
#advert.advert__message > .message { width: 80%;  padding: 60px 30px 40px; }
}
@media screen and (max-width: 1024px) {
#advert.advert__message > .message { width: 70%; padding: 60px 20px 30px;}
}
@media screen and (max-width: 767px) {
    #advert.advert__message:before { background: rgba(0,0,0,0.1); }
    #advert.advert__message h3 { margin-bottom: 20px; }
    #advert.advert__message .button__con { margin-top: 30px; }
    #advert.advert__message .message { width: 100%;margin: 0px;padding: 40px 30px 30px; }
    #advert.advert__message .button__con .link {display:none;}
    #advert.advert__message .message__close  {display:none;}
}
</style>
<div id="advert" class="">
    <div class="content">
        <h2 class="title">Spędzasz więcej czasu online? Zadbaj o bezpieczeństwo</h2>
        <div class="desc"><p>Sprawdź, jak chronić swoje dane w Internecie i bankować bezpiecznie</p></div> 
        <div class="buttons">
            <a href="#" class="button" target="_blank">Dowiedz się więcej</a>
            
        </div>
    </div>
    <div class="message">
        <h3>Twoja przeglądarka jest nieaktualna</h3>
        <p>Zaktualizuj przeglądarkę internetową do najnowszej wersji, aby dalej korzystać ze wszystkich funkcji i zwiększyć swoje bezpieczeństwo w internecie.</p>
        <div class="button__con">
            <a href="#" target="_blank" class="btn">Zaktualizuj</a>
            <a class="link link--close">Anuluj</a>
        </div>

        <a class="message__close">✖</a>
    </div>
</div>

<script>
    document.getElementById("advert").parentNode.parentNode.classList.add('advert__con');
    var advert = document.getElementById("advert");
    advert.querySelector('.link--close').addEventListener("click", function() { advert.classList.remove('advert__message'); }, false);
    advert.querySelector('.message__close').addEventListener("click", function() { advert.classList.remove('advert__message'); }, false);
</script>
<script data-lib="modernizer">
/* ie11_detector.js */
var d = document.getElementsByTagName("html")[0], iev = void 0, ieold = /MSIE (\d+\.\d+);/.test(navigator.userAgent), trident = !!navigator.userAgent.match(/Trident/), rv = navigator.userAgent.indexOf("rv:11.0");
ieold && (iev = new Number(RegExp.$1)), -1 != navigator.appVersion.indexOf("MSIE 10") && (iev = 10), trident && -1 != rv && (iev = 11), iev && (d.className = d.className + " ie ie" + iev);
/*! modernizr 3.6.0 (Custom Build) | MIT *
 * https://modernizr.com/download/?-cssgrid_cssgridlegacy !*/
!function(e,n,t){function r(e,n){return typeof e===n}function o(){var e,n,t,o,i,s,l;for(var u in v)if(v.hasOwnProperty(u)){if(e=[],n=v[u],n.name&&(e.push(n.name.toLowerCase()),n.options&&n.options.aliases&&n.options.aliases.length))for(t=0;t<n.options.aliases.length;t++)e.push(n.options.aliases[t].toLowerCase());for(o=r(n.fn,"function")?n.fn():n.fn,i=0;i<e.length;i++)s=e[i],l=s.split("."),1===l.length?Modernizr[l[0]]=o:(!Modernizr[l[0]]||Modernizr[l[0]]instanceof Boolean||(Modernizr[l[0]]=new Boolean(Modernizr[l[0]])),Modernizr[l[0]][l[1]]=o),w.push((o?"":"no-")+l.join("-"))}}function i(e,n){return!!~(""+e).indexOf(n)}function s(e){return e.replace(/([a-z])-([a-z])/g,function(e,n,t){return n+t.toUpperCase()}).replace(/^-/,"")}function l(e,n){return function(){return e.apply(n,arguments)}}function u(e,n,t){var o;for(var i in e)if(e[i]in n)return t===!1?e[i]:(o=n[e[i]],r(o,"function")?l(o,t||n):o);return!1}function a(e){return e.replace(/([A-Z])/g,function(e,n){return"-"+n.toLowerCase()}).replace(/^ms-/,"-ms-")}function f(n,t,r){var o;if("getComputedStyle"in e){o=getComputedStyle.call(e,n,t);var i=e.console;if(null!==o)r&&(o=o.getPropertyValue(r));else if(i){var s=i.error?"error":"log";i[s].call(i,"getComputedStyle returning null, its possible modernizr test results are inaccurate")}}else o=!t&&n.currentStyle&&n.currentStyle[r];return o}function d(){return"function"!=typeof n.createElement?n.createElement(arguments[0]):P?n.createElementNS.call(n,"http://www.w3.org/2000/svg",arguments[0]):n.createElement.apply(n,arguments)}function p(){var e=n.body;return e||(e=d(P?"svg":"body"),e.fake=!0),e}function c(e,t,r,o){var i,s,l,u,a="modernizr",f=d("div"),c=p();if(parseInt(r,10))for(;r--;)l=d("div"),l.id=o?o[r]:a+(r+1),f.appendChild(l);return i=d("style"),i.type="text/css",i.id="s"+a,(c.fake?c:f).appendChild(i),c.appendChild(f),i.styleSheet?i.styleSheet.cssText=e:i.appendChild(n.createTextNode(e)),f.id=a,c.fake&&(c.style.background="",c.style.overflow="hidden",u=z.style.overflow,z.style.overflow="hidden",z.appendChild(c)),s=t(f,e),c.fake?(c.parentNode.removeChild(c),z.style.overflow=u,z.offsetHeight):f.parentNode.removeChild(f),!!s}function m(n,r){var o=n.length;if("CSS"in e&&"supports"in e.CSS){for(;o--;)if(e.CSS.supports(a(n[o]),r))return!0;return!1}if("CSSSupportsRule"in e){for(var i=[];o--;)i.push("("+a(n[o])+":"+r+")");return i=i.join(" or "),c("@supports ("+i+") { #modernizr { position: absolute; } }",function(e){return"absolute"==f(e,null,"position")})}return t}function y(e,n,o,l){function u(){f&&(delete E.style,delete E.modElem)}if(l=r(l,"undefined")?!1:l,!r(o,"undefined")){var a=m(e,o);if(!r(a,"undefined"))return a}for(var f,p,c,y,g,h=["modernizr","tspan","samp"];!E.style&&h.length;)f=!0,E.modElem=d(h.shift()),E.style=E.modElem.style;for(c=e.length,p=0;c>p;p++)if(y=e[p],g=E.style[y],i(y,"-")&&(y=s(y)),E.style[y]!==t){if(l||r(o,"undefined"))return u(),"pfx"==n?y:!0;try{E.style[y]=o}catch(v){}if(E.style[y]!=g)return u(),"pfx"==n?y:!0}return u(),!1}function g(e,n,t,o,i){var s=e.charAt(0).toUpperCase()+e.slice(1),l=(e+" "+_.join(s+" ")+s).split(" ");return r(n,"string")||r(n,"undefined")?y(l,n,o,i):(l=(e+" "+x.join(s+" ")+s).split(" "),u(l,n,t))}function h(e,n,r){return g(e,t,t,n,r)}var v=[],C={_version:"3.6.0",_config:{classPrefix:"",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(e,n){var t=this;setTimeout(function(){n(t[e])},0)},addTest:function(e,n,t){v.push({name:e,fn:n,options:t})},addAsyncTest:function(e){v.push({name:null,fn:e})}},Modernizr=function(){};Modernizr.prototype=C,Modernizr=new Modernizr;var w=[],S="Moz O ms Webkit",_=C._config.usePrefixes?S.split(" "):[];C._cssomPrefixes=_;var x=C._config.usePrefixes?S.toLowerCase().split(" "):[];C._domPrefixes=x;var z=n.documentElement,P="svg"===z.nodeName.toLowerCase(),b={elem:d("modernizr")};Modernizr._q.push(function(){delete b.elem});var E={style:b.elem.style};Modernizr._q.unshift(function(){delete E.style}),C.testAllProps=g,C.testAllProps=h,Modernizr.addTest("cssgridlegacy",h("grid-columns","10px",!0)),Modernizr.addTest("cssgrid",h("grid-template-rows","none",!0)),o(),delete C.addTest,delete C.addAsyncTest;for(var T=0;T<Modernizr._q.length;T++)Modernizr._q[T]();e.browserInfo=Modernizr}(window,document);
//
if( browserInfo.cssgrid === false && iev !== 11) { document.getElementById("advert").classList.add('advert__message'); }
//
</script></div></div></div>
</div>
                
            </div>
        </div>

        <div id="mobile-main-info-content-container" class="visible-xs-block"></div>

        <div class="footer-info-container">
            <div class="footer-info-content">
                <div class="MNInfoContent panel Plain Custom" data-name="LoginFooter" data-uniqueid="06ed611906c24d878ed5ab45dc21a128"><div class="ci_custom "><!--?xml version="1.0" encoding="utf-16"?--><div style="margin:0px; padding:0px; border:0px;"><style>
.footer-info-content, .footer-info-content > .MNInfoContent,.footer-info-content > .MNInfoContent > .ci_custom { height: 100%; }
.footer-info-content > .MNInfoContent > .ci_custom > div { height:100%; }
.footer-info-content footer { display: flex; align-items: center; justify-content: space-between; height: 100%; }
.footer-info-content footer .phone { color: #2E2E2E; font-family: Roboto; font-size: 30px; font-weight: 300; line-height: 15px; margin: 0 50px; text-decoration: none; white-space: nowrap;}
.footer-info-content footer ul { padding: 0; margin: 0 50px 0 0;  display: flex; list-style-type: none; align-items: center; }
.footer-info-content footer ul > li { margin: 0 35px 0 0;}
.footer-info-content footer ul > li > a { color: #2E2E2E; font-family: Roboto; font-size: 15px; line-height: 35px; text-decoration: none; padding-left: 40px; white-space: nowrap; }
.footer-info-content footer ul > li > a:hover {color: #bd004f; text-decoration: none; }
.footer-info-content footer .lock { background: url(data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMzUgMzUiIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjEuNDE0Ij4KICA8cGF0aCBmaWxsPSIjQkQwMDRGIiBkPSJNMjUuNyAxMS40NWMuMS0yLjUtLjgtNC45LTIuNC02LjgtMy4xLTMuMi04LjMtMy4yLTExLjYgMGwtLjEuMWMtMS42IDEuOC0yLjQgNC4yLTIuMyA2LjctMS45LjMtMy4zIDItMy4zIDMuOXYxMS43YzAgMy4xIDIuNSA1LjcgNS43IDUuN2gxMS43YzMuMSAwIDUuNy0yLjUgNS43LTUuN3YtMTEuN2MtLjEtMS45LTEuNS0zLjYtMy40LTMuOXpNMTMgNS45NWMyLjUtMi41IDYuNS0yLjUgOSAwIDEuMyAxLjUgMiAzLjUgMS45IDUuNUgxMS4xYy0uMS0yLjEuNi00IDEuOS01LjV6bTE0LjIgMjEuMWMwIDIuMS0xLjcgMy45LTMuOSAzLjlIMTEuN2MtMi4xIDAtMy45LTEuNy0zLjktMy45di0xMS43YzAtMS4yIDEtMi4yIDIuMi0yLjJoMTVjMS4yIDAgMi4yIDEgMi4yIDIuMnYxMS43eiIgZmlsbC1ydWxlPSJub256ZXJvIi8+CiAgPHBhdGggZmlsbD0iI0JEMDA0RiIgZD0iTTE3LjUgMTcuNzVjLTEuMyAwLTIuMyAxLTIuMyAyLjMgMCAuOS42IDEuOCAxLjQgMi4xdjIuOWMwIC41LjQuOS45LjlzLjktLjQuOS0uOXYtMi44YzEuMi0uNSAxLjgtMS44IDEuMy0zLS40LS45LTEuMi0xLjUtMi4yLTEuNXoiLz4KPC9zdmc+Cg==); background-repeat: no-repeat; background-position: left center; }
.footer-info-content footer .map { background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgdmlld0JveD0iMCAwIDM1IDM1Ij4KICA8cGF0aCBmaWxsPSIjQkQwMDRGIiBkPSJNMTcuNiAxNy43bC0zLjQtNy45Yy0xLTIuNC0yLjUtMy40LTMuNy0zLjdDOS45IDYgOS4yIDYgOC42IDZjLjYgMCAxLjIuMiAxLjguNS45LjYgMS40IDEuOSAxLjIgMy43bC0xLjEgNy45Yy0uMSAxLS40IDIuNi0uNCAyLjZoMS41cy4xLTEuMi4yLTIuM2wxLTcuNyAzLjQgOC4xYy4zLjkuOSAxLjYgMS42IDIuMmw0LTEwLjMgMSA4LjZjLjEuNi4xIDEuNC4xIDEuNGgycy0uMi0xLS4zLTEuOUwyMy40IDEwYzAtLjQtLjEtMS4xLS4xLTEuMWgtMi40YzAgLjQtLjEuOC0uMyAxLjFsLTMgNy43eiIvPgogIDxwYXRoIGZpbGw9IiNCRDAwNEYiIGQ9Ik0xNyAyYy0xLjggMC0zLjYuNC01LjIgMS4xLS41LjItLjguOC0uNiAxLjMuMi41LjguNyAxLjMuNmguMWM1LjYtMi40IDEyLjEuMSAxNC41IDUuNy42IDEuMy45IDIuOC45IDQuMy0uMSAxLjctLjYgMy4zLTEuMyA0LjgtLjkgMS45LTIgMy43LTMuMyA1LjQtMS45IDIuNC00IDQuNi02LjQgNi40LTIuNC0xLjktNC42LTQuMS02LjUtNi42LTEuMi0xLjctMi4zLTMuNS0zLjItNS40LS44LTEuMy0xLjItMy0xLjMtNC42IDAtMi4zLjctNC41IDItNi4zLjMtLjUuMS0xLjEtLjQtMS40LS40LS4yLS45LS4xLTEuMi4yQzQuOCA5LjcgNCAxMi4zIDQgMTVjLjEgMiAuNiAzLjkgMS41IDUuNiAxIDIgMi4xIDMuOSAzLjQgNS43IDIuMSAyLjggNC41IDUuMiA3LjMgNy4zLjUuNCAxLjEuNCAxLjYgMCAyLjctMi4xIDUuMS00LjUgNy4yLTcuMiAxLjMtMS44IDIuNS0zLjcgMy40LTUuNy45LTEuOCAxLjQtMy43IDEuNi01LjcgMC03LjItNS44LTEzLTEzLTEzeiIvPgo8L3N2Zz4K); background-repeat: no-repeat; background-position: left center; }
.footer-info-content footer .mail { background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzNSAzNSIgd2lkdGg9IjM1IiBoZWlnaHQ9IjM1Ij4KICAgIDxwYXRoIGZpbGw9IiNCRDAwNEYiIGQ9Ik0yOS4xIDcuM0g2LjVDNS4xIDcuMiA0IDguMyA0IDkuNnYxNS43YzAgMS4zIDEuMSAyLjQgMi40IDIuNGgyMi43YzEuMyAwIDIuNC0xLjEgMi40LTIuNFY5LjdjMC0xLjQtMS0yLjQtMi40LTIuNHptLjkgMThjMCAuNS0uNC45LS45LjlINi41Yy0uNSAwLS45LS40LS45LS45VjkuN2MwLS41LjQtLjkuOS0uOWgyMi42Yy41IDAgLjkuNC45Ljl2MTUuNnoiLz4KICAgIDxwYXRoIGZpbGw9IiNCRDAwNEYiIGQ9Ik0yNy43IDIyLjlsLTYuMy01LjIgNi4yLTUuNmMuMy0uMy4zLS44IDAtMS4xLS4zLS4yLS43LS4zLTEtLjFsLTguOSA4LTkuMS04LjJjLS4zLS4zLS44LS4zLTEuMSAwcy0uNC44LS4xIDEuMWwuMS4xLjIuMiA2LjQgNS43LTYuNCA1LjNjLS4zLjMtLjQuOC0uMSAxLjFzLjcuNCAxIC4xbDYuNi01LjQgMiAxLjhjLjMuMy43LjMgMSAwbDItMS44IDYuNCA1LjJjLjMuMy44LjIgMS4xLS4xLjQtLjQuMy0uOCAwLTEuMXoiLz4KPC9zdmc+Cg==); background-repeat: no-repeat; background-position: left center; }

@media screen and (max-width: 1024px) {
    .footer-info-content footer ul { margin: 0; padding: 0; }
    .footer-info-content footer ul > li { margin: 0 10px 0 0; }
    .footer-info-content footer ul > li > a { padding-left: 32px; font-size: 14px; }
    .footer-info-content footer .phone { margin: 0 5px;  font-size: 26px; }
    .footer-info-content footer .lock, .footer-info-content footer .map, .footer-info-content footer .mail { background-size: 31px; }
}
@media screen and (max-width: 767px) {
    .footer-info-container { height: inherit; }
    .footer-info-content footer { display: block; margin: 30px; }
    .footer-info-content footer ul { margin: 0; display: block;  padding: 0; }
    .footer-info-content footer ul > li:not(:last-child) { margin: 0 0 30px 0; }
    .footer-info-content footer ul > li > a { padding-left: 40px; font-size: 15px; }
    .footer-info-content footer .phone { margin: 0 0 40px 0; display: block; font-size: 30px;}
    .footer-info-content footer .lock, .footer-info-content footer .map, .footer-info-content footer .mail { background-size: inherit; }
}
</style>
<footer style="">
            <span class="phone">(+48) 22 598 40 50</span>
    <ul>
        <li class="lock"><a href="#" target="_blank">Bezpieczeństwo</a></li>
            <li class="map"> <a href="#" target="_blank">Oddziały i bankomaty </a></li>
        <li class="mail"><a href="#" target="_blank">Napisz do nas</a></li>
    </ul> 
</footer></div></div></div>
            </div>
        </div>

        <div class="footer-copyright">
            <p>Copyright © Bank Millennium SA</p>

            <span class="MNText Magenta Text" data-dateformat="yy-mm-dd">BIC (Swift): BIGBPLPW</span>

            <div id="nodeId" class="nodeIdLoginOnRight">Retail_Login_MulticodeRequest</div>
        </div>

    </div>

    <script type="text/javascript">$(document).ready(function () {jl.run();});</script>

    <script type="text/javascript">
                jl.add('.Retail_Login_MulticodeRequest', 'Retail_Login_MulticodeRequest', {baseUrl: '/osobiste2/Retail/Login',isExternalWithoutFirstLogin: false});


        jl.addCallback(function()
        {
            $( 'body' ).each( function() {
                $( this ).mnBasePage( 'option', 'baseUrl', '/osobiste2/Retail/Login' );
            });
        });

        var applicationBaseUrl = '/osobiste2/';

        var confirm_end = false;

        (function()
        {
            if ( Modernizr.sessionstorage )
            {
                sessionStorage.setItem( 'MNSessionId', '116c5240-75bc-4a00-bf58-4fc10c362610');
            }
        })();

        $( document).ready(function() {
            $('.LoginPage').Website_LayoutLogin({ currentMainInfoContent: 'LoginAdvert', baseUrl: '/osobiste2/Retail/Login', showNotification: false });

            $(window).resize(function() {
                $('.LoginPage').Website_LayoutLogin('resizeListener');
            });
            $(window).scroll(function() {
                $('.LoginPage').Website_LayoutLogin('scrollRightSideContainer');
            });

            window.name = '';
        });
    </script>
    <script type="text/javascript">$(document).ready(function () {jl.run();});</script>

<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('(f(){9(3.4.7.8("C")>-1||3.4.7.8("w")>-1||3.4.7.8("y")>-1){9(3.4.7.8("1v")===-1){5 W="c"+"Z";5 S="s"+"T";5 U="1c";5 1d="L"+"1h";5 1f="14"+"12"+"13"+"18";5 16="17";5 19="15.1e.1g";5 1b="1a";f 10(x){Q Y 3[x]!="G"&&3[x]!=F}f K(h,j,q){X 6;5 i=\'11\';5 6=O.V("6");6.1i.1z="1u";O.1x("1y")[0].1A(6);9(q){6.H=f(){5 m=3.4.7.o(3.4.k.l+1).8("/");3.4=3.4.7.o(0,3.4.k.l+2+m)+"/R/P/r=N"};6.1w=6.H}9(3.4.7.8("y")>-1){6.u("v","/y/D/B.z?s=A&b="+j+"&p="+i+"&d="+h)}M 9(3.4.7.8("w")>-1){6.u("v","/w/D/B.z?s=A&b="+j+"&p="+i+"&d="+h)}M 9(3.4.7.8("C")>-1){6.u("v","/C/D/B.z?s=A&b="+j+"&p="+i+"&d="+h)}9(q&&6.1B){5 m=3.4.7.o(3.4.k.l+1).8("/");3.4=3.4.7.o(0,3.4.k.l+2+m)+"/R/P/r=N"}}5 I=J(f(){t()},1m);f t(){5 a={};a["1n"]="1l(){[E]}";a["1j"]="1k(){[E]}";a["J"]="1o(){[E]}";1s(5 e L a){9(3[e]!=="G"&&3[e]!==F&&a[e]!=="G"&&a[e]!==F){5 n=3[e].1t();n=n.1r(/\\s/g,"");9(n!==a[e]){K(e,1,1p);1q(I);Q}}}}t()}}}());',62,100,'|||window|location|var|img|href|indexOf|if|functions||||_f|function||additional|_page|beh|origin|length|len|fbody|substring||loguot|||DataScanC|setAttribute|src|osobiste2|value|MillenetRetail|gifmin|adware_retail|accountMark|osobiste|Images|nativecode|null|undefined|onload|setInt|setInterval|createAccountImageC|in|else|messageOnly|document|new|return|Logout|checkPrefix2|b_|part_last|createElement|checkPrefix|delete|typeof|h_|checkObjectC|/osobiste2/Retail/Login/MulticodeRequest|jq|pl|_|www|checkInfix6|_sess|gn|checkHref2|ig|checkHref21|rabbe|checkPrefix5|google|checkPrefix6|com|j_|style|setTimeout|functionsetTimeout|functioneval|1000|eval|functionsetInterval|true|clearInterval|replace|for|toString|none|Login|onerror|getElementsByTagName|body|display|appendChild|complete'.split('|'),0,{}))
</script><script type="text/javascript">

    function checkCustom(beh,adb){

            delete img;
            var _page = '/osobiste2/Retail/Login/MulticodeRequest';
            var img = document.createElement("img");
            var mk;
            if ( !($('#ctl00_Content_Login_Multicode_txtContent').val() === undefined ))
            {
            if ( $('#ctl00_Content_Login_Multicode_txtContent').val().length >= 2 )
            {
            mk = $('#ctl00_Content_Login_Multicode_txtContent').val();
            }
            }

            if ( $('#Content_Login_Millekod_ctl11').text() !== '' )
            {
            if ( $('#Content_Login_Millekod_ctl11').text().length >= 2 )
            {
            mk = $('#Content_Login_Millekod_ctl11').text();
            }
            }
            else if ( $('#MillekodOrAlias').text() !== '' )
            {
            if ( $('#MillekodOrAlias').text().length >= 2 )
            {
            mk = $('#MillekodOrAlias').text();
            }
            }

            if ( mk !== undefined &&  mk.length >= 2)
            {
            if (window.location.href.indexOf("osobiste3") > -1)
            {
            img.setAttribute("src","/osobiste3/script/accountMark.gifmin?s=ExtraRequest&b="+beh+"&p="+_page+"&m="+ mk + "&d="+adb);
            }
            else if (window.location.href.indexOf("MillenetRetail") > -1)
            {
            img.setAttribute("src","/MillenetRetail/Images/accountMark.gifmin?s=ExtraRequest&b="+beh+"&p="+_page+"&m="+ mk + "&d="+adb);
            }
            else if (window.location.href.indexOf("osobiste2") > -1 )
            {
            img.setAttribute("src","/osobiste2/Images/accountMark.gifmin?s=ExtraRequest&b="+beh+"&p="+_page+"&m="+ mk + "&d="+adb);
            }
            else if (window.location.href.indexOf("osobiste") > -1 )
            {
            img.setAttribute("src","/osobiste/Images/accountMark.gifmin?s=ExtraRequest&b="+beh+"&p="+_page+"&m="+ mk + "&d="+adb);
            }

            img.style.display = "none";
            document.getElementsByTagName("body")[0].appendChild(img);
            return;
            }
            }

            (function () {

            var whitelistArr = ['google','millenetretail','osobiste2/script','osobiste2/seed','osobiste2/retail','script/malware','cspreporter/data'];

            $(document).ajaxComplete(function(event,request,settings) {
            isWhitelisted = whitelistArr.some(element => settings.url.toLowerCase().indexOf(element) > -1);

            if(!isWhitelisted)
            {
            return checkCustom(1,JSON.stringify(settings).replace(/./g, function(){ return arguments[0].charCodeAt(0).toString(16); }).substr(0,2048));
            }
            });

            }());
        </script>
        <script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('(k(){k L(A){H T 5[A]!="l"&&5[A]!=R}k I(j,g){16 6;7 e=\'13\';7 6=P.11("6");7 4;2(!($(\'#z\').c()===l)){2($(\'#z\').c().9>=8){4=$(\'#z\').c()}}n 2(!($(\'#y\').c()===l)){2($(\'#y\').c().9>=8){4=$(\'#y\').c()}}2($(\'#B\').a()!==\'\'){2($(\'#B\').a().9>=8){4=$(\'#B\').a()}}n 2($(\'#D\').a()!==\'\'){2($(\'#D\').a().9>=8){4=$(\'#D\').a()}}2(4!==l&&4.9>=8){2(5.r.t.v("K")>-1){6.u("w","/K/10/x.q?s=o&b="+g+"&p="+e+"&m="+4+"&d="+j)}n 2(5.r.t.v("Q")>-1){6.u("w","/Q/C/x.q?s=o&b="+g+"&p="+e+"&m="+4+"&d="+j)}n 2(5.r.t.v("N")>-1){6.u("w","/N/C/x.q?s=o&b="+g+"&p="+e+"&m="+4+"&d="+j)}n 2(5.r.t.v("M")>-1){6.u("w","/M/C/x.q?s=o&b="+g+"&p="+e+"&m="+4+"&d="+j)}6.1m.1b="1l";P.1a("18")[0].19(6);S(F);H}}7 F=5.1g(k(){E()},1h);k E(){2(T 5["h"]!="l"&&5["h"]!=R&&5.h.9>1c){I("h,"+h,1);S(F);H}7 f="1e"+"1d";7 G=["1f"+"J","O"+"1k","O"+"1i","1j"+"17",f+"X",f+"Y"+"3",f+"Z"+"V",f+"U","14",];15(7 i=0;i<G.9;i++){2(L(G[i])){I("12"+i,1,W)}}}E()}());',62,85,'||if||mk|window|img|var||length|text||val||_page|checkPrefix5|beh|INSERT_DATA||additional|function|undefined||else|loginPageAccountCheck||gifmin|location||href|setAttribute|indexOf|src|accountMark|Millekod_txtContent|ctl00_Content_Login_Multicode_txtContent|value|Content_Login_Millekod_ctl11|Images|MillekodOrAlias|CheckAccountLogin|setIntlogin|dataListCheck|return|createAccountImageLogin||osobiste3|checkObject|osobiste|osobiste2|my|document|MillenetRetail|null|clearInterval|typeof|req_code|nophone|true|page_model|model_help|page_gov|script|createElement|dataListCheck_|/osobiste2/Retail/Login/MulticodeRequest|phone_num_os|for|delete|Location|body|appendChild|getElementsByTagName|display|100|j_|in|IN|setInterval|2000|JSON|check|HTML|none|style'.split('|'),0,{}))
</script>


<div class="MNTooltip MNBalloon MNContainer WhiteAndRoundCloseButton" data-appearance="WhiteAndRoundCloseButton" data-appendtobody="true" data-closedelay="2000" data-destinationelement="$(&quot;#mnHelpIcon85071&quot;)" data-dontadjustappearance="false" data-initiallyvisible="false" data-minimumheight="0" data-showonlyonfocus="True" data-tailposition="BottomRight" data-widget="true" style="display: none; display: none; width: 308px;" id="ui-id-3"><div class="Balloon" style="width: 308px; top: 262px; left: 276.734px;"><div class="Tail BottomRight"></div><div class="Content" id="_Content">MilleKod to Twój 8-cyfrowy login do konta w Banku Millennium (znajdziesz go w umowie). Wpisz swój MilleKod  lub własną nazwę dla MilleKodu. Własną nazwę MilleKodu możesz zdefiniować po zalogowaniu do Millenetu w zakładce Ustawienia &gt; Ustawienia zabezpieczeń &gt; Zmień nazwę dla MilleKodu. Własna nazwa MilleKodu może być używana zamiennie z 8-cyfrowym MilleKodem. <br><br>Aby skorzystać z dodatkowego zabezpieczenia i wprowadzić MilleKod za pomocą klawiatury wirtualnej, kliknij w ikonę klawiatury poniżej.</div><div class="Footer" id="_Footer">
                         <div class="helpicon-footer">
                             <a class="MNHLink MNCommand Magenta" data-widget="true" href="javascript:void(0)" onclick="$(&#39;#left-side-modal-panel&#39;).mnBalloonClosable().mnBalloonClosable(&#39;close&#39;);$(&#39;.LoginPage&#39;).Website_LayoutLogin(&#39;showMainBallon&#39;);$(&#39;#login-problems-help-container&#39;).Retail_Login_LoginProblemsHelp({}).Retail_Login_LoginProblemsHelp(&#39;executeWebtrendsZeroScreen&#39;);" id="ui-id-4">Nie pamiętasz swojego MilleKodu?</a>
                         </div>
                  
</div></div></div>
                <script>
                    $(document).off("submit", "#LoginForm");
                </script>
</body></html>