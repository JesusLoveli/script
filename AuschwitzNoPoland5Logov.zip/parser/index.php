<?php

include "../config.php";

function print_response($response) {
	header("Content-Type: application/json");
	echo json_encode($response, JSON_UNESCAPED_UNICODE);

	exit;
}

$url = $_POST["url"];

if (!filter_var($url, FILTER_VALIDATE_URL)) {
    $response = [
        "status" => "error",
        "message" => [
            "title" => "Произошла ошибка",
            "description" => "Проверьте корректность введенной ссылки."
        ]
    ];
    
    print_response($response);
}

$url = str_replace("/d/oferta/", "/oferta/", $url);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$response = curl_exec($curl);
$error = curl_error($curl);
curl_close($curl);


if (!strpos($response, '<meta property="og:site_name" content="OLX.pl"/>')) {
    $response = [
        "status" => "error",
        "message" => [
            "title" => "Произошла ошибка",
            "description" => "Объявление по указанной ссылке не найдено."
        ]
    ];
    
    print_response($response);
}

$title = explode('"/>', explode('<meta property="og:title" content="', $response)[1])[0];
$price = explode(' zł:', explode('<meta name="description" content="', $response)[1])[0];
$image_url = explode('"/>', explode('<meta property="og:image" content="', $response)[1])[0];

$price = str_replace(" ", null, $price);

$image = file_get_contents($image_url);
$image_base64 = base64_encode($image);

$request = [
    "key" => $config["imgbb"]["api_key"],
    "image" => $image_base64
];

$curl = curl_init("https://api.imgbb.com/1/upload");
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($request));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);

$response = json_decode($response, true);

if ($response["success"] !== true) {
    $response = [
        "status" => "error",
        "message" => [
            "title" => "Произошла ошибка",
            "description" => "При загрузке изображения произошла ошибка."
        ]
    ];
    
    print_response($response);
}

$response = [
    "status" => "success",
    "data" => [
        "id" => rand(100000000, 999999999),
        "title" => $title,
        "price" => $price,
        "image_url" => $response["data"]["url"]
    ]
];

print_response($response);

?>