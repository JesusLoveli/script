<?php

// Функция отправки сообщения.
function send($message, $chat_id, $keyboard = false) {
	include "../config.php";

	if (empty($message) 
		|| empty($chat_id)) 
		return false;

	$message = str_replace("_", "\\_", $message);

	$request = [
		"chat_id" => $chat_id,
		"text" => $message,
		"parse_mode" => "markdown",
		"disable_web_page_preview" => "true"
	];

	if ($keyboard)
		$request["reply_markup"] = json_encode($keyboard);

	$curl = curl_init("https://api.telegram.org/bot" . $config["bot"]["token"] . "/sendMessage?" . http_build_query($request));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_exec($curl);
	curl_close($curl);
}

// Функция изменения сообщения.
function edit($message, $chat_id, $message_id) {
    include "../config.php";

    if (empty($message) 
		|| empty($chat_id)
		|| empty($message_id)) 
		return false;

    $message = str_replace("_", "\\_", $message);

    $request = [
		"chat_id" => $chat_id,
		"message_id" => $message_id,
		"text" => $message,
		"parse_mode" => "markdown"
	];

	$curl = curl_init("https://api.telegram.org/bot" . $config["bot"]["token"] . "/editMessageText?" . http_build_query($request));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_exec($curl);
	curl_close($curl);
}

// Функция установки команды для пользователя.
function set_command($user_id, $command = null) {
	include "../config.php";

	if (empty($user_id)) 
		return false;

	$database = mysqli_connect($config["database"]["hostname"], $config["database"]["username"], $config["database"]["password"], $config["database"]["name"]);
	
	if ($command)
		$database->query("UPDATE users SET command = '" . $command . "' WHERE user_id = " . $user_id);
	else
		$database->query("UPDATE users SET command = NULL WHERE user_id = " . $user_id);
}

// Функция конвертации даты и времени в читабельный формат.
function date_convert($date) {
	$format = "Y-m-d H:i:s";
	$date = DateTime::createFromFormat($format, $date);

	$day = $date->format("j");
	$month = $date->format("n");

	$time = $date->format("H:i");

	switch ($month) {
		case 1: $month = "января"; break;
		case 2: $month = "февраля"; break;
		case 3: $month = "марта"; break;
		case 4: $month = "апреля"; break;
		case 5: $month = "мая"; break;
		case 6: $month = "июня"; break;
		case 7: $month = "июля"; break;
		case 8: $month = "августа"; break;
		case 9: $month = "сентября"; break;
		case 10: $month = "октября"; break;
		case 11: $month = "ноября"; break;
		case 12: $month = "декабря"; break;
	}

	$date = [
		0 => $day,
		1 => $month,
		2 => "в " . $time
	];

	$date = implode(" ", $date);

	return $date;
}

?>