<?php

$keyboard["main_menu"] = [
	"keyboard" => [
		[
			[
				"text" => "🔗  Создать ссылку"
			],
			[
				"text" => "📦  Мои объявления"
			]
		],
		[
			[
				"text" => "💬  Поддержка"
			],
			[
				"text" => "📋  Стандартные данные"
			]
		]
	],
	"resize_keyboard" => true
];

$keyboard["back_menu"] = [
	"keyboard" => [
		[
			[
				"text" => "↩  Вернуться"
			]
		]
	],
	"resize_keyboard" => true
];

?>