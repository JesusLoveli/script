<?php

include "../function.php";
include "../config.php";

function print_response($response) {
	header("Content-Type: application/json");
	echo json_encode($response, JSON_UNESCAPED_UNICODE);

	exit;
}

$database = mysqli_connect($config["database"]["hostname"], $config["database"]["username"], $config["database"]["password"], $config["database"]["name"]);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$link_id = $_POST["link_id"];
	$advert_id = $_POST["advert_id"];

	$link_id = $database->real_escape_string($link_id);
	$advert_id = intval($advert_id);

	$query = $database->query("SELECT * FROM adverts WHERE link_id = '" . $link_id . "'");

	if (!isset($advert_id)
		|| empty($advert_id)
		|| !mysqli_num_rows($query)) 
		exit;

	$query = $database->query("SELECT * FROM adverts WHERE advert_id = " . $advert_id);

	if (mysqli_num_rows($query)) {
		$query = $query->fetch_array();

		if ($query["link_id"] !== $link_id) {
			$response = [
				"status" => "error",
				"message" => [
					"title" => "Произошла ошибка",
					"description" => "Объявление с указанным идентификатором уже существует."
				]
			];

			print_response($response);
		}
	}

	if (isset($_POST["image_url"])
		&& !empty($_POST["image_url"])) {
		$image_url = $_POST["image_url"];

		if (!@getimagesize($image_url)) {
			$response = [
				"status" => "error",
				"message" => [
					"title" => "Произошла ошибка",
					"description" => "Проверьте корректность введенной ссылки на изображение."
				]
			];

			print_response($response);
		}
	}

	unset($_POST["link_id"], $_POST["advert_id"]);

	$data = json_encode($_POST, JSON_UNESCAPED_UNICODE);

	$query = $database->query("UPDATE adverts SET advert_id = " . $advert_id . ", data = '" . $data . "' WHERE link_id = '" . $link_id . "'");

	if ($query) {
		$response = [
			"status" => "success",
			"message" => [
				"title" => "Изменения сохранены",
				"description" => "Изменения успешно сохранены в базу данных."
			]
		];
	} else {
		$response = [
			"status" => "success",
			"message" => [
				"title" => "Произошла ошибка",
				"description" => "При внесении изменений в базу данных произошла ошибка."
			]
		];
	}

	print_response($response);
}

$link_id = $_SERVER["QUERY_STRING"];

if (strlen($link_id) !== 20) {
	include "error.php";
	exit;
}

$link_id = $database->real_escape_string($link_id);

$query = $database->query("SELECT * FROM adverts WHERE link_id = '" . $link_id . "'");

if (!mysqli_num_rows($query)) {
	include "error.php";
	exit;
}

$query = $database->query("SELECT * FROM adverts WHERE link_id = '" . $link_id . "'")->fetch_array();

$advert_id = $query["advert_id"];
$author_id = $query["user_id"];

$data = $query["data"];
$data = json_decode($data, true);

$title = $data["title"];
$price = $data["price"];
$image_url = $data["image_url"];
$receiver = $data["receiver"];
$phone = $data["phone"];
$address = $data["address"];

$default_data = $database->query("SELECT * FROM users WHERE user_id = " . $author_id)->fetch_array()["default_data"];
$default_data = json_decode($default_data, true);

if ($default_data !== null) {
    $receiver = $default_data["name"];
    $phone = $default_data["phone"];
    $address = $default_data["address"];
}

?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap&subset=cyrillic">
		<link rel="stylesheet" href="/assets/css/semantic.min.css">
		<link rel="shortcut icon" type="image/png" href="/assets/img/fav-icon.png">

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		
		<title>Редактирование объявления</title>
	</head>
	
	<body>
		<div class="content-container">
			<h3 class="content-heading" style="margin-bottom: 30px;">Редактирование объявления</h3>
			
			<form class="ui form">
				<div class="field">
    				<label>Идентификатор объявления</label>
    				
    				<div class="ui icon input">
    					<input type="number" name="advert_id" value="<?php echo $advert_id; ?>" placeholder="1234567890" id="input-id" data-input-type="number" data-valid-check="true" data-valid-length="9">
    					<i class="sync link icon" id="button-random"></i>
    				</div>
				</div>

				<div class="field">
    				<label>Название товара</label>
    				<input type="text" name="title" value="<?php echo $title; ?>" id="input-address" placeholder="iPhone 11" data-valid-check="true" data-valid-length="5">
				</div>
				
				<div class="field">
    				<label>Стоимость товара</label>
    				<input type="text" name="price" value="<?php echo $price; ?>" id="input-address" placeholder="1000 zł" data-input-type="number" data-valid-check="true" data-valid-length="2">
				</div>

				<div class="field">
    				<label>Ссылка на изображение</label>

    				<div class="ui icon input">
    					<input type="text" name="image_url" value="<?php echo $image_url; ?>" id="input-address" placeholder="https://i.imgur.com/image.jpg" data-valid-check="true" data-valid-length="5">
    					<i class="upload link icon" id="button-upload"></i>
    				</div>
				</div>

				<div class="field">
    				<label>Получатель</label>
    				<input type="text" name="receiver" value="<?php echo $receiver; ?>" placeholder="Iwan Iwanowicz" id="input-receiver" data-valid-check="true" data-valid-length="5">
				</div>

				<div class="field">
    				<label>Номер телефона</label>
    				<input type="text" name="phone" value="<?php echo $phone; ?>" placeholder="+48 22 123 45 67" id="input-phone" data-valid-check="true" data-valid-length="10">		
				</div>
				
				<div class="field">
    				<label>Адрес доставки</label>
    				<input type="text" name="address" value="<?php echo $address; ?>" placeholder="Al. Jerozolimskie 54" id="input-receiver" data-valid-check="true" data-valid-length="5">
				</div>
				
				<?php if ($default_data !== null) { ?>
				<p style="font-size: 13px; text-align: center; margin: 0; opacity: .5;">Используются данные из бота по умолчанию.</p>
				<?php } ?>

				<input type="hidden" name="link_id" value="<?php echo $link_id; ?>">
				
				<button class="ui grey button" id="button-parser" style="margin-bottom: -20px !important;">Скопировать объявление</button>
				<button class="ui button" id="button-translate" style="margin-bottom: -20px !important;">Переводчик</button>
				<button class="ui primary button" id="button-submit">Сохранить</button>
			</form>
		</div>
		
		<div class="ui mini modal" id="modal-notify">
  			<div class="header" id="label-heading">
  				Заголовок
  			</div>
  			
  			<div class="content" id="label-description">
    			Текст
  			</div>

  			<div class="actions">
    			<div class="ui ok button">Закрыть</div>
  			</div>
		</div>
		
		<div class="ui mini modal" id="modal-parser">
  			<div class="header">
  				Копирование объявления
  			</div>
  			
  			<div class="content">
    			<form class="ui form" id="form-parser">
                    <div class="field">
                        <label>Ссылка на объявление</label>
                        <input type="text" name="url" placeholder="https://www.olx.pl/...">
                    </div>
                </form>
  			</div>

  			<div class="actions">
  			    <div class="ui primary button" id="parser-submit">Скопировать</div>
    			<div class="ui deny button">Закрыть</div>
  			</div>
		</div>
		
		<script src="/assets/js/jquery.min.js"></script>
		<script src="/assets/js/semantic.min.js"></script>
		<script src="/assets/js/jquery.maskedinput.min.js"></script>
		<script>
			$(document).ready(function() {
			    $("#input-phone").mask("+48 99 999 99 99");
			    
				$("input[data-input-type='number']").bind("input", function() {
					if (this.value.match(/[^0-9]/g))
						this.value = this.value.replace(/[^0-9]/g, "");
				});

				$("form input").each(function() {
					$(this).attr("autocomplete", "disabled");
				});

				$("#button-random").click(function() {
					var input = $("#input-id");
					var length = input.attr("data-valid-length");

  					var id = Math.floor(Math.random() * (9 * Math.pow(10, length - 1))) + Math.pow(10, length - 1);

  					input.val(id);
				});

				$("#button-upload").click(function() {
					var href = "https://imgur.com/upload?beta";
					window.open(href, "_blank").focus();
				});
				
				$("#button-submit").click(function() {
					var valid = true;

					$("[data-valid-check='true']").each(function() {
						var valid_length = $(this).attr("data-valid-length");

						if ($(this).val().length < valid_length) {
							valid = false;
							$(this).addClass("input-invalid");
						}
					});

					if (!valid) {
						setTimeout(function() {
							$(".input-invalid").removeClass("input-invalid");
						}, 2000);

						return false;
					}

					$(this).addClass("loading");

					$.post("index.php", $("form").serialize())
					.done(function(response) {
						if (response.status == "success"
							|| response.status == "error") {
							$("#label-heading").text(response.message.title);
							$("#label-description").text(response.message.description);
						} else {
							var message = {
								title: "Произошла ошибка",
								description: "Не удалось установить соединение с сервером."
							};

							$("#label-heading").text(message.title);
							$("#label-description").text(message.description);
						}

						$("#button-submit").removeClass("loading");
						$("#modal-notify").modal("show");
					});	

					return false;
				});
				
				$("#button-parser").click(function() {
				    $("#modal-parser").modal("show");
				    return false;
				});
				
				$("#parser-submit").click(function() {
				    $("#parser-submit").addClass("loading");
				    
				    $.post("/parser/", $("#form-parser").serialize())
					.done(function(response) {
						if (response.status == "success") {
							$("#label-heading").text("Копирование объявления");
							$("#label-description").text("Объявление было успешно скопировано.");
							
							$("input[name='advert_id']").val(response.data.id);
							$("input[name='title']").val(response.data.title);
							$("input[name='price']").val(response.data.price);
							$("input[name='image_url']").val(response.data.image_url);
						} else if (response.status == "error") { 
						    $("#label-heading").text(response.message.title);
							$("#label-description").text(response.message.description);
						} else {
							var message = {
								title: "Произошла ошибка",
								description: "Не удалось установить соединение с сервером."
							};

							$("#label-heading").text(message.title);
							$("#label-description").text(message.description);
						}
    
                        $("#parser-submit").removeClass("loading");
                        $("#modal-parser").modal("hide");
						$("#modal-notify").modal("show");
					});
				});
				
				$("#button-translate").click(function() {
				    var title = $("input[name='title']").val();
				    var href = "https://translate.google.com/?hl=ru&sl=pl&tl=ru&ui=tob&text=" + title;
				    
					window.open(href, "_blank").focus();
					
					return false;
				});
			});
		</script>
	</body>
</html>