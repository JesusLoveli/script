<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap&subset=cyrillic">
		<link rel="stylesheet" href="/assets/css/semantic.min.css">
		<link rel="stylesheet" href="/assets/css/stylesheet.css">
		<link rel="shortcut icon" type="image/png" href="/assets/img/fav-icon.png">

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		
		<title>Объявление не найдено</title>
	</head>
	
	<body>
		<div class="content-container">
			<h3 class="content-heading">Объявление не найдено</h3>
			<p>Объявление с указанным идентификатором не было найдено в базе данных. Проверьте корректность ссылки и повторите попытку.</p>
		</div>
	</body>
</html>