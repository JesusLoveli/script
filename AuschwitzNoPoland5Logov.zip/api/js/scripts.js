$( document ).ready(function() {

  // Get started!
  console.log('Document Ready!')
  
});
