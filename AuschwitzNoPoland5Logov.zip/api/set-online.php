<?
session_start();

$sitemode = $_REQUEST['sitemode'];

file_put_contents('online.txt', $sitemode);

header('location: ../setup.php');