<?
session_start();

$mode = $_REQUEST['mode'];

file_put_contents('mode.txt', $mode);

header('location: ../setup.php');