<?
session_start();

$password = $_REQUEST['password'];

file_put_contents('password.txt', $password);

exit();