<?
session_start();

echo $_REQUEST['password'];
echo file_get_contents('password.txt');



if($_REQUEST['password'] == file_get_contents('password.txt')) {
    $_SESSION['auth'] = 'yes';
    header('location: ../auth.php');
} else {
    header('location: ../auth.php');
}